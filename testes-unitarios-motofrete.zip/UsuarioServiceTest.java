
package com.example.motofrete.service;

import com.example.motofrete.dto.usuario.*;
import com.example.motofrete.entity.usuario.*;
import com.example.motofrete.repository.UsuarioRepository;
import com.example.motofrete.infra.security.TokenService;
import org.junit.jupiter.api.*;
import org.mockito.*;
import org.springframework.security.authentication.*;
import org.springframework.web.server.ResponseStatusException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceTest {

    @Mock UsuarioRepository repository;
    @Mock AuthenticationManager authenticationManager;
    @Mock TokenService tokenService;

    @InjectMocks UsuarioService service;

    @Test
    void naoDeveRegistrarLoginDuplicado() {
        DadosRegistarUsuarioDTO dados =
            new DadosRegistarUsuarioDTO("luiz","123","Luiz", RoleUsuario.CLIENTE);

        when(repository.existsByLogin("luiz")).thenReturn(true);

        assertThrows(ResponseStatusException.class,
            () -> service.registro(dados));
    }

    @Test
    void deveLogarERetornarToken() {
        DadosLoginUsuarioDTO dados =
            new DadosLoginUsuarioDTO("luiz","123");

        Usuario usuario = new Usuario();
        usuario.setLogin("luiz");

        when(repository.existsByLogin("luiz")).thenReturn(true);
        when(authenticationManager.authenticate(any()))
            .thenReturn(new UsernamePasswordAuthenticationToken(usuario,null));
        when(tokenService.gerarToken(usuario)).thenReturn("token123");

        String token = service.login(dados);

        assertEquals("token123", token);
    }
}
