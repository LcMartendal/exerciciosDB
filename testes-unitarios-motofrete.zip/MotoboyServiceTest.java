
package com.example.motofrete.service;

import com.example.motofrete.dto.motoboy.*;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.exception.motoboy.DadosDoVeiculoNulosOuInvalidos;
import com.example.motofrete.repository.*;
import org.junit.jupiter.api.*;
import org.mockito.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MotoboyServiceTest {

    @Mock MotoboyRepository repository;
    @Mock UsuarioRepository usuarioRepository;

    @InjectMocks MotoboyService service;

    @Test
    void deveFalharQuandoAnoInvalido() {
        Motoboy motoboy = new Motoboy();
        motoboy.setId(1L);

        DadosAtualizarMotoboyDTO dados =
            new DadosAtualizarMotoboyDTO("Honda","ABC",1970);

        when(repository.findById(1L)).thenReturn(Optional.of(motoboy));

        assertThrows(DadosDoVeiculoNulosOuInvalidos.class,
            () -> service.atualizar(1L, dados));
    }
}
