
package com.example.motofrete.service;

import com.example.motofrete.dto.frete.*;
import com.example.motofrete.dto.usuario.DadosResponseUsuarioDTO;
import com.example.motofrete.entity.frete.*;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.exception.frete.DadosOrigemOuDestinoNaoPodeSerNullException;
import com.example.motofrete.repository.*;
import com.example.motofrete.service.rotas.*;
import org.junit.jupiter.api.*;
import org.mockito.*;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FreteServiceTest {

    @Mock FreteRepository freteRepository;
    @Mock UsuarioRepository usuarioRepository;
    @Mock MotoboyRepository motoboyRepository;
    @Mock RotaService rotaService;
    @Mock RotaOrdenacaoService rotaOrdenacaoService;

    @InjectMocks FreteService freteService;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(freteService, "tarifaKm", 10.0);
    }

    @Test
    void deveInserirFreteComSucesso() {
        DadosFreteDTO dados = new DadosFreteDTO("Rua A", "Rua B", 1L);
        Usuario usuario = new Usuario();
        usuario.setId(1L);

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        when(rotaService.gerarCoordenadas(anyString())).thenReturn(new double[]{-26.9, -49.0});

        Map<String,Object> rotaMock = Map.of(
            "routes", List.of(
                Map.of("summary", Map.of("distance", 5000, "duration", 600),
                       "geometry", "abc")
            )
        );

        when(rotaService.gerarRota(anyList())).thenReturn(rotaMock);
        when(freteRepository.save(any())).thenAnswer(i -> i.getArgument(0));

        DadosResponseFreteDTO resp = freteService.inserir(dados);

        assertEquals(StatusFrete.PENDENTE, resp.status());
        assertEquals(5.0, resp.distanciaKm());
        assertEquals(50.0, resp.valor());
    }

    @Test
    void deveFalharQuandoOrigemVazia() {
        DadosFreteDTO dados = new DadosFreteDTO("", "Rua B", 1L);
        assertThrows(DadosOrigemOuDestinoNaoPodeSerNullException.class,
            () -> freteService.inserir(dados));
    }
}
