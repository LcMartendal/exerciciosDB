
package com.example.motofrete.controller;

import com.example.motofrete.dto.usuario.*;
import com.example.motofrete.entity.usuario.RoleUsuario;
import com.example.motofrete.service.UsuarioService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UsuarioController.class)
@AutoConfigureMockMvc(addFilters = false)
class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UsuarioService service;

    @Test
    void deveRegistrarUsuario() throws Exception {

        DadosRegistarUsuarioDTO dto =
                new DadosRegistarUsuarioDTO("luiz", "123", "Luiz", RoleUsuario.CLIENTE);

        DadosResponseUsuarioDTO resposta =
                new DadosResponseUsuarioDTO(1L, "luiz", "Luiz", RoleUsuario.CLIENTE);

        when(service.registro(any())).thenReturn(resposta);

        mockMvc.perform(post("/usuario/auth/registrar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.['Usuario registrado com sucesso!'].login").value("luiz"));
    }

    @Test
    void deveLogarUsuario() throws Exception {

        DadosLoginUsuarioDTO dto =
                new DadosLoginUsuarioDTO("luiz", "123");

        when(service.login(any())).thenReturn("token123");

        mockMvc.perform(post("/usuario/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Login bem sucessedido!"))
                .andExpect(jsonPath("$.token").value("token123"));
    }

    @Test
    void deveAtualizarUsuario() throws Exception {

        DadosAtualizarUsuarioDTO dto =
                new DadosAtualizarUsuarioDTO("novoLogin", "novaSenha", "Novo Nome", RoleUsuario.CLIENTE);

        DadosResponseUsuarioDTO resposta =
                new DadosResponseUsuarioDTO(1L, "novoLogin", "Novo Nome", RoleUsuario.CLIENTE);

        when(service.atualizar(eq(1L), any())).thenReturn(resposta);

        mockMvc.perform(put("/usuario/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.['usuário'].login").value("novoLogin"));
    }

    @Test
    void deveListarUsuarios() throws Exception {

        when(service.listarTodos()).thenReturn(List.of(
                new DadosResponseUsuarioDTO(1L, "luiz", "Luiz", RoleUsuario.CLIENTE)
        ));

        mockMvc.perform(get("/usuario"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Usuários listados com sucesso!"))
                .andExpect(jsonPath("$.['lista de usuários']").isArray());
    }

    @Test
    void deveDeletarUsuario() throws Exception {

        DadosResponseUsuarioDTO resposta =
                new DadosResponseUsuarioDTO(1L, "luiz", "Luiz", RoleUsuario.CLIENTE);

        when(service.deletar(1L)).thenReturn(resposta);

        mockMvc.perform(delete("/usuario/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Usuário deletado com sucesso!"));
    }
}
