CREATE TABLE IF NOT EXISTS usuario (

    id SERIAL PRIMARY KEY,
    login VARCHAR(120) UNIQUE NOT NULL,
    senha_hash VARCHAR(200) NOT NULL,
    nome VARCHAR(150),
    role VARCHAR(50) NOT NULL,
    criado_em TIMESTAMP DEFAULT NOW()

);