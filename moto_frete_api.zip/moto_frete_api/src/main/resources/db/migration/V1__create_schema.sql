CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(200) NOT NULL,
    nome VARCHAR(150),
    role VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS motoboy (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    status VARCHAR(20) DEFAULT 'OFFLINE',
    placa VARCHAR(30),
    modelo VARCHAR(100),
    ano INTEGER
);

CREATE TABLE IF NOT EXISTS frete (
    id SERIAL PRIMARY KEY,
    criador_id INTEGER REFERENCES users(id),
    motoboy_id INTEGER REFERENCES motoboy(id),

    origem_endereco TEXT,
    origem_lat DOUBLE PRECISION,
    origem_lng DOUBLE PRECISION,

    destino_endereco TEXT,
    destino_lat DOUBLE PRECISION,
    destino_lng DOUBLE PRECISION,

    distancia_km DOUBLE PRECISION,
    valor DOUBLE PRECISION,

    status VARCHAR(30) DEFAULT 'PENDENTE',
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_frete_origem_coords ON frete (origem_lat, origem_lng);
