CREATE TABLE IF NOT EXISTS frete (

    id SERIAL PRIMARY KEY,
    criador_id INTEGER REFERENCES usuario(id),
    motoboy_id INTEGER REFERENCES motoboy(id),

    origem_endereco TEXT,
    origem_lat DOUBLE PRECISION,
    origem_lng DOUBLE PRECISION,

    destino_endereco TEXT,
    destino_lat DOUBLE PRECISION,
    destino_lng DOUBLE PRECISION,

    distancia_km DOUBLE PRECISION,
    valor DOUBLE PRECISION,

    status VARCHAR(30) DEFAULT 'PENDENTE',
    criado_em TIMESTAMP DEFAULT NOW()

);

CREATE INDEX IF NOT EXISTS idx_frete_origem_coords ON frete (origem_lat, origem_lng);