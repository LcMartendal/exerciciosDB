ALTER TABLE usuario
ADD CONSTRAINT uk_usuario_cpf_ou_cnpj UNIQUE (cpf_ou_cnpj);