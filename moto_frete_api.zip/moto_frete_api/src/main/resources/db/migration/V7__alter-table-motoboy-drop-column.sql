ALTER TABLE motoboy
DROP COLUMN modelo_moto,
DROP COLUMN placa,
DROP COLUMN ano;
