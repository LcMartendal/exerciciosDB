ALTER TABLE usuario
ADD CONSTRAINT chk_cpf_cnpj_dt_nascimento
CHECK (
    (
        length(cpf_ou_cnpj) = 11
        AND dt_nascimento IS NOT NULL
    )
    OR
    (
        length(cpf_ou_cnpj) = 14
    )
);
