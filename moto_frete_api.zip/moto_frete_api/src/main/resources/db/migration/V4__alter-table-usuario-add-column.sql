ALTER TABLE usuario
ADD COLUMN cpf_ou_cnpj VARCHAR(14),
ADD COLUMN dt_nascimento DATE;
