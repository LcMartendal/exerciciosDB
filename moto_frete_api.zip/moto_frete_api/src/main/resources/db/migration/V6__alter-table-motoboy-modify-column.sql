ALTER TABLE motoboy
RENAME COLUMN modelo_moto TO modelo_veiculo;

ALTER TABLE motoboy
RENAME COLUMN placa TO placa_veiculo;

ALTER TABLE motoboy
RENAME COLUMN ano TO ano_veiculo;
