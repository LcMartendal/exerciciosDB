package com.martendal.moto_frete_api.exception.entities.usuario;

public class DadosNaoPodemSerNullException extends RuntimeException{

    public DadosNaoPodemSerNullException() {
    }

    public DadosNaoPodemSerNullException(String message) {
        super(message);
    }
}
