package com.martendal.moto_frete_api.dto.frete;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosFreteDTO(

        @NotNull
        Long criador_id,

        @NotBlank
        String origem,

        @NotBlank
        String destino

//        @NotNull
//        Double distanciaKm,
//
//        @NotNull
//        Double valor,
//
//        @NotNull
//        StatusFrete status

) {
}
