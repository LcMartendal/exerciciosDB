package com.martendal.moto_frete_api.dto.motoboy;

import org.springframework.data.domain.Page;

public record ListaMotoboysResponseDTO(

        String message,
        Page<DadosResponseMotoboyDTO> motoboys

) {}
