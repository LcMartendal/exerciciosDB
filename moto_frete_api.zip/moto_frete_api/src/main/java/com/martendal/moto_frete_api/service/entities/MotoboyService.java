package com.martendal.moto_frete_api.service.entities;

import com.martendal.moto_frete_api.dto.motoboy.*;
import com.martendal.moto_frete_api.entity.Motoboy;
import com.martendal.moto_frete_api.entity.usuario.Usuario;
import com.martendal.moto_frete_api.repository.UsuarioRepository;
import com.martendal.moto_frete_api.exception.entities.NaoEncontradoException;
import com.martendal.moto_frete_api.exception.entities.motoboy.UsuarioJaAssociadoAUmMotoboyException;
import com.martendal.moto_frete_api.exception.entities.usuario.DadosNaoPodemSerNullException;
import com.martendal.moto_frete_api.repository.MotoboyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.stereotype.Service;

@Service
public class MotoboyService {

    @Autowired
    private MotoboyRepository repository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public DadosResponseMotoboyDTO inserir(DadosCadastroMotoboyDTO dados) {

        if (dados.usuario_id() == null) {
            throw new DadosNaoPodemSerNullException();
        }

        if (repository.existsByUsuarioId(dados.usuario_id())){
            throw new UsuarioJaAssociadoAUmMotoboyException("Usuário já associado a um motoboy");
        }

        Usuario usuario = usuarioRepository.findById(dados.usuario_id())
                .orElseThrow(() -> new NaoEncontradoException("Usuário não encontrado com id " + dados.usuario_id()));

        Motoboy motoboy = new Motoboy(dados, usuario);

        repository.save(motoboy);

        return new DadosResponseMotoboyDTO(
                motoboy.getUsuario().getUsername(),
                dados.modelo_veiculo(),
                dados.placa_veiculo(),
                dados.ano_veiculo(),
                new DadosLocalizacaoMotoboyDTO(
                        0.0,
                        0.0
                ));
    }

    public Page<DadosResponseMotoboyDTO> listarMotoboys(Pageable pageable) {

        return repository.findAll(pageable)
                .map(motoboy -> new DadosResponseMotoboyDTO(
                        motoboy.getUsuario().getUsername(),
                        motoboy.getModelo_veiculo(),
                        motoboy.getPlaca_veiculo(),
                        motoboy.getAno_veiculo(),
                        new DadosLocalizacaoMotoboyDTO(
                                motoboy.getLatitude(),
                                motoboy.getLongitude()
                        ))
                );
    }

    public DadosResponseMotoboyDTO atualizar(Long id, DadosAtualizarMotoboyDTO dados) {

        Motoboy motoboy = repository.findById(id)
                            .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + id));

        if(!dados.modelo_moto().isBlank()){
            motoboy.setModelo_veiculo(dados.modelo_moto());
        }

        if(!dados.placa().isBlank()){
            motoboy.setPlaca_veiculo(dados.placa());
        }

        if(dados.ano() < 1980 ){
            throw new UsuarioJaAssociadoAUmMotoboyException("Ano da moto inválido: " + dados.ano());
        }

        motoboy.setAno_veiculo(dados.ano());

        repository.save(motoboy);

        return new DadosResponseMotoboyDTO(
                motoboy.getUsuario().getNome(),
                dados.modelo_moto(),
                dados.placa(),
                dados.ano(),
                new DadosLocalizacaoMotoboyDTO(
                        motoboy.getLatitude(),
                        motoboy.getLongitude()
                ));
    }

    public DadosResponseLocalizacaoMotoboyDTO atualizarLocalizacao(Long id, DadosAtualizarLocalizacaoMotoboyDTO dados) {

        Motoboy motoboy = repository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + id));

        motoboy.setLatitude(dados.latitude());
        motoboy.setLongitude(dados.longitude());

        repository.save(motoboy);

        return new DadosResponseLocalizacaoMotoboyDTO(
                motoboy.getId(),
                motoboy.getUsuario().getNome(),
                motoboy.getLatitude(),
                motoboy.getLongitude());

    }

    public DadosResponseMotoboyDTO deletar(Long motoboy_id) {

        Motoboy motoboy = repository.findById(motoboy_id)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboy_id));

        repository.delete(motoboy);

        return new DadosResponseMotoboyDTO(
                motoboy.getUsuario().getNome(),
                motoboy.getModelo_veiculo(),
                motoboy.getPlaca_veiculo(),
                motoboy.getAno_veiculo(),
                new DadosLocalizacaoMotoboyDTO(
                        motoboy.getLatitude(),
                        motoboy.getLongitude()
                ));
    }

}
