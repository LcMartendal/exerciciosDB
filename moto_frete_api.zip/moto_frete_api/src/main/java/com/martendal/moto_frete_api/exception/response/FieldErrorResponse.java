package com.martendal.moto_frete_api.exception.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class FieldErrorResponse {

    private String field;
    private String message;

}
