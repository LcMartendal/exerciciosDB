package com.martendal.moto_frete_api.service.rotas.util;

import com.martendal.moto_frete_api.dto.rota.FreteRotaDTO;
import com.martendal.moto_frete_api.dto.rota.PontoRota;
import com.martendal.moto_frete_api.dto.rota.TipoPonto;
import com.martendal.moto_frete_api.entity.Motoboy;
import com.martendal.moto_frete_api.entity.frete.Frete;
import com.martendal.moto_frete_api.entity.frete.StatusFrete;
import com.martendal.moto_frete_api.repository.FreteRepository;
import com.martendal.moto_frete_api.service.rotas.RotaOrdenacaoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ObtedorEMapeadorDeRotaMotoboyService {

    private final FreteRepository freteRepository;
    private final RotaOrdenacaoService rotaOrdenacaoService;

    public List<PontoRota> obterRotaMotoboy(Motoboy motoboy) {

        List<Frete> fretesAtivos =
                freteRepository.findByMotoboyAndStatus(
                        motoboy,
                        StatusFrete.ACEITO
                );

        List<FreteRotaDTO> fretesRota = fretesAtivos.stream()
                .map(this::mapearFrete)
                .toList();

        if (motoboy.getLatitude() == null || motoboy.getLongitude() == null) {
            throw new RuntimeException("Motoboy sem coordenadas");
        }

        if (fretesRota.isEmpty()) {
            return List.of(
                    new PontoRota(
                            motoboy.getId(),
                            TipoPonto.ORIGEM_FRETE,
                            null,
                            motoboy.getLatitude(),
                            motoboy.getLongitude()
                    )
            );
        }


        return rotaOrdenacaoService.ordenarGreedy(
                new PontoRota(null, TipoPonto.ORIGEM_FRETE, null, motoboy.getLatitude(), motoboy.getLongitude()),
                fretesRota);
    }

    private FreteRotaDTO mapearFrete(Frete frete) {

        Long id = frete.getId();

        return new FreteRotaDTO(
                id,
                new PontoRota(
                        id,
                        TipoPonto.ORIGEM_FRETE,
                        frete.getOrigemEndereco(),
                        frete.getOrigemLat(),
                        frete.getOrigemLng()
                ),
                new PontoRota(
                        id,
                        TipoPonto.DESTINO_FRETE,
                        frete.getDestinoEndereco(),
                        frete.getDestinoLat(),
                        frete.getDestinoLng()
                )
        );
    }
}
