package com.martendal.moto_frete_api.dto.motoboy;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizarLocalizacaoMotoboyDTO(

        @NotNull
        Double latitude,

        @NotNull
        Double longitude

) {
}
