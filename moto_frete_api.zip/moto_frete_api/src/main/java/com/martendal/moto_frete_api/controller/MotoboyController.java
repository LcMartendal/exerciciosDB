package com.martendal.moto_frete_api.controller;

import com.martendal.moto_frete_api.dto.ApiResponse;
import com.martendal.moto_frete_api.dto.motoboy.*;
import com.martendal.moto_frete_api.service.entities.MotoboyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/motoboy")
public class MotoboyController {

    @Autowired
    private MotoboyService service;

    @PostMapping("/cadastro")
    public ResponseEntity cadastrar(@RequestBody @Valid DadosCadastroMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse<>("Motoboy cadastrado com sucesso!", service.inserir(dados)));
    }

    @PutMapping("/{id}")
    public ResponseEntity atualizar(@PathVariable Long id, @Valid @RequestBody DadosAtualizarMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Motoboy atualizado com sucesso!", service.atualizar(id, dados)));
    }

    @GetMapping
    public ResponseEntity listar(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {

        Pageable pageable = PageRequest.of(page, size);
        Page<DadosResponseMotoboyDTO> motoboys = service.listarMotoboys(pageable);

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Motoboys listados com sucesso!", motoboys));
    }

    @PutMapping("/localizacao/{id}")
    public ResponseEntity atualizarLocalizacao(@PathVariable Long id, @Valid @RequestBody DadosAtualizarLocalizacaoMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Localização do motoboy atualizada com sucesso!", service.atualizarLocalizacao(id, dados)));
    }

    @DeleteMapping("{id}")
    public ResponseEntity deletar(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Motoboy deletado com sucesso!", service.deletar(id)));
    }

}
