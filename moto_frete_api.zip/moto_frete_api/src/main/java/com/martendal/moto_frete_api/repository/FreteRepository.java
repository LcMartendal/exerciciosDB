package com.martendal.moto_frete_api.repository;

import com.martendal.moto_frete_api.entity.Motoboy;
import com.martendal.moto_frete_api.entity.frete.Frete;
import com.martendal.moto_frete_api.entity.frete.StatusFrete;
import com.martendal.moto_frete_api.entity.usuario.Usuario;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FreteRepository extends JpaRepository<Frete, Long> {

    Page<Frete> findByStatus(Pageable pageable, StatusFrete status);

    @Query(
            value = """
    SELECT *
    FROM (
        SELECT *,
        (6371 * acos(
            cos(radians(:lat)) * cos(radians(origem_lat)) *
            cos(radians(origem_lng) - radians(:lng)) +
            sin(radians(:lat)) * sin(radians(origem_lat))
        )) AS distancia
        FROM frete
        WHERE status = :status
    ) f
    WHERE distancia <= :raio
    ORDER BY distancia ASC
    """,
            nativeQuery = true
    )
    Page<Frete> listarFretesProximosPorRaio(Pageable pageable,
            @Param("lat") Double latitude,
            @Param("lng") Double longitude,
            @Param("status") String status,
            @Param("raio") Double raioKm
    );

    List<Frete> findByMotoboyAndStatus(Motoboy motoboy, StatusFrete status);

    boolean existsByCriadorId(Long criadorId);

    @Query(value = """
    SELECT EXISTS (
        SELECT 1
        FROM frete
        WHERE criador_id = :criadorId
          AND ABS(origem_lat - :origemLat) < 0.0001
          AND ABS(origem_lng - :origemLng) < 0.0001
          AND ABS(destino_lat - :destinoLat) < 0.0001
          AND ABS(destino_lng - :destinoLng) < 0.0001
    )
    """, nativeQuery = true)
    boolean existsByCriadorAndRota(
            @Param("criadorId") Long criadorId,
            @Param("origemLat") Double origemLat,
            @Param("origemLng") Double origemLng,
            @Param("destinoLat") Double destinoLat,
            @Param("destinoLng") Double destinoLng
    );

    @Query(value = """
       SELECT CASE WHEN COUNT(*) >= 5 THEN true ELSE false END
       FROM frete
       WHERE motoboy_id = :motoboyId
       AND status <> 'CONCLUIDO'
       """, nativeQuery = true)
    boolean hasFiveOrMoreFretesMotoboy(@Param("motoboyId") Long motoboyId);


    @Query(value = """
       SELECT CASE WHEN COUNT(*) >= 5 THEN true ELSE false END
       FROM frete
       WHERE criador_id = :criadorId
       AND status <> 'CONCLUIDO'
       """, nativeQuery = true)
    boolean hasFiveOrMoreFretesCriador(@Param("criadorId") Long criadorId);

}
