package com.martendal.moto_frete_api.exception.entities.usuario;

public class RoleInvalidaException extends RuntimeException{

    public RoleInvalidaException() {
    }

    public RoleInvalidaException(String message) {
        super(message);
    }
}
