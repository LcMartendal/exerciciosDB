package com.martendal.moto_frete_api.exception.entities.motoboy;

public class UsuarioJaAssociadoAUmMotoboyException extends RuntimeException {
    public UsuarioJaAssociadoAUmMotoboyException() {}

    public UsuarioJaAssociadoAUmMotoboyException(String message) {
        super(message);
    }
}
