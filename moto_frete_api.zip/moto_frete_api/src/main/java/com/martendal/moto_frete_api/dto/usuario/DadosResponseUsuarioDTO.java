package com.martendal.moto_frete_api.dto.usuario;

import com.martendal.moto_frete_api.entity.usuario.RoleUsuario;

public record DadosResponseUsuarioDTO(

        Long id,

        String login,

        String nome,

        RoleUsuario role
) {
}
