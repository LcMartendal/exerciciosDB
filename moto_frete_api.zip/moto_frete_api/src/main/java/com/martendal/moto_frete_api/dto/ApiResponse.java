package com.martendal.moto_frete_api.dto;

public record ApiResponse<T>(
        String message,
        T data
) {}
