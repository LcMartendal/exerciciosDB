package com.martendal.moto_frete_api.dto.rota.notused;

public record NOTUSEDCoordenadaDTO(

        double lat,
        double lng

) {}
