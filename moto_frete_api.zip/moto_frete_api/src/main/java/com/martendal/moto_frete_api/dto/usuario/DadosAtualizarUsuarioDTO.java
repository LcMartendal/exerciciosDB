package com.martendal.moto_frete_api.dto.usuario;

import com.martendal.moto_frete_api.entity.usuario.RoleUsuario;
import jakarta.validation.constraints.Email;

public record DadosAtualizarUsuarioDTO(

        @Email
        String login,

        String senha_hash,

        String nome,

        RoleUsuario role

) {
}
