package com.martendal.moto_frete_api.annotation.dtNascimento;


import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = DtNascimentoCpfValidator.class)
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface DtNascimentoObrigatorioParaCpf {

    String message() default "Data de nascimento é obrigatória quando CPF for informado";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

}
