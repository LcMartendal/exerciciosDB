package com.martendal.moto_frete_api.exception;

import com.martendal.moto_frete_api.exception.autenticacao.TokenInvalidoException;
import com.martendal.moto_frete_api.exception.entities.NaoEncontradoException;
import com.martendal.moto_frete_api.exception.entities.frete.FreteJaSolicitadoParaEssasLocalidadesException;
import com.martendal.moto_frete_api.exception.entities.frete.FreteNaoDisponivelException;
import com.martendal.moto_frete_api.exception.entities.frete.FreteNaoPodeSerConcluidoException;
import com.martendal.moto_frete_api.exception.entities.frete.LimiteDeFretesException;
import com.martendal.moto_frete_api.exception.entities.motoboy.UsuarioJaAssociadoAUmMotoboyException;
import com.martendal.moto_frete_api.exception.entities.usuario.*;
import com.martendal.moto_frete_api.exception.response.FieldErrorResponse;
import com.martendal.moto_frete_api.exception.response.ResponseException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Date;
import java.util.List;

@RestControllerAdvice
public class RestControllerAdviceHandler {

    @ExceptionHandler(LimiteDeFretesException.class)
    public ResponseEntity<ResponseException> handlerBadRequest(LimiteDeFretesException ex) {
        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(FreteJaSolicitadoParaEssasLocalidadesException.class)
    public  ResponseEntity<ResponseException> handlerBadRequest(FreteJaSolicitadoParaEssasLocalidadesException ex) {
        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(RoleInvalidaException.class)
    public ResponseEntity<ResponseException> handlerBadRequest(RoleInvalidaException ex) {
        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(DataDeNascimentoInvalidaException.class)
    public ResponseEntity<ResponseException> handlerBadRequest(DataDeNascimentoInvalidaException ex) {
        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(CpfOuCnpjJaCadastradoException.class)
    public ResponseEntity<ResponseException> handlerBadRequest(CpfOuCnpjJaCadastradoException ex) {
        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(FreteNaoPodeSerConcluidoException.class)
    public ResponseEntity<ResponseException> handlerBadRequest(FreteNaoPodeSerConcluidoException ex) {
        ResponseException response = new ResponseException(
                "Frete já concluido ou não pode ser concluido",
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(FreteNaoDisponivelException.class)
    public ResponseEntity<ResponseException> handlerBadRequest(FreteNaoDisponivelException ex) {
        ResponseException response = new ResponseException(
                "Frete não está disponivel",
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    @ExceptionHandler(NaoEncontradoException.class)
    public ResponseEntity<ResponseException> handlerNotFound(NaoEncontradoException ex) {
        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.NOT_FOUND.value(),
                new Date().getTime(),
                null
        );


        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(response);
    }

    @ExceptionHandler(FreteExistenteParaCriadorException.class)
    public ResponseEntity<ResponseException> handlerFreteAssociado(FreteExistenteParaCriadorException ex) {
        ResponseException response = new ResponseException(
                "Há frete associado a esse usuário",
                HttpStatus.CONFLICT.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(response);
    }

    @ExceptionHandler(UsuarioJaAssociadoAUmMotoboyException.class)
    public ResponseEntity<ResponseException> handler(UsuarioJaAssociadoAUmMotoboyException ex) {
        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );


        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(response);
    }

    @ExceptionHandler(LoginJaExisteException.class)
    public ResponseEntity<ResponseException> handlerConflict(LoginJaExisteException ex) {

        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.CONFLICT.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }

    @ExceptionHandler(TokenInvalidoException.class)
    public ResponseEntity<String> handlerConflict(TokenInvalidoException ex) {

        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body("token invalido");
    }

    // @JsonFormat usado na dt_nascimento
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ResponseException> handleInvalidDateFormat(HttpMessageNotReadableException ex) {
        ResponseException response = new ResponseException(
                "Formato da data de aniversário deve ser (aaaa-mm-dd)",
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);
    }

    //Para @VALID
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResponseException> handleValidations(MethodArgumentNotValidException ex) {

        List<FieldErrorResponse> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(error -> new FieldErrorResponse(
                        error.getField(),
                        error.getDefaultMessage()
                ))
                .toList();

        ResponseException response = new ResponseException(

                "Erro de validação",
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                errors
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);

    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResponseException> handle(Exception ex) throws Exception {
        if (ex instanceof AuthenticationException) {
            throw ex;
        }else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                    new ResponseException(
                            "Erro interno da aplicação. Tente novamente mais tarde ou entre em contato com o time de suporte.",
                            HttpStatus.INTERNAL_SERVER_ERROR.value(),
                            new Date().getTime()
                    )
            );
        }
    }

}
