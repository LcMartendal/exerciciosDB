package com.martendal.moto_frete_api.entity.usuario;

public enum RoleUsuario {

    MOTOBOY,
    SOLICITANTE_FRETE,
    ADMIN

}
