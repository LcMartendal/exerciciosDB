package com.martendal.moto_frete_api.controller;

import com.martendal.moto_frete_api.dto.ApiResponse;
import com.martendal.moto_frete_api.dto.frete.DadosFreteDTO;
import com.martendal.moto_frete_api.dto.frete.DadosResponseFreteDTO;
import com.martendal.moto_frete_api.dto.frete.ListaFretesPendentesResponseDTO;
import com.martendal.moto_frete_api.dto.frete.ListaFretesProximosResponseDTO;
import com.martendal.moto_frete_api.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.martendal.moto_frete_api.service.entities.FreteService;
import jakarta.validation.Valid;
import org.aspectj.lang.annotation.AfterReturning;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/frete")
public class FreteController {

    @Autowired
    private FreteService service;

    @PostMapping("/inserir")
    public ResponseEntity inserir(@Valid @RequestBody DadosFreteDTO dados) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new ApiResponse<>("Frete inserido com sucesso!", service.inserir(dados)));
    }

    @GetMapping("/pendentes")
    public ResponseEntity listarPendentes(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {

        Pageable pageable = PageRequest.of(page, size);
        Page<DadosResponseFreteDTO> fretes = service.listarPendentes(pageable);

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Listagem de fretes pendentes bem sucessedida", fretes));
    }

    @GetMapping("/proximos")
    public ResponseEntity listarProximos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @Valid @RequestBody DadosAtualizarLocalizacaoMotoboyDTO dados
    ) {

        Pageable pageable = PageRequest.of(page, size);
        Page<DadosResponseFreteDTO> fretes = service.listarProximos(pageable, dados);

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Listagem de fretes proximos bem sucessedida", fretes));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity excluir(@PathVariable Long id) {

        service.excluir(id);
        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Frete deletado com sucesso!", ""));
    }

    @PutMapping("/{frete_id}/aceitar/{motoboy_id}")
    public ResponseEntity aceitar(@PathVariable Long frete_id, @PathVariable Long motoboy_id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Frete aceito com sucesso", service.aceitar(frete_id, motoboy_id)));
    }

    @PutMapping("/{id}")
    public ResponseEntity concluir(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("Frete concluido com sucesso", service.concluir(id)));
    }

    @GetMapping("/rota/{motoboy_id}")
    public ResponseEntity mostrarRota(@PathVariable Long motoboy_id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(new ApiResponse<>("rota", service.mostrarRota(motoboy_id)));
    }

}
