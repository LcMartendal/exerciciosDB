package com.martendal.moto_frete_api.dto.frete;

import com.martendal.moto_frete_api.entity.frete.StatusFrete;

public record DadosResponseFreteDTO(

        Long id,
        String nome_do_solicitante,
        String origem,
        String destino,
        Double distanciaKm,
        Double valor,
        StatusFrete status

) {
}
