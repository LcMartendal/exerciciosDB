package com.martendal.moto_frete_api.dto.rota;

public enum TipoPonto {
    ORIGEM_FRETE,
    DESTINO_FRETE,
    POSICAO_MOTOBOY
}
