package com.martendal.moto_frete_api.exception.entities.usuario;

public class DataDeNascimentoInvalidaException extends RuntimeException{

    public DataDeNascimentoInvalidaException() {
    }

    public DataDeNascimentoInvalidaException(String message) {
        super(message);
    }
}
