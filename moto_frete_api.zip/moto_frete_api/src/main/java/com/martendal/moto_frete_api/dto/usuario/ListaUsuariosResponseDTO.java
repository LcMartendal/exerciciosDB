package com.martendal.moto_frete_api.dto.usuario;

import org.springframework.data.domain.Page;

public record ListaUsuariosResponseDTO(

        String message,
        Page<DadosResponseUsuarioDTO> usuarios

) {}
