package com.martendal.moto_frete_api.dto.usuario;

import com.martendal.moto_frete_api.annotation.cpfOuCnpj.CpfOuCnpjValido;
import com.martendal.moto_frete_api.annotation.dtNascimento.DtNascimentoObrigatorioParaCpf;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.validation.constraints.*;

import java.time.LocalDate;

@DtNascimentoObrigatorioParaCpf
public record DadosRegistarUsuarioDTO(

        @Email
        @NotBlank
        String login,

        @NotBlank
        String senha_hash,

        @NotBlank
        String nome,

        @NotNull
        @CpfOuCnpjValido
        String cpf_ou_cnpj,

        @JsonFormat(pattern = "yyyy-MM-dd")
        LocalDate dt_nascimento,

        @NotBlank
        String role
) {
}
