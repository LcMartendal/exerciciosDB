package com.martendal.moto_frete_api.exception.entities.frete;

public class FreteNaoPodeSerConcluidoException extends RuntimeException{
    public FreteNaoPodeSerConcluidoException() {
    }

    public FreteNaoPodeSerConcluidoException(String message) {
        super(message);
    }
}
