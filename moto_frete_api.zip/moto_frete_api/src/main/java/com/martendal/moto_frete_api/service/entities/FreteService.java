package com.martendal.moto_frete_api.service.entities;

import com.martendal.moto_frete_api.entity.Motoboy;
import com.martendal.moto_frete_api.entity.frete.Frete;
import com.martendal.moto_frete_api.entity.frete.StatusFrete;
import com.martendal.moto_frete_api.dto.frete.DadosFreteDTO;
import com.martendal.moto_frete_api.dto.frete.DadosResponseFreteDTO;
import com.martendal.moto_frete_api.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.martendal.moto_frete_api.entity.usuario.Usuario;
import com.martendal.moto_frete_api.exception.entities.frete.*;
import com.martendal.moto_frete_api.repository.MotoboyRepository;
import com.martendal.moto_frete_api.repository.UsuarioRepository;
import com.martendal.moto_frete_api.dto.rota.FreteRotaDTO;
import com.martendal.moto_frete_api.dto.rota.PontoRota;
import com.martendal.moto_frete_api.dto.rota.TipoPonto;
import com.martendal.moto_frete_api.dto.rota.RotaResumoDTO;
import com.martendal.moto_frete_api.service.rotas.RotaOrdenacaoService;
import com.martendal.moto_frete_api.service.rotas.RotaService;
import com.martendal.moto_frete_api.exception.entities.NaoEncontradoException;
import com.martendal.moto_frete_api.repository.FreteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FreteService {

    private final FreteRepository freteRepository;
    private final RotaOrdenacaoService rotaOrdenacaoService;
    private final MotoboyRepository motoboyRepository;
    private final UsuarioRepository usuarioRepository;
    private final RotaService rotaService;

    @Value("${motofrete.tarifa-por-km}")
    private double tarifaKm;

//    @Value("${motofrete.aumento-chuva}")
//    private double aumentoChuva;

    public DadosResponseFreteDTO inserir(DadosFreteDTO dados) {

        if (freteRepository.hasFiveOrMoreFretesCriador(dados.criador_id())) {
            throw new LimiteDeFretesException("Limite de fretes, delete ou espere algum frete ser concluido para inserir mais");
        }

        Usuario usuario = usuarioRepository.findById(dados.criador_id())
                .orElseThrow(() -> new NaoEncontradoException("Usuário solicitante de frete não encontrado com id " + dados.criador_id()));

        if(dados.destino().isBlank() || dados.origem().isBlank()){
            throw new DadosOrigemOuDestinoNaoPodeSerNullException();
        }

        double[] coordenadasOrigem = rotaService.gerarCoordenadas(dados.origem());
        double[] coordenadasDestino = rotaService.gerarCoordenadas(dados.destino());

        if( freteRepository.existsByCriadorAndRota(
            dados.criador_id(),
            coordenadasOrigem[1],
            coordenadasOrigem[0],
            coordenadasDestino[1],
            coordenadasDestino[0]
        )) {
            throw new FreteJaSolicitadoParaEssasLocalidadesException("Já foi solicitado frete para as mesmo local origem e destino");
        }


        Frete frete = new Frete(dados, StatusFrete.PENDENTE, usuario, coordenadasOrigem[1],
                coordenadasOrigem[0], coordenadasDestino[1], coordenadasDestino[0]);

        List<double[]> coordenadas = new ArrayList<>();

        coordenadas.add(coordenadasOrigem);
        coordenadas.add(coordenadasDestino);

        RotaResumoDTO resumo = rotaService.extrairResumoRota(rotaService.gerarRota(coordenadas));
        int casasDecimais = 3;

        if (resumo.distanciaKm() > 1000) { casasDecimais = 2; }

        BigDecimal distanciaKm = BigDecimal.valueOf(resumo.distanciaKm())
                .setScale(casasDecimais, RoundingMode.HALF_UP);

        frete.setValor(distanciaKm.doubleValue() * tarifaKm);
        frete.setDistanciaKm(distanciaKm.doubleValue());
        freteRepository.save(frete);

        return new DadosResponseFreteDTO(
                frete.getId(),
                frete.getCriador().getNome(),
                dados.origem(),
                dados.destino(),
                frete.getDistanciaKm(),
                frete.getValor(),
                frete.getStatus()
        );
    }

    public Page<DadosResponseFreteDTO> listarPendentes(Pageable pageable) {

        return freteRepository.findByStatus(pageable, StatusFrete.PENDENTE)
                .map(frete -> new DadosResponseFreteDTO(
                        frete.getId(),
                        frete.getCriador().getUsername(),
                        frete.getOrigemEndereco(),
                        frete.getDestinoEndereco(),
                        frete.getDistanciaKm(),
                        frete.getValor(),
                        frete.getStatus()
                ));
    }

    public Page<DadosResponseFreteDTO> listarProximos(Pageable pageable, DadosAtualizarLocalizacaoMotoboyDTO dados) {

        return freteRepository.listarFretesProximosPorRaio(pageable, dados.latitude(), dados.longitude(), "PENDENTE", 5.0 )
                .map(frete -> new DadosResponseFreteDTO(
                        frete.getId(),
                        frete.getCriador().getUsername(),
                        frete.getOrigemEndereco(),
                        frete.getDestinoEndereco(),
                        frete.getDistanciaKm(),
                        frete.getValor(),
                        frete.getStatus()
                ));
    }

    public void excluir(Long frete_id) {

        Frete frete = freteRepository.findById(frete_id)
                        .orElseThrow(() -> new NaoEncontradoException("Frete não encontrado com id " + frete_id));

        freteRepository.delete(frete);

    }

    public DadosResponseFreteDTO aceitar(Long freteId, Long motoboyId) {

        if (freteRepository.hasFiveOrMoreFretesMotoboy(motoboyId)){
                throw new LimiteDeFretesException("Limite de fretes, conclua algum frete para aceitar mais");
        }

        Frete frete = freteRepository.findById(freteId)
                .orElseThrow(() -> new NaoEncontradoException("Frete não encontrado com id " + freteId));

        Motoboy motoboy = motoboyRepository.findById(motoboyId)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboyId));

        if (frete.getStatus() != StatusFrete.PENDENTE){
            throw new FreteNaoDisponivelException("Frete não está disponivel");
        }

        frete.setMotoboy(motoboy);
        frete.setStatus(StatusFrete.ACEITO);

        freteRepository.save(frete);

        recalcularRotaMotoboy(motoboy);

        return new DadosResponseFreteDTO(
                frete.getId(),
                frete.getCriador().getUsername(),
                frete.getOrigemEndereco(),
                frete.getDestinoEndereco(),
                frete.getDistanciaKm(),
                frete.getValor(),
                frete.getStatus()
        );
    }

    public DadosResponseFreteDTO concluir(Long id) {

        Frete frete = freteRepository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("Frete não encontrado com id " + id));

        if (frete.getStatus() != StatusFrete.ACEITO){
            throw new FreteNaoPodeSerConcluidoException("Frete ja concluido ou não pode ser");
        }
        frete.setStatus(StatusFrete.CONCLUIDO);
        freteRepository.save(frete);

        if (frete.getMotoboy() != null) {
            recalcularRotaMotoboy(frete.getMotoboy());
        }

        return new DadosResponseFreteDTO(
                frete.getId(),
                frete.getCriador().getUsername(),
                frete.getOrigemEndereco(),
                frete.getDestinoEndereco(),
                frete.getDistanciaKm(),
                frete.getValor(),
                frete.getStatus()
        );

    }

    public List<PontoRota> mostrarRota(Long motoboyId) {

        Motoboy motoboy = motoboyRepository.findById(motoboyId)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontra com id "+ motoboyId));

        return obterRotaMotoboy(motoboy);
    }

    private List<PontoRota> obterRotaMotoboy(Motoboy motoboy) {

        List<Frete> fretesAtivos =
                freteRepository.findByMotoboyAndStatus(
                        motoboy,
                        StatusFrete.ACEITO
                );

        List<FreteRotaDTO> fretesRota = fretesAtivos.stream()
                .map(this::mapearFrete)
                .toList();

        return rotaOrdenacaoService.ordenarGreedy(
                new PontoRota(
                        motoboy.getId(),
                        TipoPonto.POSICAO_MOTOBOY,
                        null,
                        motoboy.getLongitude(),
                        motoboy.getLatitude()),
                fretesRota);
    }


    private void recalcularRotaMotoboy(Motoboy motoboy) {

        List<PontoRota> rota = obterRotaMotoboy(motoboy);

        rota.forEach(p ->
                System.out.println(
                        p.tipo() + " | Frete " + p.Id()
                )
        );
    }


    private FreteRotaDTO mapearFrete(Frete frete) {

        Long id = frete.getId();

        return new FreteRotaDTO(
                id,
                new PontoRota(
                        id,
                        TipoPonto.ORIGEM_FRETE,
                        frete.getOrigemEndereco(),
                        frete.getOrigemLat(),
                        frete.getOrigemLng()
                ),
                new PontoRota(
                        id,
                        TipoPonto.DESTINO_FRETE,
                        frete.getDestinoEndereco(),
                        frete.getDestinoLat(),
                        frete.getDestinoLng()
                )
        );
    }

}
