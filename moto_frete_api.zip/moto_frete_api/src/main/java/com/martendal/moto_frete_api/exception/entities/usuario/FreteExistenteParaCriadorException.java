package com.martendal.moto_frete_api.exception.entities.usuario;

public class FreteExistenteParaCriadorException extends RuntimeException{

    public FreteExistenteParaCriadorException() {
    }

    public FreteExistenteParaCriadorException(String message) {
        super(message);
    }
}
