package com.martendal.moto_frete_api.dto.motoboy;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosAtualizarMotoboyDTO(

        String modelo_moto,

        String placa,

        int ano
) {
}
