package com.martendal.moto_frete_api.exception.entities;

public class NaoEncontradoException extends RuntimeException{

    public NaoEncontradoException() {
    }

    public NaoEncontradoException(String message) {
        super(message);
    }
}
