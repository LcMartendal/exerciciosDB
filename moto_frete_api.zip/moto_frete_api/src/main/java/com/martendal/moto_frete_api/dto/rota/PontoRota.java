package com.martendal.moto_frete_api.dto.rota;

public record PontoRota(

        Long Id,
        TipoPonto tipo,
        String endereco,
        double latitude,
        double longitude

) {}
