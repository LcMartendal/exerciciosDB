package com.martendal.moto_frete_api.dto.frete;

import org.springframework.data.domain.Page;

public record ListaFretesPendentesResponseDTO(

        String message,
        Page<DadosResponseFreteDTO> fretes

) {}
