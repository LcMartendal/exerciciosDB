package com.martendal.moto_frete_api.exception.entities.usuario;

public class CpfOuCnpjJaCadastradoException extends RuntimeException{

    public CpfOuCnpjJaCadastradoException() { super("Login já existe"); }

    public CpfOuCnpjJaCadastradoException(String message) {
        super(message);
    }
}
