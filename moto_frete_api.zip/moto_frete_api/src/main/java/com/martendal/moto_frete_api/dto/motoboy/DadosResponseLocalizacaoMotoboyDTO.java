package com.martendal.moto_frete_api.dto.motoboy;

public record DadosResponseLocalizacaoMotoboyDTO(

        Long id,

        String nome,

        Double latitude,

        Double longitude

) {
}
