package com.martendal.moto_frete_api.exception.entities.frete;

public class FreteJaSolicitadoParaEssasLocalidadesException extends RuntimeException{
    public FreteJaSolicitadoParaEssasLocalidadesException() {
    }

    public FreteJaSolicitadoParaEssasLocalidadesException(String message) {
        super(message);
    }
}
