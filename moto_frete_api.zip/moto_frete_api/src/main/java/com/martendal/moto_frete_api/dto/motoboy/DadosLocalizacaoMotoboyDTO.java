package com.martendal.moto_frete_api.dto.motoboy;

public record DadosLocalizacaoMotoboyDTO(


        Double latitude,

        Double longitude

) {
}
