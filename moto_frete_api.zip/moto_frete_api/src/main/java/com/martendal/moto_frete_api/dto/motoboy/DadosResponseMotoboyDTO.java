package com.martendal.moto_frete_api.dto.motoboy;

public record DadosResponseMotoboyDTO(

        String nome,

        String modelo_veiculo,
        String placa_veiculo,
        Integer ano_veiculo,

        DadosLocalizacaoMotoboyDTO localizacao


) {}
