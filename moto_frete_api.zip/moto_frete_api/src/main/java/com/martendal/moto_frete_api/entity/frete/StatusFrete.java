package com.martendal.moto_frete_api.entity.frete;

public enum StatusFrete {

    PENDENTE,
    ACEITO,
    CONCLUIDO
//
//        COLETADO,        // Motoboy chegou na origem
//        EM_ANDAMENTO,    // Indo para o destino
//        CANCELADO        // Cancelado por alguém



    }
