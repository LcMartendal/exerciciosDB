package com.martendal.moto_frete_api.entity;

import com.martendal.moto_frete_api.dto.motoboy.DadosCadastroMotoboyDTO;
import com.martendal.moto_frete_api.entity.usuario.Usuario;
import com.martendal.moto_frete_api.dto.motoboy.DadosMotoboyDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "motoboy")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Motoboy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne @JoinColumn(name="usuario_id", nullable=false)
    private Usuario usuario;

    private Double latitude;

    private Double longitude;

//    private String status;

    private String modelo_veiculo;

    private String placa_veiculo;

    private int ano_veiculo;

    public Motoboy(DadosMotoboyDTO dados) {
        this.usuario = dados.usuario();
        this.latitude = dados.latitude();
        this.longitude = dados.longitude();
        this.modelo_veiculo = dados.modelo_veiculo();
        this.placa_veiculo = dados.placa_veiculo();
        this.ano_veiculo = dados.ano_veiculo();
    }

    public Motoboy(DadosCadastroMotoboyDTO dados, Usuario usuario) {
        this.usuario = usuario;
        this.modelo_veiculo = dados.modelo_veiculo();
        this.placa_veiculo = dados.placa_veiculo();
        this.ano_veiculo= dados.ano_veiculo();
    }
}
