package com.martendal.moto_frete_api.service;

import com.martendal.moto_frete_api.entity.usuario.Usuario;
import com.martendal.moto_frete_api.repository.UsuarioRepository;
import com.martendal.moto_frete_api.exception.entities.NaoEncontradoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

@Service
public class AutenticacaoService implements UserDetailsService {

    @Autowired
    private UsuarioRepository repository;

    @Override
    public UserDetails loadUserByUsername(String login) {

        Usuario usuario = (Usuario) repository.findByLogin(login);
        if(usuario.equals(null) || usuario.equals("")){
            throw new NaoEncontradoException("Usuário não encontrado com login: " + login);
        }

        return repository.findByLogin(login);
    }

}
