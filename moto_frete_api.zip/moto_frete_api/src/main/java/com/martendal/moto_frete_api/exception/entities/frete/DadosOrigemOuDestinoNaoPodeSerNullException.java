package com.martendal.moto_frete_api.exception.entities.frete;

public class DadosOrigemOuDestinoNaoPodeSerNullException extends RuntimeException{
    public DadosOrigemOuDestinoNaoPodeSerNullException() {
    }

    public DadosOrigemOuDestinoNaoPodeSerNullException(String message) {
        super(message);
    }
}
