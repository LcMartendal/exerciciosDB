package com.martendal.moto_frete_api.exception.entities.frete;

public class LimiteDeFretesException extends RuntimeException{
    public LimiteDeFretesException() {
    }

    public LimiteDeFretesException(String message) {
        super(message);
    }
}
