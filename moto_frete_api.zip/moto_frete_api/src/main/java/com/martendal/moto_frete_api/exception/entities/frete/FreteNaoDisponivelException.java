package com.martendal.moto_frete_api.exception.entities.frete;

public class FreteNaoDisponivelException extends RuntimeException{
    public FreteNaoDisponivelException() {
    }

    public FreteNaoDisponivelException(String message) {
        super(message);
    }
}
