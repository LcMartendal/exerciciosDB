package com.martendal.moto_frete_api.exception.autenticacao;

public class TokenInvalidoException extends RuntimeException{

    public TokenInvalidoException() {
    }

    public TokenInvalidoException(String message) {
        super(message);
    }
}
