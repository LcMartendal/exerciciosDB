package com.martendal.moto_frete_api.service.rotas;

import com.martendal.moto_frete_api.dto.rota.FreteRotaDTO;
import com.martendal.moto_frete_api.dto.rota.PontoRota;
import com.martendal.moto_frete_api.dto.rota.TipoPonto;
import com.martendal.moto_frete_api.service.rotas.util.CalculadoraDistancia;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RotaOrdenacaoService {

    private PontoRota atual;

    public List<PontoRota> ordenarGreedy(
            PontoRota inicio,
            List<FreteRotaDTO> fretes
    ) {

        List<PontoRota> rota = new ArrayList<>();
        List<PontoRota> pendentes = new ArrayList<>();
        Set<Long> fretesColetados = new HashSet<>();

        // adiciona início da rota
        rota.add(inicio);

        for (FreteRotaDTO f : fretes) {
            pendentes.add(f.origem());
            pendentes.add(f.destino());
        }

        this.atual = inicio;

        while (!pendentes.isEmpty()) {

            Optional<PontoRota> optProximo = pendentes.stream()
                    .filter(p ->
                            p.tipo() == TipoPonto.ORIGEM_FRETE ||
                                    fretesColetados.contains(p.Id())
                    )
                    .min(Comparator.comparingDouble(p ->
                            CalculadoraDistancia.distancia(atual, p)
                    ));

            if (optProximo.isEmpty()) {
                throw new IllegalStateException(
                        "Nenhum próximo ponto válido encontrado. Pendentes: " + pendentes
                );
            }

            PontoRota proximo = optProximo.get();

            rota.add(proximo);
            pendentes.remove(proximo);

            if (proximo.tipo() == TipoPonto.ORIGEM_FRETE) {
                fretesColetados.add(proximo.Id());
            }

            atual = proximo;
        }

        return rota;
    }

}
