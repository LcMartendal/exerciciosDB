package com.martendal.moto_frete_api.dto.rota;

public record FreteRotaDTO(

        Long freteId,
        PontoRota origem,
        PontoRota destino

){}
