package com.martendal.moto_frete_api.exception.entities.frete;

public class SolicitanteDoFreteNaoPodeSerNullException extends RuntimeException{

    public SolicitanteDoFreteNaoPodeSerNullException() {
    }

    public SolicitanteDoFreteNaoPodeSerNullException(String message) {
        super(message);
    }
}
