package com.example.motofrete.dto;
import jakarta.validation.constraints.*;

public class AtualizarLocalizacaoDTO {
  @NotNull public Double latitude;
  @NotNull public Double longitude;
}
