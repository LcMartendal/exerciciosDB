package com.example.motofrete.domain.dto.usuario;

import com.example.motofrete.domain.entity.usuario.RoleUsuario;

public record DadosResponseUsuarioDTO(

        Long id,

        String login,

//        String senha_hash,

        String nome,

        RoleUsuario role
) {
}
