package com.example.motofrete.exception.entities.frete;

public class FreteNaoPodeSerConcluidoException extends RuntimeException{
    public FreteNaoPodeSerConcluidoException() {
    }

    public FreteNaoPodeSerConcluidoException(String message) {
        super(message);
    }
}
