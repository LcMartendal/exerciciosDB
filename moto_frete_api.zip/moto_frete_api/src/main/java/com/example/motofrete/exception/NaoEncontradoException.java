package com.example.motofrete.exception;

public class NaoEncontradoException extends RuntimeException{

    public NaoEncontradoException() {
    }

    public NaoEncontradoException(String message) {
        super(message);
    }
}
