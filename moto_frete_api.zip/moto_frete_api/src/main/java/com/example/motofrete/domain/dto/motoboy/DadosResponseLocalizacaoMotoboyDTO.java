package com.example.motofrete.domain.dto.motoboy;

import com.example.motofrete.domain.entity.usuario.Usuario;

public record DadosResponseLocalizacaoMotoboyDTO(

        Usuario usuario,

        Long id,

        Double latitude,

        Double longitude

) {
}
