package com.example.motofrete.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.Map;

@FeignClient(name = "geocodeClient", url = "${maps.google.geocode_url}")
public interface GeocodeClient {
  @GetMapping
  Map geocode(@RequestParam Map<String,String> params);
}
