package com.example.motofrete.dto.usuario;

import com.example.motofrete.entity.usuario.RoleUsuario;
import jakarta.validation.constraints.Email;
import org.springframework.data.domain.Page;

public record ListaUsuariosResponseDTO(

        String message,
        Page<DadosResponseUsuarioDTO> usuarios

) {}
