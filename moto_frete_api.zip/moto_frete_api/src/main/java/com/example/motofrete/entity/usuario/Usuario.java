package com.example.motofrete.entity.usuario;

import com.example.motofrete.dto.usuario.DadosRegistarUsuarioDTO;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

@Entity
@Table(name = "usuario")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Usuario implements UserDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique=true, nullable=false)
    private String login;

    private String senha_hash;

    private String nome;

    @Column(nullable=false)
    @Enumerated(EnumType.STRING)
    private RoleUsuario role;

    private LocalDateTime createdAt = LocalDateTime.now();

    @Column(name = "cpf_ou_cnpj", unique = true)
    private String cpfOuCnpj;

    private LocalDate dt_nascimento;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {

        if(role == RoleUsuario.ADMIN){
            return List.of(new SimpleGrantedAuthority("MOTOBOY"),
                    new SimpleGrantedAuthority("SOLICITANTE_FRETE"),
                    new SimpleGrantedAuthority("ADMIN"));

        }else if(role == RoleUsuario.MOTOBOY){
            return List.of(new SimpleGrantedAuthority("MOTOBOY"));
        }

        return List.of(new SimpleGrantedAuthority("SOLICITANTE_FRETE"));
    }

    @Override
    public String getPassword() {
        return this.senha_hash;
    }

    @Override
    public String getUsername() {
        return this.login;
    }

    public Usuario(DadosRegistarUsuarioDTO dados, String senha_hash) {
        this.login = dados.login();
        this.senha_hash = senha_hash;
        this.nome = dados.nome();
        this.cpfOuCnpj = dados.cpf_ou_cnpj();
        this.dt_nascimento = dados.dt_nascimento();
        this.role = RoleUsuario.valueOf(dados.role().toUpperCase());
    }
}
