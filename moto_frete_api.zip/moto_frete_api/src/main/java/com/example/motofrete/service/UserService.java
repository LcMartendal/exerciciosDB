package com.example.motofrete.service;
import com.example.motofrete.dto.CriarUsuarioDTO;
import com.example.motofrete.entity.User;
import com.example.motofrete.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {
  private final UserRepository repo;
  private final PasswordEncoder encoder;
  public UserService(UserRepository repo, PasswordEncoder encoder){ this.repo=repo; this.encoder=encoder; }

  public User create(CriarUsuarioDTO dto){
    User u = new User();
    u.setUsername(dto.username);
    u.setPassword(encoder.encode(dto.password));
    u.setNome(dto.nome);
    u.setRole(dto.role);
    return repo.save(u);
  }
  public List<User> list(){ return repo.findAll(); }
  public User get(Long id){ return repo.findById(id).orElseThrow(IllegalArgumentException::new); }
  public User update(Long id, CriarUsuarioDTO dto){ User u = get(id); u.setNome(dto.nome); if(dto.password!=null) u.setPassword(encoder.encode(dto.password)); return repo.save(u); }
  public void delete(Long id){ repo.deleteById(id); }
}
