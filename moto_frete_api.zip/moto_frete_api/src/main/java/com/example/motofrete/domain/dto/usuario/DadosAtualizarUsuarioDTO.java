package com.example.motofrete.domain.dto.usuario;

import com.example.motofrete.domain.entity.usuario.RoleUsuario;
import jakarta.validation.constraints.Email;

public record DadosAtualizarUsuarioDTO(

        @Email
        String login,

        String senha_hash,

        String nome,

        String role
//        RoleUsuario role

) {
}
