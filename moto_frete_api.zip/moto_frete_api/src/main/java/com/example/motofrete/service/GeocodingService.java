package com.example.motofrete.service;

import com.example.motofrete.dto.ors.Coordenada;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;

@Service
public class GeocodingService {

    @Value("${locationiq.api.key}")
    private String apiKey;

    private final WebClient webClient = WebClient.create("https://us1.locationiq.com");

    public Coordenada geocode(String endereco) {
        List<Map<String,Object>> resposta = webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path("/v1/search.php")
                        .queryParam("key", "pk.0714922108f937447de95a600667fd99")
                        .queryParam("q", endereco)
                        .queryParam("format", "json")
                        .queryParam("limit", 1)
                        .build())
                .retrieve()
                .bodyToMono(List.class)
                .block();

        if (resposta == null || resposta.isEmpty()) {
            throw new RuntimeException("Endereço não encontrado: " + endereco);
        }

        Map<String,Object> obj = resposta.get(0);
        double lat = Double.parseDouble((String)obj.get("lat"));
        double lng = Double.parseDouble((String)obj.get("lon"));
        return new Coordenada(lat, lng);
    }
}

