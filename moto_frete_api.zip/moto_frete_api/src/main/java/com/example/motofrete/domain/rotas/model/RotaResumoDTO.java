package com.example.motofrete.domain.rotas.model;

public record RotaResumoDTO(

        double distanciaKm,
        double duracaoMinutos,
        String polyline

) {}
