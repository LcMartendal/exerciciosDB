package com.example.motofrete.dto.google;
public class RouteDTO { public java.util.List<LegDTO> legs; }
