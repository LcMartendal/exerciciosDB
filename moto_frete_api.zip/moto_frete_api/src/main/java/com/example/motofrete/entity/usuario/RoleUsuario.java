package com.example.motofrete.entity.usuario;

public enum RoleUsuario {

    MOTOBOY,
    SOLICITANTE_FRETE,
    ADMIN

}
