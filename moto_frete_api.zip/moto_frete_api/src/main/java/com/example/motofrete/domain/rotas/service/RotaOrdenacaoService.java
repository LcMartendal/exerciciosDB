package com.example.motofrete.domain.rotas.service;

import com.example.motofrete.domain.rotas.FreteRota;
import com.example.motofrete.domain.rotas.PontoRota;
import com.example.motofrete.domain.rotas.TipoPonto;
import com.example.motofrete.domain.rotas.service.util.CalculadoraDistancia;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class RotaOrdenacaoService {

    /**
     * Ordena a rota garantindo:
     * - origem sempre antes do destino do mesmo frete
     * - melhor ordem (menor distância)
     */
    public List<PontoRota> ordenar(List<FreteRota> fretes) {

        List<PontoRota> pontos = new ArrayList<>();

        for (FreteRota frete : fretes) {
            pontos.add(frete.getOrigem());
            pontos.add(frete.getDestino());
        }

        List<List<PontoRota>> rotasValidas = new ArrayList<>();
        permutar(pontos, 0, rotasValidas);

        return rotasValidas.stream()
                .min(Comparator.comparingDouble(CalculadoraDistancia::distanciaTotal))
                .orElse(pontos);
    }

    /**
     * Gera permutações válidas
     */
    private void permutar(List<PontoRota> lista, int index, List<List<PontoRota>> resultado) {
        if (index == lista.size()) {
            if (rotaValida(lista)) {
                resultado.add(new ArrayList<>(lista));
            }
            return;
        }

        for (int i = index; i < lista.size(); i++) {
            trocar(lista, index, i);
            permutar(lista, index + 1, resultado);
            trocar(lista, index, i);
        }
    }

    private void trocar(List<PontoRota> lista, int i, int j) {
        PontoRota temp = lista.get(i);
        lista.set(i, lista.get(j));
        lista.set(j, temp);
    }

    /**
     * Regra-chave:
     * origem do frete sempre antes do destino
     */
    private boolean rotaValida(List<PontoRota> rota) {
        for (PontoRota p : rota) {
            if (p.getTipo() == TipoPonto.DESTINO) {
                boolean origemAntes = false;
                for (PontoRota anterior : rota) {
                    if (anterior == p) break;
                    if (anterior.getFreteId().equals(p.getFreteId())
                            && anterior.getTipo() == TipoPonto.ORIGEM) {
                        origemAntes = true;
                    }
                }
                if (!origemAntes) {
                    return false;
                }
            }
        }
        return true;
    }
}
