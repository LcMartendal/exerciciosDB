package com.example.motofrete.service;
import com.example.motofrete.client.OpenMeteoClient;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class WeatherService {
  private final OpenMeteoClient client;

  public WeatherService(OpenMeteoClient client){ this.client = client; }

  public boolean isRaining(double lat, double lon) {

    Map<String,String> params = new HashMap<>();

    params.put("latitude", Double.toString(lat));
    params.put("longitude", Double.toString(lon));
    params.put("hourly", "precipitation");
    params.put("forecast_days", "1");
    params.put("timezone", "UTC");

    Map resp = client.forecast(params);

    if (resp == null) return false;

    Map hourly = (Map) resp.get("hourly");

    if (hourly == null) return false;

    List prec = (List) hourly.get("precipitation");

    if (prec == null || prec.isEmpty()) return false;

    for (int i = 0; i < Math.min(3, prec.size()); i++) {

      double v = ((Number) prec.get(i)).doubleValue();

      if (v > 0.0) return true;

    }

    return false;
  }

}
