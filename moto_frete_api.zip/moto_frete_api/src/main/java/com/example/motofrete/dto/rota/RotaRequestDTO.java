package com.example.motofrete.dto.rota;

import java.util.List;

public record RotaRequestDTO(

        String origem,
        List<String> paradas,
        String destino

){}

