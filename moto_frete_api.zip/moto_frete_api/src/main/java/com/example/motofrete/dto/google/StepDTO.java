package com.example.motofrete.dto.google;
public class StepDTO { public DistanceDTO distance; public DurationDTO duration; public String html_instructions; }
