package com.example.motofrete.dto;

import jakarta.validation.constraints.NotNull;

public record AtualizarMotoboyDTO(

    String placa,

    String modelo,

    Integer ano

) {}
