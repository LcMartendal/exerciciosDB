package com.example.motofrete.exception.frete;

public class SolicitanteDoFreteNaoPodeSerNullException extends RuntimeException{

    public SolicitanteDoFreteNaoPodeSerNullException() {
    }

    public SolicitanteDoFreteNaoPodeSerNullException(String message) {
        super(message);
    }
}
