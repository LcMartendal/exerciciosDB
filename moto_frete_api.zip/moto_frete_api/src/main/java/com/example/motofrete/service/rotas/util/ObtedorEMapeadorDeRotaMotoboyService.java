package com.example.motofrete.service.rotas.util;

import com.example.motofrete.dto.rota.FreteRotaDTO;
import com.example.motofrete.dto.rota.PontoRota;
import com.example.motofrete.dto.rota.TipoPonto;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.entity.frete.Frete;
import com.example.motofrete.entity.frete.StatusFrete;
import com.example.motofrete.repository.FreteRepository;
import com.example.motofrete.service.rotas.RotaOrdenacaoService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ObtedorEMapeadorDeRotaMotoboyService {

    private final FreteRepository freteRepository;
    private final RotaOrdenacaoService rotaOrdenacaoService;

    public List<PontoRota> obterRotaMotoboy(Motoboy motoboy) {

        List<Frete> fretesAtivos =
                freteRepository.findByMotoboyAndStatus(
                        motoboy,
                        StatusFrete.ACEITO
                );

        List<FreteRotaDTO> fretesRota = fretesAtivos.stream()
                .map(this::mapearFrete)
                .toList();

        if (motoboy.getLatitude() == null || motoboy.getLongitude() == null) {
            throw new RuntimeException("Motoboy sem coordenadas");
        }

        if (fretesRota.isEmpty()) {
            return List.of(
                    new PontoRota(
                            null,
                            TipoPonto.ORIGEM,
                            motoboy.getLatitude(),
                            motoboy.getLongitude()
                    )
            );
        }


        return rotaOrdenacaoService.ordenarGreedy(
                new PontoRota(null, TipoPonto.ORIGEM, motoboy.getLatitude(), motoboy.getLongitude()),
                fretesRota);
    }

    private FreteRotaDTO mapearFrete(Frete frete) {

        Long id = frete.getId();

        return new FreteRotaDTO(
                id,
                new PontoRota(
                        id,
                        TipoPonto.ORIGEM,
                        frete.getOrigemLat(),
                        frete.getOrigemLng()
                ),
                new PontoRota(
                        id,
                        TipoPonto.DESTINO,
                        frete.getDestinoLat(),
                        frete.getDestinoLng()
                )
        );
    }
}
