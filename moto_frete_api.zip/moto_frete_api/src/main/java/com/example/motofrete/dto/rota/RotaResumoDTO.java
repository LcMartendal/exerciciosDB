package com.example.motofrete.dto.rota;

public record RotaResumoDTO(

        double distanciaKm,
        double duracaoMinutos,
        String polyline

) {}
