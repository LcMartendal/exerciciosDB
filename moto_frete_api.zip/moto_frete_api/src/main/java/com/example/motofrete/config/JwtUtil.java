package com.example.motofrete.config;

import java.time.Instant;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTVerificationException;

@Component
public class JwtUtil {

    @Value("${jwt.secret}")
    private String secret;

    // expiration in milliseconds (you can inject or compute)
    @Value("${jwt.expiration-ms}")
    private long expirationMs;

    // Generate token using Auth0 library
    public String generateToken(String username, String role) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(secret);
            Instant expInstant = Instant.now().plusMillis(expirationMs);
            Date expDate = Date.from(expInstant);

            return JWT.create()
                      .withIssuer("auth-api")
                      .withSubject(username)
                      .withClaim("role", role)
                      .withIssuedAt(Date.from(Instant.now()))
                      .withExpiresAt(expDate)
                      .sign(algorithm);
        } catch (JWTCreationException e) {
            throw new RuntimeException("Erro ao gerar token JWT", e);
        }
    }

    // Return subject (username)
    public String extractUsername(String token) {
        DecodedJWT jwt = verifyAndGetDecoded(token);
        return jwt.getSubject();
    }

    // Check expiration
    public boolean isTokenExpired(String token) {
        DecodedJWT jwt = verifyAndGetDecoded(token);
        Date exp = jwt.getExpiresAt();
        if (exp == null) return true;
        return exp.before(new Date());
    }

    // Validate token signature and expiration (returns true if valid)
    public boolean validateToken(String token) {
        try {
            verifyAndGetDecoded(token);
            return true;
        } catch (JWTVerificationException ex) {
            return false;
        }
    }

    // Helper: verify signature and return DecodedJWT (throws JWTVerificationException on failure)
    private DecodedJWT verifyAndGetDecoded(String token) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(secret);
            JWTVerifier verifier = JWT.require(algorithm)
                                      .withIssuer("auth-api")
                                      .build();
            // if token contains "Bearer " prefix, remove it:
            if (token.startsWith("Bearer ")) {
                token = token.substring(7);
            }
            return verifier.verify(token);
        } catch (JWTVerificationException ex) {
            // rethrow so callers can handle
            throw ex;
        }
    }
}

