package com.example.motofrete.exception.entities.frete;

public class FreteNaoDisponivelException extends RuntimeException{
    public FreteNaoDisponivelException() {
    }

    public FreteNaoDisponivelException(String message) {
        super(message);
    }
}
