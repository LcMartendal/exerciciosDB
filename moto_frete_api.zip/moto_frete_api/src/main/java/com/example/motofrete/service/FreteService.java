package com.example.motofrete.service;

import com.example.motofrete.dto.usuario.DadosResponseUsuarioDTO;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.entity.frete.Frete;
import com.example.motofrete.entity.frete.StatusFrete;
import com.example.motofrete.dto.frete.DadosFreteDTO;
import com.example.motofrete.dto.frete.DadosResponseFreteDTO;
import com.example.motofrete.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.exception.entities.frete.FreteNaoDisponivelException;
import com.example.motofrete.exception.entities.frete.FreteNaoPodeSerConcluidoException;
import com.example.motofrete.repository.MotoboyRepository;
import com.example.motofrete.repository.UsuarioRepository;
import com.example.motofrete.dto.rota.FreteRotaDTO;
import com.example.motofrete.dto.rota.PontoRota;
import com.example.motofrete.dto.rota.TipoPonto;
import com.example.motofrete.dto.rota.RotaResumoDTO;
import com.example.motofrete.service.rotas.RotaOrdenacaoService;
import com.example.motofrete.service.rotas.RotaService;
import com.example.motofrete.exception.entities.NaoEncontradoException;
import com.example.motofrete.exception.entities.frete.DadosOrigemOuDestinoNaoPodeSerNullException;
import com.example.motofrete.repository.FreteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class FreteService {

    private final FreteRepository freteRepository;
    private final RotaOrdenacaoService rotaOrdenacaoService;
    private final MotoboyRepository motoboyRepository;
    private final UsuarioRepository usuarioRepository;
    private final RotaService rotaService;

    @Value("${motofrete.tarifa-por-km}")
    private double tarifaKm;

//    @Value("${motofrete.aumento-chuva}")
//    private double aumentoChuva;

    public DadosResponseFreteDTO inserir(DadosFreteDTO dados) {

        Usuario usuario = usuarioRepository.findById(dados.criador_id())
                .orElseThrow(() -> new NaoEncontradoException("Usuário solicitante de frete não encontrado com id " + dados.criador_id()));

        if(dados.destino().isBlank() || dados.origem().isBlank()){
            throw new DadosOrigemOuDestinoNaoPodeSerNullException();
        }

        double[] coordenadasOrigem = rotaService.gerarCoordenadas(dados.origem());
        double[] coordenadasDestino = rotaService.gerarCoordenadas(dados.destino());

        Frete frete = new Frete(dados, StatusFrete.PENDENTE, usuario, coordenadasOrigem[1],
                coordenadasOrigem[0], coordenadasDestino[1], coordenadasDestino[0]);

        List<double[]> coordenadas = new ArrayList<>();

        coordenadas.add(coordenadasOrigem);
        coordenadas.add(coordenadasDestino);

        RotaResumoDTO resumo = rotaService.extrairResumoRota(rotaService.gerarRota(coordenadas));
        int casasDecimais = 3;

        if (resumo.distanciaKm() > 1000) { casasDecimais = 2; }

        BigDecimal distanciaKm = BigDecimal.valueOf(resumo.distanciaKm())
                .setScale(casasDecimais, RoundingMode.HALF_UP);

        frete.setValor(distanciaKm.doubleValue() * tarifaKm);
        frete.setDistanciaKm(distanciaKm.doubleValue());
        freteRepository.save(frete);

        return new DadosResponseFreteDTO(
                frete.getId(),
                frete.getCriador().getUsername(),
                frete.getCriador().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                dados.origem(),
                dados.destino(),
                frete.getDistanciaKm(),
                frete.getValor(),
                frete.getStatus()
        );
    }

    public Page<DadosResponseFreteDTO> listarPendentes(Pageable pageable) {

        return freteRepository.findByStatus(pageable, StatusFrete.PENDENTE)
                .map(frete -> new DadosResponseFreteDTO(
                        frete.getId(),
                        frete.getCriador().getUsername(),
                        frete.getCriador().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                        frete.getOrigemEndereco(),
                        frete.getDestinoEndereco(),
                        frete.getDistanciaKm(),
                        frete.getValor(),
                        frete.getStatus()
                ));
    }

    public Page<DadosResponseFreteDTO> listarProximos(Pageable pageable, DadosAtualizarLocalizacaoMotoboyDTO dados) {

        return freteRepository.listarFretesProximosPorRaio(pageable, dados.latitude(), dados.longitude(), "PENDENTE", 5.0 )
                .map(frete -> new DadosResponseFreteDTO(
                        frete.getId(),
                        frete.getCriador().getUsername(),
                        frete.getCriador().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                        frete.getOrigemEndereco(),
                        frete.getDestinoEndereco(),
                        frete.getDistanciaKm(),
                        frete.getValor(),
                        frete.getStatus()
                ));
    }

    public DadosResponseFreteDTO excluir(Long frete_id) {

        Frete frete = freteRepository.findById(frete_id)
                        .orElseThrow(() -> new NaoEncontradoException("Frete não encontrado com id " + frete_id));

        freteRepository.delete(frete);

        return new DadosResponseFreteDTO(
                frete.getId(),
                frete.getCriador().getUsername(),
                frete.getCriador().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                frete.getOrigemEndereco(),
                frete.getDestinoEndereco(),
                frete.getDistanciaKm(),
                frete.getValor(),
                frete.getStatus()
        );
    }

    public DadosResponseFreteDTO aceitar(Long freteId, Long motoboyId) {

        Frete frete = freteRepository.findById(freteId)
                .orElseThrow(() -> new NaoEncontradoException("Frete não encontrado com id " + freteId));

        Motoboy motoboy = motoboyRepository.findById(motoboyId)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboyId));

        if (frete.getStatus() != StatusFrete.PENDENTE){
            throw new FreteNaoDisponivelException("Frete não está disponivel");
        }

        frete.setMotoboy(motoboy);
        frete.setStatus(StatusFrete.ACEITO);


        freteRepository.save(frete);

        //recalcularRotaMotoboy(motoboy);

        return new DadosResponseFreteDTO(
                frete.getId(),
                frete.getCriador().getUsername(),
                frete.getCriador().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                frete.getOrigemEndereco(),
                frete.getDestinoEndereco(),
                frete.getDistanciaKm(),
                frete.getValor(),
                frete.getStatus()
        );
    }

    public DadosResponseFreteDTO concluir(Long id) {

        Frete frete = freteRepository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("Frete não encontrado com id " + id));

        if (frete.getStatus() != StatusFrete.ACEITO){
            throw new FreteNaoPodeSerConcluidoException("Frete ja concluido ou não pode ser");
        }
        frete.setStatus(StatusFrete.CONCLUIDO);
        freteRepository.save(frete);

        if (frete.getMotoboy() != null) {
            //recalcularRotaMotoboy(frete.getMotoboy());
        }

        return new DadosResponseFreteDTO(
                frete.getId(),
                frete.getCriador().getUsername(),
                frete.getCriador().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                frete.getOrigemEndereco(),
                frete.getDestinoEndereco(),
                frete.getDistanciaKm(),
                frete.getValor(),
                frete.getStatus()
        );

    }

//        public String mostrarRota(Long motoboyId) {
//
//        Motoboy motoboy = motoboyRepository.findById(motoboyId)
//                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboyId));
//
//        return rotaService.rotaMotoboy(motoboy.getId());
//    }

    public String  mostrarRota(Long motoboyId) {

        Motoboy motoboy = motoboyRepository.findById(motoboyId)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboyId));

        return rotaService.rotaMotoboy(motoboyId);
    }

    private List<PontoRota> obterRotaMotoboy(Motoboy motoboy) {

        List<Frete> fretesAtivos =
                freteRepository.findByMotoboyAndStatus(
                        motoboy,
                        StatusFrete.ACEITO
                );

        List<FreteRotaDTO> fretesRota = fretesAtivos.stream()
                .map(this::mapearFrete)
                .toList();

        return rotaOrdenacaoService.ordenarGreedy(
                new PontoRota(null, TipoPonto.ORIGEM, motoboy.getLatitude(), motoboy.getLongitude()),
                fretesRota);
    }


    private void recalcularRotaMotoboy(Motoboy motoboy) {

        List<PontoRota> rota = obterRotaMotoboy(motoboy);

        // hoje só imprime
        rota.forEach(p ->
                System.out.println(
                        p.tipo() + " | Frete " + p.freteId()
                )
        );
    }

    private void recalcularRotaMotoboyORS(Motoboy motoboy) {
        List<PontoRota> rota = obterRotaMotoboy(motoboy);

        // hoje só imprime
        rota.forEach(p ->{

            String endereco = rotaService.obterEndereco(p.latitude(), p.longitude());
            System.out.println(
                    p.tipo() + " | Frete " + p.freteId()
            );

        });

    }

    private FreteRotaDTO mapearFrete(Frete frete) {

        Long id = frete.getId();

        return new FreteRotaDTO(
                id,
                new PontoRota(
                        id,
                        TipoPonto.ORIGEM,
                        frete.getOrigemLat(),
                        frete.getOrigemLng()
                ),
                new PontoRota(
                        id,
                        TipoPonto.DESTINO,
                        frete.getDestinoLat(),
                        frete.getDestinoLng()
                )
        );
    }

    private RotaResumoDTO extrairResumoRota(Map<String, Object> rotaORS) {

        if (rotaORS == null || !rotaORS.containsKey("routes")) {
            return null;
        }

        List<Map<String, Object>> routes =
                (List<Map<String, Object>>) rotaORS.get("routes");

        if (routes.isEmpty()) {
            return null;
        }

        Map<String, Object> route = routes.get(0);

        Map<String, Object> summary =
                (Map<String, Object>) route.get("summary");

        double distanciaMetros =
                ((Number) summary.get("distance")).doubleValue();

        double duracaoSegundos =
                ((Number) summary.get("duration")).doubleValue();

        String polyline = (String) route.get("geometry");

        return new RotaResumoDTO(
                distanciaMetros / 1000.0, // km
                duracaoSegundos / 60.0,   // minutos
                polyline
        );
    }

//
//    private FreteRota mapearFrete(Frete frete) {
//
//        Long id = frete.getId();
//
//        boolean mostrarOrigem =
//                frete.getStatus() == StatusFrete.ACEITO;
//
//        boolean mostrarDestino =
//                frete.getStatus() == StatusFrete.ACEITO ||
//                        frete.getStatus() == StatusFrete.COLETADO ||
//                        frete.getStatus() == StatusFrete.EM_ANDAMENTO;
//
//        PontoRota origem = mostrarOrigem
//                ? new PontoRota(id, TipoPonto.ORIGEM,
//                frete.getOrigemLat(), frete.getOrigemLng())
//                : null;
//
//        PontoRota destino = mostrarDestino
//                ? new PontoRota(id, TipoPonto.DESTINO,
//                frete.getDestinoLat(), frete.getDestinoLng())
//                : null;
//
//        return new FreteRota(id, origem, destino);
//    }


}
