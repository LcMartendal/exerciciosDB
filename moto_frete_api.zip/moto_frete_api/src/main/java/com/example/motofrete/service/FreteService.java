package com.example.motofrete.service;
import com.example.motofrete.dto.CriarFreteDTO;
import com.example.motofrete.entity.*;
import com.example.motofrete.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FreteService {
  private final FreteRepository freteRepo;
  private final RotaService rotaService;
  private final WeatherService weatherService;
  private final MotoboyRepository motoboyRepo;

  @Value("${motofrete.tarifa-por-km}") private double tarifaKm;
  @Value("${motofrete.aumento-chuva}") private double aumentoChuva;

  public FreteService(FreteRepository freteRepo, RotaService rotaService, WeatherService weatherService, MotoboyRepository motoboyRepo){
    this.freteRepo = freteRepo; this.rotaService = rotaService; this.weatherService = weatherService; this.motoboyRepo = motoboyRepo;
  }

  public Frete create(CriarFreteDTO dto, User criador){
    double[] orig = rotaService.geocode(dto.origem);
    double[] dest = rotaService.geocode(dto.destino);

    String originStr = orig[0] + "," + orig[1];
    String destStr = dest[0] + "," + dest[1];
    double distancia = rotaService.calcularDistanciaComParadas(originStr, destStr, null);

    boolean chovendo = weatherService.isRaining(orig[0], orig[1]);

    double valor = distancia * tarifaKm;
    if (chovendo) valor *= aumentoChuva;

    Frete f = new Frete();
    f.setCriador(criador);
    f.setOrigemEndereco(dto.origem);
    f.setOrigemLat(orig[0]); f.setOrigemLng(orig[1]);
    f.setDestinoEndereco(dto.destino);
    f.setDestinoLat(dest[0]); f.setDestinoLng(dest[1]);
    f.setDistanciaKm(distancia);
    f.setValor(Math.round(valor*100.0)/100.0);
    f.setStatus("PENDENTE");
    return freteRepo.save(f);
  }

  public List<Frete> list(){ return freteRepo.findAll(); }
  public List<Frete> listPendentesNearby(double lat, double lng){ return freteRepo.findByStatusOrderByDistance("PENDENTE", lat, lng); }

  public Frete aceitar(Long freteId, Long motoboyId){
    Frete f = freteRepo.findById(freteId).orElseThrow(IllegalArgumentException::new);
    Motoboy m = motoboyRepo.findById(motoboyId).orElseThrow(IllegalArgumentException::new);
    f.setMotoboy(m); f.setStatus("ACEITO");
    return freteRepo.save(f);
  }

  public Frete concluir(Long id){ Frete f = freteRepo.findById(id).orElseThrow(IllegalArgumentException::new); f.setStatus("ENTREGUE"); return freteRepo.save(f); }
}
