package com.example.motofrete.dto.google;
import java.util.List;
public class GoogleDirectionsResponseDTO { public java.util.List<RouteDTO> routes; }
