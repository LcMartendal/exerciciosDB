package com.example.motofrete.domain.dto.motoboy;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosAtualizarMotoboyDTO(

        @NotBlank
        String modelo_moto,

        @NotBlank
        String placa,

        @NotNull
        int ano
) {
}
