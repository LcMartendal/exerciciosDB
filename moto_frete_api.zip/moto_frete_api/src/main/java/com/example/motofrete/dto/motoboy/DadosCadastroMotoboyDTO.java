package com.example.motofrete.dto.motoboy;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosCadastroMotoboyDTO(

        @NotNull
        Long usuario_id,

        @NotBlank
        String modelo_veiculo,

        @NotBlank
        String placa_veiculo,

        @NotNull
        int ano_veiculo

) {
}
