package com.example.motofrete.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
public class ResponseException {
    private String message;
    private Integer statusCode;
    private Long timestamp;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<String> invalidFields;

    public ResponseException(String message, Integer statusCode, Long timestamp) {
        this.message = message;
        this.statusCode = statusCode;
        this.timestamp = timestamp;
    }
}
