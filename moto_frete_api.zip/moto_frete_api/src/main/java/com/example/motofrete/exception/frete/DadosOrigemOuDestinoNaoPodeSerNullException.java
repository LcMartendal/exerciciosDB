package com.example.motofrete.exception.frete;

public class DadosOrigemOuDestinoNaoPodeSerNullException extends RuntimeException{
    public DadosOrigemOuDestinoNaoPodeSerNullException() {
    }

    public DadosOrigemOuDestinoNaoPodeSerNullException(String message) {
        super(message);
    }
}
