package com.example.motofrete.domain.repository;

import com.example.motofrete.domain.entity.Motoboy;
import com.example.motofrete.domain.entity.frete.Frete;
import com.example.motofrete.domain.entity.frete.StatusFrete;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.management.relation.RoleStatus;
import java.util.List;

@Repository
public interface FreteRepository extends JpaRepository<Frete, Long> {

    List<Frete> findByStatus(StatusFrete status);

    @Query(
            value = """
    SELECT *
    FROM (
        SELECT *,
        (6371 * acos(
            cos(radians(:lat)) * cos(radians(origem_lat)) *
            cos(radians(origem_lng) - radians(:lng)) +
            sin(radians(:lat)) * sin(radians(origem_lat))
        )) AS distancia
        FROM frete
        WHERE status = :status
    ) f
    WHERE distancia <= :raio
    ORDER BY distancia ASC
    """,
            nativeQuery = true
    )
    List<Frete> listarFretesProximosPorRaio(
            @Param("lat") Double latitude,
            @Param("lng") Double longitude,
            @Param("status") String status,
            @Param("raio") Double raioKm
    );

    List<Frete> findByMotoboyAndStatus(Motoboy motoboy, StatusFrete status);

}
