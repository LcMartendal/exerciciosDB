package com.example.motofrete.exception.usuario;

public class UsuarioNaoExisteException extends RuntimeException{

    public UsuarioNaoExisteException() {
    }

    public UsuarioNaoExisteException(String message) {
        super(message);
    }
}
