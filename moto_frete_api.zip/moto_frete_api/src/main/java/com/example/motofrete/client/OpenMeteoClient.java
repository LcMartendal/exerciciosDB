package com.example.motofrete.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import java.util.Map;

@FeignClient(name = "openMeteo", url = "${weather.open-meteo.url}")
public interface OpenMeteoClient {
  @GetMapping
  Map forecast(@RequestParam Map<String,String> params);
}
