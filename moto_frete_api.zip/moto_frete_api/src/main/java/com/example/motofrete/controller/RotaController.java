package com.example.motofrete.controller;
import com.example.motofrete.dto.RotaRequestDTO;
import com.example.motofrete.service.RotaService;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/rotas")
public class RotaController {
  private final RotaService rotaService;
  public RotaController(RotaService rotaService){ this.rotaService = rotaService; }

    @PostMapping("/calcular")
    public Map<String, Object> calcular(@Valid @RequestBody RotaRequestDTO dto) {
        double km = rotaService.calcularDistanciaComParadas(dto.origem, dto.destino, dto.paradas);

        Map<String, Object> response = new HashMap<>();
        response.put("distancia_km", Math.round(km * 100.0) / 100.0);

        return response;
    }
}
