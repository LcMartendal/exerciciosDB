package com.example.motofrete.controller;

import com.example.motofrete.domain.rotas.model.RotaRequest;
import com.example.motofrete.domain.rotas.service.RotaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/rota")
public class RotaController {

    @Autowired
    private RotaService service;

    @PostMapping("/rota")
    public ResponseEntity<?> criarRota(@RequestBody RotaRequest request) {

        List<double[]> coordenadas = new ArrayList<>();

        double[] origem = service.gerarCoordenadas(request.getOrigem());
        if (origem == null) return ResponseEntity.badRequest().body("Endereço de origem inválido");
        coordenadas.add(origem);

        if (request.getParadas() != null) {
            for (String parada : request.getParadas()) {
                double[] paradaCoord = service.gerarCoordenadas(parada);
                if (paradaCoord == null) {
                    return ResponseEntity.badRequest()
                            .body("Parada inválida: " + parada);
                }
                coordenadas.add(paradaCoord);
            }
        }

        double[] destino = service.gerarCoordenadas(request.getDestino());
        if (destino == null) return ResponseEntity.badRequest().body("Endereço de destino inválido");
        coordenadas.add(destino);

        Map<String, Object> rota = service.gerarRota(coordenadas);

        return ResponseEntity.ok(rota);
    }
}
