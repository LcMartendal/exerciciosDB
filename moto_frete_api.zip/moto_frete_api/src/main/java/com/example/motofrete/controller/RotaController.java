package com.example.motofrete.controller;

import com.example.motofrete.dto.rota.RotaRequestDTO;
import com.example.motofrete.service.rotas.ORSService;
import com.example.motofrete.service.rotas.RotaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/rota")
public class RotaController {

    @Autowired
    private RotaService service;
    @Autowired
    private ORSService orsService;

    @PostMapping("/rota")
    public ResponseEntity<?> criarRota(@RequestBody RotaRequestDTO request) {

        List<double[]> coordenadas = new ArrayList<>();

        double[] origem = service.gerarCoordenadas(request.origem());
        if (origem == null) return ResponseEntity.badRequest().body("Endereço de origem inválido");
        coordenadas.add(origem);

        if (request.paradas() != null) {
            for (String parada : request.paradas()) {
                try {
                    double[] paradaCoord = service.gerarCoordenadas(parada);

                    if (paradaCoord == null) {
                        return ResponseEntity.badRequest()
                                .body("Não foi possível geocodificar a parada: " + parada);
                    }

                    coordenadas.add(paradaCoord);

                } catch (Exception e) {
                    e.printStackTrace(); // 👈 ESSENCIAL AGORA
                    return ResponseEntity.internalServerError()
                            .body("Erro ao processar parada: " + parada);
                }
            }
    }

        double[] destino = service.gerarCoordenadas(request.destino());
        if (destino == null) return ResponseEntity.badRequest().body("Endereço de destino inválido");
        coordenadas.add(destino);

        //Map<String, Object> rota = service.gerarRota(coordenadas);
        Map<String, Object>   rota = orsService.calcularRota(coordenadas);

        return ResponseEntity.ok(rota);
    }

    @PostMapping("/motoboy/{id}")
    public ResponseEntity criarRotaMotoboy(@RequestParam Long id) {

        Map<String, Object> rota = service.criarInstrucoesDeRota(id);

        return ResponseEntity.ok(rota);
    }

    @PostMapping("/rota/rota")
    public ResponseEntity criar(@RequestBody List<String> paradas) {

        List<double[]> coordenadas = new ArrayList<>();

        if (paradas != null) {
            for (String parada : paradas) {
                try {
                    double[] paradaCoord = service.gerarCoordenadas(parada);

                    if (paradaCoord == null) {
                        return ResponseEntity.badRequest()
                                .body("Não foi possível geocodificar a parada: " + parada);
                    }

                    coordenadas.add(paradaCoord);

                } catch (Exception e) {
                    e.printStackTrace(); // 👈 ESSENCIAL AGORA
                    return ResponseEntity.internalServerError()
                            .body("Erro ao processar parada: " + parada);
                }
            }
        }

        Map<String, Object> rota = orsService.calcularRota(coordenadas);

        return ResponseEntity.ok(rota);
    };
}
