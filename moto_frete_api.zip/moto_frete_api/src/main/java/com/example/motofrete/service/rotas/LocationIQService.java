package com.example.motofrete.service.rotas;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Map;

@Service
public class LocationIQService {

    private static final String LOCATIONIQ_URL
            = "https://us1.locationiq.com/v1/search";

    private static final String API_KEY =
            "pk.0714922108f937447de95a600667fd99";

    private final RestTemplate restTemplate = new RestTemplate();

    public double[] gerarCoordenadas(String endereco) {

        String url = UriComponentsBuilder
                .fromHttpUrl(LOCATIONIQ_URL)
                .queryParam("key", API_KEY)
                .queryParam("q", endereco)
                .queryParam("format", "json")
                .queryParam("limit", 1)
                .toUriString();

        ResponseEntity<List<Map<String, Object>>> response =
                restTemplate.exchange(
                        url,
                        HttpMethod.GET,
                        null,
                        new ParameterizedTypeReference<>() {}
                );

        if (response.getBody() == null || response.getBody().isEmpty()) {
            throw new RuntimeException("Endereço não encontrado");
        }

        Map<String, Object> first = response.getBody().get(0);

        double lon = Double.parseDouble(first.get("lon").toString());
        double lat = Double.parseDouble(first.get("lat").toString());

        return new double[]{lon, lat};
    }

}
