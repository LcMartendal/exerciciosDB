package com.example.motofrete.dto.usuario;

import com.example.motofrete.annotation.cpfOuCnpj.CpfOuCnpjValido;
import com.example.motofrete.annotation.dtNascimento.DtNascimentoObrigatorioParaCpf;
import com.example.motofrete.entity.usuario.RoleUsuario;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.time.LocalDate;

@DtNascimentoObrigatorioParaCpf
public record DadosRegistarUsuarioDTO(

        @Email
        @NotBlank
        String login,

        @NotBlank
        String senha_hash,

        @NotBlank
        String nome,

        @NotNull
        @CpfOuCnpjValido
        String cpf_ou_cnpj,

        LocalDate dt_nascimento,

        @NotBlank
        String role
) {
}
