package com.example.motofrete.dto.usuario;

import com.example.motofrete.entity.usuario.RoleUsuario;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosRegistarUsuarioDTO(

        @Email
        @NotBlank
        String login,

        @NotBlank
        String senha_hash,

        @NotBlank
        String nome,

        @NotNull
        RoleUsuario role
) {
}
