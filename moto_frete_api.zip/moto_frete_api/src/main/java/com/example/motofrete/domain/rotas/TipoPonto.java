package com.example.motofrete.domain.rotas;

public enum TipoPonto {
    ORIGEM,
    DESTINO
}
