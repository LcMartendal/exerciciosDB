package com.example.motofrete.exception.entities.usuario;

public class LoginJaExisteException extends RuntimeException{

    public LoginJaExisteException() { super("Login já existe"); }

    public LoginJaExisteException(String message) {
        super(message);
    }
}
