package com.example.motofrete.exception.motoboy;

public class MotoboyNaoExisteException extends RuntimeException{

    public MotoboyNaoExisteException() {
    }

    public MotoboyNaoExisteException(String message) {
        super(message);
    }
}
