package com.example.motofrete.controller;
import com.example.motofrete.dto.CriarUsuarioDTO;
import com.example.motofrete.entity.User;
import com.example.motofrete.service.UserService;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UserController {
  private final UserService service;
  public UserController(UserService service){ this.service = service; }

  @PostMapping public User create(@Valid @RequestBody CriarUsuarioDTO dto){ return service.create(dto); }
  @GetMapping public List<User> list(){ return service.list(); }
  @GetMapping("/{id}") public User get(@PathVariable Long id){ return service.get(id); }
  @PutMapping("/{id}") public User update(@PathVariable Long id, @Valid @RequestBody CriarUsuarioDTO dto){ return service.update(id,dto); }
  @DeleteMapping("/{id}") public void delete(@PathVariable Long id){ service.delete(id); }
}
