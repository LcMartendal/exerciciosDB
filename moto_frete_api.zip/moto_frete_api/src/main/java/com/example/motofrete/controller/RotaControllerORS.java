package com.example.motofrete.controller;

import com.example.motofrete.dto.ors.RotaRequest;
import com.example.motofrete.dto.ors.RotaResponse;
import com.example.motofrete.service.RotaServiceORS;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/rotas")
public class RotaControllerORS {

    private final RotaServiceORS routeService;

    public RotaControllerORS(RotaServiceORS routeService) {
        this.routeService = routeService;
    }

    @PostMapping("/rota")
    public ResponseEntity<?> criarRota(@RequestBody RotaRequest request) {

        List<double[]> coordenadas = new ArrayList<>();

        double[] origem = routeService.geocode(request.getOrigem());
        if (origem == null) return ResponseEntity.badRequest().body("Endereço de origem inválido");
        coordenadas.add(origem);

        if (request.getParadas() != null) {
            for (String parada : request.getParadas()) {
                double[] paradaCoord = routeService.geocode(parada);
                if (paradaCoord == null) {
                    return ResponseEntity.badRequest()
                            .body("Parada inválida: " + parada);
                }
                coordenadas.add(paradaCoord);
            }
        }

        double[] destino = routeService.geocode(request.getDestino());
        if (destino == null) return ResponseEntity.badRequest().body("Endereço de destino inválido");
        coordenadas.add(destino);

        Map<String, Object> rota = routeService.generateRoute(coordenadas);

        return ResponseEntity.ok(rota);
    }
}
