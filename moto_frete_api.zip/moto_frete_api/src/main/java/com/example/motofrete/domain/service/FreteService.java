package com.example.motofrete.domain.service;

import com.example.motofrete.domain.entity.Motoboy;
import com.example.motofrete.domain.entity.frete.Frete;
import com.example.motofrete.domain.entity.frete.StatusFrete;
import com.example.motofrete.domain.dto.frete.DadosFreteDTO;
import com.example.motofrete.domain.dto.frete.DadosResponseFreteDTO;
import com.example.motofrete.domain.dto.motoboy.DadosLocalizacaoMotoboyDTO;
import com.example.motofrete.domain.repository.MotoboyRepository;
import com.example.motofrete.domain.rotas.FreteRota;
import com.example.motofrete.domain.rotas.PontoRota;
import com.example.motofrete.domain.rotas.TipoPonto;
import com.example.motofrete.domain.rotas.service.RotaOrdenacaoService;
import com.example.motofrete.exception.frete.DadosOrigemOuDestinoNaoPodeSerNullException;
import com.example.motofrete.exception.frete.FreteNaoExisteException;
import com.example.motofrete.exception.frete.SolicitanteDoFreteNaoPodeSerNullException;
import com.example.motofrete.domain.repository.FreteRepository;
import com.example.motofrete.exception.motoboy.MotoboyNaoExisteException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.List;

@Service
public class FreteService {

    @Autowired
    private FreteRepository freteRepository;

    @Autowired
    private RotaOrdenacaoService rotaOrdenacaoService;

    @Autowired
    private MotoboyRepository motoboyRepository;

    @Value("${motofrete.tarifa-por-km}")
    private double tarifaKm;

    @Value("${motofrete.aumento-chuva}")
    private double aumentoChuva;

    public DadosResponseFreteDTO inserir(DadosFreteDTO dados) {

        if(dados.criador() == null){
            throw new SolicitanteDoFreteNaoPodeSerNullException();
        }

        if(dados.destino().isBlank() || dados.origem().isBlank()){
            throw new DadosOrigemOuDestinoNaoPodeSerNullException();
        }

        Frete frete = new Frete(dados, StatusFrete.PENDENTE);

        freteRepository.save(frete);

        //tenho que calcular distancia e valor do frete
        return new DadosResponseFreteDTO(dados.criador(), dados.origem(),
                dados.destino(), frete.getDistanciaKm(),
                frete.getValor(), frete.getStatus());
    }

    public List<Frete> listarPendentes() {

        return freteRepository.findByStatus(StatusFrete.PENDENTE);
    }

    public List<Frete> listarProximos(DadosLocalizacaoMotoboyDTO dados) {

        return freteRepository.listarFretesProximosPorRaio(dados.latitude(), dados.longitude(), StatusFrete.PENDENTE, 5.0 );
    }

    public DadosResponseFreteDTO excluir(Long frete_id) {

        Frete frete = freteRepository.findById(frete_id)
                        .orElseThrow(FreteNaoExisteException::new);

        freteRepository.delete(frete);

        return new DadosResponseFreteDTO(frete.getCriador(), frete.getOrigemEndereco(), frete.getDestinoEndereco(),
                frete.getDistanciaKm(), frete.getValor(), frete.getStatus());
    }

    public DadosResponseFreteDTO aceitar(Long freteId, Long motoboyId) {

        Frete frete = freteRepository.findById(freteId)
                .orElseThrow(FreteNaoExisteException::new);

        Motoboy motoboy = motoboyRepository.findById(motoboyId)
                .orElseThrow(MotoboyNaoExisteException::new);

        frete.setMotoboy(motoboy);
        frete.setStatus(StatusFrete.ACEITO);

        freteRepository.save(frete);

        recalcularRotaMotoboy(motoboy);

        return new DadosResponseFreteDTO(frete.getCriador(), frete.getOrigemEndereco(), frete.getDestinoEndereco(),
                frete.getDistanciaKm(), frete.getValor(), frete.getStatus());
    }

    public Frete concluir(Long id) {

        Frete f = freteRepository.findById(id)
                .orElseThrow(IllegalArgumentException::new);

        f.setStatus(StatusFrete.CONCLUIDO);
        freteRepository.save(f);

        if (f.getMotoboy() != null) {
            recalcularRotaMotoboy(f.getMotoboy());
        }

        return f;
    }

    public List<PontoRota> mostrarRota(Long motoboyId) {

        Motoboy motoboy = motoboyRepository.findById(motoboyId)
                .orElseThrow(MotoboyNaoExisteException::new);

        return obterRotaMotoboy(motoboy);
    }

    private List<PontoRota> obterRotaMotoboy(Motoboy motoboy) {

        List<Frete> fretesAtivos =
                freteRepository.findByMotoboyAndStatus(
                        motoboy,
                        StatusFrete.ACEITO
                );

        List<FreteRota> fretesRota = fretesAtivos.stream()
                .map(this::mapearFrete)
                .toList();

        return rotaOrdenacaoService.ordenar(fretesRota);
    }


    private void recalcularRotaMotoboy(Motoboy motoboy) {

        List<PontoRota> rota = obterRotaMotoboy(motoboy);

        // hoje só imprime
        rota.forEach(p ->
                System.out.println(
                        p.getTipo() + " | Frete " + p.getFreteId()
                )
        );
    }


    private FreteRota mapearFrete(Frete frete) {

        Long id = frete.getId();

        return new FreteRota(
                id,
                new PontoRota(
                        id,
                        TipoPonto.ORIGEM,
                        frete.getOrigemLat(),
                        frete.getOrigemLng()
                ),
                new PontoRota(
                        id,
                        TipoPonto.DESTINO,
                        frete.getDestinoLat(),
                        frete.getDestinoLng()
                )
        );
    }

//    private FreteRota mapearFrete(Frete frete) {
//
//        Long id = frete.getId();
//
//        boolean mostrarOrigem =
//                frete.getStatus() == StatusFrete.ACEITO;
//
//        boolean mostrarDestino =
//                frete.getStatus() == StatusFrete.ACEITO ||
//                        frete.getStatus() == StatusFrete.COLETADO ||
//                        frete.getStatus() == StatusFrete.EM_ANDAMENTO;
//
//        PontoRota origem = mostrarOrigem
//                ? new PontoRota(id, TipoPonto.ORIGEM,
//                frete.getOrigemLat(), frete.getOrigemLng())
//                : null;
//
//        PontoRota destino = mostrarDestino
//                ? new PontoRota(id, TipoPonto.DESTINO,
//                frete.getDestinoLat(), frete.getDestinoLng())
//                : null;
//
//        return new FreteRota(id, origem, destino);
//    }


}
