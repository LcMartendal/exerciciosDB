package com.example.motofrete.domain.dto.motoboy;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizarLocalizacaoMotoboyDTO(

        @NotNull
        Double latitude,

        @NotNull
        Double longitude

) {
}
