package com.example.motofrete.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Date;

@RestControllerAdvice
public class RestControllerAdviceHandler {

    @ExceptionHandler(NaoEncontradoException.class)
    public ResponseEntity<String> handlerNotFound(Exception ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ex.getLocalizedMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResponseException> handle(MethodArgumentNotValidException ex) {

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ResponseException());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResponseException> handle(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                new ResponseException(
                        "Erro interno da aplicação. Tente novamente mais tarde ou entre em contato com o time de suporte.",
                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        new Date().getTime()
                )
        );
    }

}
