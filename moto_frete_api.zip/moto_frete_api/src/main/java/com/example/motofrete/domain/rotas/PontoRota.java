package com.example.motofrete.domain.rotas;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PontoRota {

    private Long freteId;
    private TipoPonto tipo;
    private double latitude;
    private double longitude;

}
