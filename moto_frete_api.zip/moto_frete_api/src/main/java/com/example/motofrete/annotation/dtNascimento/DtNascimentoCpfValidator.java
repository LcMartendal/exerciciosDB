package com.example.motofrete.annotation.dtNascimento;

import com.example.motofrete.dto.usuario.DadosRegistarUsuarioDTO;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class DtNascimentoCpfValidator implements ConstraintValidator<DtNascimentoObrigatorioParaCpf, DadosRegistarUsuarioDTO> {

    @Override
    public boolean isValid(
            DadosRegistarUsuarioDTO dto,
            ConstraintValidatorContext context) {

        if (dto == null) return true;

        String doc = dto.cpf_ou_cnpj();
        if (doc == null) return true;

        String numeros = doc.replaceAll("\\D", "");

        // CPF → dt_nascimento obrigatório
        if (numeros.length() == 11 && dto.dt_nascimento() == null) {

            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(
                            "dt_nascimento é obrigatória quando CPF é informado")
                    .addPropertyNode("dt_nascimento")
                    .addConstraintViolation();

            return false;
        }

        return true;
    }
}
