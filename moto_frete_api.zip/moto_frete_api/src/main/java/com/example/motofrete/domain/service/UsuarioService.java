package com.example.motofrete.domain.service;

import com.example.motofrete.domain.entity.usuario.Usuario;
import com.example.motofrete.domain.dto.usuario.DadosAtualizarUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosLoginUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosResponseUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosUsuarioDTO;
import com.example.motofrete.exception.usuario.LoginJaExisteException;
import com.example.motofrete.exception.usuario.UsuarioNaoExisteException;
import com.example.motofrete.infra.security.TokenService;
import com.example.motofrete.domain.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository repository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private TokenService tokenService;

    public DadosResponseUsuarioDTO registro(DadosUsuarioDTO dados) {

        if (repository.existsByLogin(dados.login())){ throw new LoginJaExisteException(); }

        Usuario usuario = new Usuario(dados, new BCryptPasswordEncoder().encode(dados.senha_hash()));

        repository.save(usuario);

        return new DadosResponseUsuarioDTO(dados.login(), dados.senha_hash(), dados.nome(), dados.role());
    }

    public String login(DadosLoginUsuarioDTO dados) {

        if(!repository.existsByLogin(dados.login())){
            throw new UsuarioNaoExisteException();
        }

        var token_autenticacao = new UsernamePasswordAuthenticationToken(dados.login(), dados.senha_hash());
        var autenticado = authenticationManager.authenticate(token_autenticacao);

        return tokenService.gerarToken((Usuario) autenticado.getPrincipal());
    }

    public DadosResponseUsuarioDTO atualizar(Long id, DadosAtualizarUsuarioDTO dados) {

        Usuario usuario = repository.findById(id)
                        .orElseThrow(UsuarioNaoExisteException::new);

        if (repository.existsByLogin(dados.login())){ throw new LoginJaExisteException(); }

        if (!dados.login().isBlank()){ usuario.setLogin(dados.login()); }

        if (!dados.senha_hash().isBlank()){ usuario.setSenha_hash(dados.senha_hash()); }

        if (!dados.nome().isBlank()){ usuario.setNome(dados.nome()); }

        if (dados.role() != null) { usuario.setRole(dados.role()); }

        repository.save(usuario);

        return new DadosResponseUsuarioDTO(usuario.getLogin(), usuario.getSenha_hash(),
                usuario.getNome(), usuario.getRole());
    }

    public List<Usuario> listarTodos() { return repository.findAll(); }

    public DadosResponseUsuarioDTO deletar(Long id) {

        Usuario usuario = repository.findById(id)
                .orElseThrow(UsuarioNaoExisteException::new);

        repository.delete(usuario);

        return new DadosResponseUsuarioDTO(usuario.getLogin(), usuario.getSenha_hash(),
                usuario.getNome(), usuario.getRole());
    }

}
