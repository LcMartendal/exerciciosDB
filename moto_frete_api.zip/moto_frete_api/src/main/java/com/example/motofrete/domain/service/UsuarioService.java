package com.example.motofrete.domain.service;

import com.example.motofrete.domain.entity.usuario.RoleUsuario;
import com.example.motofrete.domain.entity.usuario.Usuario;
import com.example.motofrete.domain.dto.usuario.DadosAtualizarUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosLoginUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosResponseUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosRegistarUsuarioDTO;
import com.example.motofrete.exception.NaoEncontradoException;
import com.example.motofrete.exception.usuario.LoginJaExisteException;
import com.example.motofrete.infra.security.TokenService;
import com.example.motofrete.domain.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository repository;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private TokenService tokenService;

    public DadosResponseUsuarioDTO registro(DadosRegistarUsuarioDTO dados) {

        if (repository.existsByLogin(dados.login())){ throw new LoginJaExisteException(); }

        Usuario usuario = new Usuario(dados, new BCryptPasswordEncoder().encode(dados.senha_hash()));

        repository.save(usuario);

        return new DadosResponseUsuarioDTO(usuario.getId(),usuario.getLogin(), usuario.getNome(), usuario.getRole());
    }


    public String login(DadosLoginUsuarioDTO dados) {
        if(!repository.existsByLogin(dados.login())){
            throw new NaoEncontradoException("Usuário " + dados.login() + " não existe.");
        }

        var tokenAutenticacao = new UsernamePasswordAuthenticationToken(dados.login(), dados.senha_hash());
        var autenticado = authenticationManager.authenticate(tokenAutenticacao);

        return tokenService.gerarToken((Usuario) autenticado.getPrincipal());
    }

    public DadosResponseUsuarioDTO atualizar(Long id, DadosAtualizarUsuarioDTO dados) {

        Usuario usuario = repository.findById(id)
                        .orElseThrow(() -> new NaoEncontradoException("Usuário não encontrado com id " + id));

        if (repository.existsByLogin(dados.login())){ throw new LoginJaExisteException(); }

        if (!dados.login().isBlank()){ usuario.setLogin(dados.login()); }

        if (!dados.senha_hash().isBlank()){ usuario.setSenha_hash(dados.senha_hash()); }

        if (!dados.nome().isBlank()){ usuario.setNome(dados.nome()); }

        if (dados.role() != null) {

            if (dados.role().equals(RoleUsuario.MOTOBOY.toString())){ usuario.setRole(RoleUsuario.MOTOBOY); }

            if (dados.role().equals(RoleUsuario.SOLICITANTE_FRETE.toString())){ usuario.setRole(RoleUsuario.SOLICITANTE_FRETE); }

            if (dados.role().equals(RoleUsuario.ADMIN.toString())){ usuario.setRole(RoleUsuario.ADMIN); }

        }

        repository.save(usuario);

        return new DadosResponseUsuarioDTO(usuario.getId(), usuario.getLogin(),
                usuario.getNome(), usuario.getRole());
    }

    public List<DadosResponseUsuarioDTO> listarTodos() {
        return repository.findAll()
                .stream()
                .map(u -> new DadosResponseUsuarioDTO(u.getId(), u.getLogin(), u.getNome(), u.getRole()))
                .toList();
    }

    public DadosResponseUsuarioDTO deletar(Long id) {

        Usuario usuario = repository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("Usuário não encontrado com id " + id));

        repository.delete(usuario);

        return new DadosResponseUsuarioDTO(usuario.getId(), usuario.getLogin(),
                usuario.getNome(), usuario.getRole());
    }

}
