package com.example.motofrete.domain.rotas.dto;

import java.util.List;

public record ORSReverseResponseDTO(

        List<Feature> features

) {

    public static class Feature {
        private Properties properties;
        public Properties getProperties(){
            return properties;
        }
    }

    public static class Properties {
        private String label;
        public String getLabel() {
            return label;
        }
    }
}
