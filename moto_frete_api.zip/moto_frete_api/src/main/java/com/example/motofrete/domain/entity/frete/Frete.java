package com.example.motofrete.domain.entity.frete;

import com.example.motofrete.domain.entity.Motoboy;
import com.example.motofrete.domain.entity.usuario.Usuario;
import com.example.motofrete.domain.dto.frete.DadosFreteDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "frete")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Frete {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Usuario criador;

    @ManyToOne
    private Motoboy motoboy;

    private String origemEndereco;
    private Double origemLat;
    private Double origemLng;

    private String destinoEndereco;
    private Double destinoLat;
    private Double destinoLng;

    private Double distanciaKm;

    private Double valor;

    @Enumerated(EnumType.STRING)
    private StatusFrete status;

    private LocalDateTime createdAt = LocalDateTime.now();

    public Frete(DadosFreteDTO dados, StatusFrete status, Usuario criador) {
        this.criador = criador;
        this.origemEndereco = dados.origem();
        this.destinoEndereco = dados.destino();
//        this.distanciaKm = dados.distanciaKm();
//        this.valor = dados.valor();
        this.status = status;
    }

    public Frete(DadosFreteDTO dados, StatusFrete status,
                 Usuario criador,Double origemLat,
                 Double origemLng, Double destinoLat, Double destinoLng) {

        this.criador = criador;
        this.origemEndereco = dados.origem();
        this.destinoEndereco = dados.destino();
        //       this.distanciaKm = dados.distanciaKm();
//      this.valor = dados.valor();
        this.status = status;
        this.origemLat = origemLat;
        this.origemLng = origemLng;
        this.destinoLat = destinoLat;
        this.destinoLng = destinoLng;
    }
}
