package com.example.motofrete.exception.entities.motoboy;

public class DadosDoVeiculoNulosOuInvalidos extends RuntimeException{

    public DadosDoVeiculoNulosOuInvalidos() {
    }

    public DadosDoVeiculoNulosOuInvalidos(String message) {
        super(message);
    }
}
