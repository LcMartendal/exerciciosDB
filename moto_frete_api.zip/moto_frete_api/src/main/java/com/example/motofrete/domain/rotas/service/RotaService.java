package com.example.motofrete.domain.rotas.service;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class RotaService {

    private final String LOCATIONIQ_KEY = "pk.0714922108f937447de95a600667fd99";
    private final String ORS_KEY = "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjY5OTdjYmUwZTM4NjQ3N2NhN2ExYTQwNmZjMjRiYmM0IiwiaCI6Im11cm11cjY0In0=";

    private final RestTemplate restTemplate = new RestTemplate();

    public double[] gerarCoordenadas(String endereco) {
        String url = "https://us1.locationiq.com/v1/search.php?key=" +
                LOCATIONIQ_KEY + "&q=" + endereco.replace(" ", "+") + "&format=json";

        ResponseEntity<List<Map<String, Object>>> response =
                restTemplate.exchange(url, HttpMethod.GET, null,
                        new ParameterizedTypeReference<List<Map<String, Object>>>() {});

        if (response.getBody() == null || response.getBody().isEmpty()) {
            return null;
        }

        Map<String, Object> first = response.getBody().get(0);

        double lon = Double.parseDouble((String) first.get("lon"));
        double lat = Double.parseDouble((String) first.get("lat"));

        return new double[]{lon, lat};
    }

    public Map<String, Object> gerarRota(List<double[]> coordinates) {

        String url = "https://api.openrouteservice.org/v2/directions/driving-car";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", ORS_KEY);
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setAccept(List.of(MediaType.APPLICATION_JSON));

        Map<String, Object> body = new HashMap<>();
        body.put("coordinates", coordinates);

        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);

        ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                url, HttpMethod.POST, entity,
                new ParameterizedTypeReference<Map<String, Object>>() {});

        return response.getBody();
    }

}
