package com.example.motofrete.service.rotas;

import com.example.motofrete.dto.rota.*;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.entity.frete.Frete;
import com.example.motofrete.entity.frete.StatusFrete;
import com.example.motofrete.exception.entities.NaoEncontradoException;
import com.example.motofrete.repository.FreteRepository;
import com.example.motofrete.repository.MotoboyRepository;
import com.example.motofrete.service.rotas.util.ObtedorEMapeadorDeRotaMotoboyService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class RotaService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final FreteRepository freteRepository;
    private final MotoboyRepository motoboyRepository;
    private final RotaOrdenacaoService rotaOrdenacaoService;
    private final ORSService orsService;
    private final LocationIQService locationIQService;
    private final ObtedorEMapeadorDeRotaMotoboyService obtedorEMapeadorDeRotaMotoboyService;


//    public String rotaMotoboy(Long id) {
//
//        Motoboy motoboy = motoboyRepository.findById(id)
//                .orElseThrow(NaoEncontradoException::new);
//
//        List<PontoRota> rotas = obtedorEMapeadorDeRotaMotoboyService.obterRotaMotoboy(motoboy);
//
//        List<double[]> coordinadas = rotas.stream()
//                .map(p -> new double[]{p.longitude(), p.latitude()})
//                .toList();
//
//
//        return orsService.calcularRota(coordinadas);
//
//    }

































    private final String LOCATIONIQ_KEY = "pk.0714922108f937447de95a600667fd99";
    private final String ORS_KEY = "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjY5OTdjYmUwZTM4NjQ3N2NhN2ExYTQwNmZjMjRiYmM0IiwiaCI6Im11cm11cjY0In0=";





    public double[] gerarCoordenadas(String endereco) {
        String url = "https://us1.locationiq.com/v1/search.php?key=" +
                LOCATIONIQ_KEY + "&q=" + endereco.replace(" ", "+") + "&format=json";

        ResponseEntity<List<Map<String, Object>>> response =
                restTemplate.exchange(url, HttpMethod.GET, null,
                        new ParameterizedTypeReference<List<Map<String, Object>>>() {});

        if (response.getBody() == null || response.getBody().isEmpty()) {
            return null;
        }

        Map<String, Object> first = response.getBody().get(0);

        double lon = Double.parseDouble((String) first.get("lon"));
        double lat = Double.parseDouble((String) first.get("lat"));

        return new double[]{lon, lat};
    }

    public Map<String, Object> gerarRota(List<double[]> coordinates) {

        String url = "https://api.openrouteservice.org/v2/directions/driving-car";

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(ORS_KEY);
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> body = Map.of(
                "coordinates", coordinates,
                "language", "pt",
                "instructions", true
        );

        HttpEntity<Map<String, Object>> entity =
                new HttpEntity<>(body, headers);

        try {
            return restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    entity,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            ).getBody();
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            System.out.println("Erro ORS:");
            System.out.println(e.getResponseBodyAsString());
            throw e;
        }
    }


    public String obterEndereco(double lat, double lng) {

        String url = String.format(
                "https://api.openrouteservice.org/geocode/reverse" +
                        "?api_key=%s&point.lon=%f&point.lat=%f",
                ORS_KEY, lng, lat
        );

        ORSReverseResponseDTO response =
                restTemplate.getForObject(url, ORSReverseResponseDTO.class);

        if (response == null ||
                response.features().isEmpty()) {
            return "Endereço não encontrado";
        }

        return response
                .features()
                .get(0)
                .getProperties()
                .getLabel();
    }

    public List<PontoRota> mostrarRota(Long motoboyId) {

        Motoboy motoboy = motoboyRepository.findById(motoboyId)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboyId));

        return obterRotaMotoboy(motoboy);
    }

    public List<double[]> mostrarCoordenasdasRota(Long motoboyId) {

        Motoboy motoboy = motoboyRepository.findById(motoboyId)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboyId));

        List<PontoRota> rota = obterRotaMotoboy(motoboy);

        return rota.stream()
                .map(p -> new double[]{
                        p.longitude(), // longitude primeiro
                        p.latitude()   // latitude depois
                })
                .toList();
    }

    private List<PontoRota> obterRotaMotoboy(Motoboy motoboy) {

        List<Frete> fretesAtivos =
                freteRepository.findByMotoboyAndStatus(
                        motoboy,
                        StatusFrete.ACEITO
                );

        List<FreteRotaDTO> fretesRota = fretesAtivos.stream()
                .map(this::mapearFrete)
                .toList();

        return rotaOrdenacaoService.ordenarGreedy(
                new PontoRota(null, TipoPonto.ORIGEM, motoboy.getLatitude(), motoboy.getLongitude()),
                fretesRota);
    }

    private FreteRotaDTO mapearFrete(Frete frete) {

        Long id = frete.getId();

        return new FreteRotaDTO(
                id,
                new PontoRota(
                        id,
                        TipoPonto.ORIGEM,
                        frete.getOrigemLat(),
                        frete.getOrigemLng()
                ),
                new PontoRota(
                        id,
                        TipoPonto.DESTINO,
                        frete.getDestinoLat(),
                        frete.getDestinoLng()
                )
        );
    }

    public RotaResumoDTO extrairResumoRota(Map<String, Object> rotaORS) {

        if (rotaORS == null || !rotaORS.containsKey("routes")) {
            return null;
        }

        List<Map<String, Object>> routes =
                (List<Map<String, Object>>) rotaORS.get("routes");

        if (routes.isEmpty()) {
            return null;
        }

        Map<String, Object> route = routes.get(0);

        Map<String, Object> summary =
                (Map<String, Object>) route.get("summary");

        double distanciaMetros =
                ((Number) summary.get("distance")).doubleValue();

        double duracaoSegundos =
                ((Number) summary.get("duration")).doubleValue();

        String polyline = (String) route.get("geometry");

        return new RotaResumoDTO(
                distanciaMetros / 1000.0, // km
                duracaoSegundos / 60.0,   // minutos
                polyline
        );
    }

    public Map<String, Object> criarInstrucoesDeRota(Long motoboyId){

        List<double[]> coordenadas = mostrarCoordenasdasRota(motoboyId);

        if (coordenadas == null || coordenadas.size() < 2) {
            throw new IllegalStateException("Não há coordenadas suficientes para gerar a rota");
        }

            return gerarRota(coordenadas);
    }



    //    public Map<String, Object> gerarRota(List<double[]> coordinates) {
//
//        String url = "https://api.openrouteservice.org/v2/directions/driving-car";
//
//        HttpHeaders headers = new HttpHeaders();
//        headers.set("Authorization", ORS_KEY);
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        headers.setAccept(List.of(MediaType.APPLICATION_JSON));
//
//        Map<String, Object> body = new HashMap<>();
//        body.put("coordinates", coordinates);
//
//        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(body, headers);
//
//        ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
//                url, HttpMethod.POST, entity,
//                new ParameterizedTypeReference<Map<String, Object>>() {});
//
//        return response.getBody();
//    }

}


