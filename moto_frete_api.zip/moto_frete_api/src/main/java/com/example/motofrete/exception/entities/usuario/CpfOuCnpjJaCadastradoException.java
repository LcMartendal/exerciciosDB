package com.example.motofrete.exception.entities.usuario;

public class CpfOuCnpjJaCadastradoException extends RuntimeException{

    public CpfOuCnpjJaCadastradoException() { super("Login já existe"); }

    public CpfOuCnpjJaCadastradoException(String message) {
        super(message);
    }
}
