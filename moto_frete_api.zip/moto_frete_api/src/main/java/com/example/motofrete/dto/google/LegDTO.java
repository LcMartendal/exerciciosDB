package com.example.motofrete.dto.google;
public class LegDTO { public DistanceDTO distance; public DurationDTO duration; public java.util.List<StepDTO> steps; }
