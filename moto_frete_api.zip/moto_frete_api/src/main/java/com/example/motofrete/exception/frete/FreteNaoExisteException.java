package com.example.motofrete.exception.frete;

public class FreteNaoExisteException extends RuntimeException{

    public FreteNaoExisteException() {
    }

    public FreteNaoExisteException(String message) {
        super(message);
    }
}
