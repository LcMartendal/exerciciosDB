package com.example.motofrete.service;
import com.example.motofrete.client.MapsClient;
import com.example.motofrete.client.GeocodeClient;
import com.example.motofrete.dto.google.GoogleDirectionsResponseDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.var;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class RotaService {
  private final MapsClient mapsClient;
  private final GeocodeClient geocodeClient;
  private final ObjectMapper objectMapper = new ObjectMapper();

  @Value("${maps.key}") private String mapsKey;

  public RotaService(MapsClient mapsClient, GeocodeClient geocodeClient){
    this.mapsClient = mapsClient; this.geocodeClient = geocodeClient;
  }

  public double[] geocode(String address) {
    Map<String,String> params = new HashMap<>();
    params.put("address", address);
    params.put("key", mapsKey);
    Map resp = geocodeClient.geocode(params);
    List results = (List) resp.get("results");
    if (results != null && !results.isEmpty()) {
      Map first = (Map) results.get(0);
      Map geometry = (Map) first.get("geometry");
      Map location = (Map) geometry.get("location");
      double lat = ((Number) location.get("lat")).doubleValue();
      double lng = ((Number) location.get("lng")).doubleValue();
      return new double[]{lat,lng};
    }
    throw new RuntimeException("Geocoding failed for: " + address);
  }

  public double calcularDistanciaComParadas(String origin, String destination, List<String> paradas) {
    Map<String,String> params = new HashMap<>();
    params.put("origin", origin);
    params.put("destination", destination);
    if (paradas != null && !paradas.isEmpty()) params.put("waypoints", String.join("|", paradas));
    params.put("key", mapsKey);

    Map resp = mapsClient.directions(params);
    try {
      // convert resp Map to DTO using Jackson
      GoogleDirectionsResponseDTO dto = objectMapper.convertValue(resp, GoogleDirectionsResponseDTO.class);
      if (dto != null && dto.routes != null && !dto.routes.isEmpty()) {
        long totalMeters = 0;
        for (var route : dto.routes) {
          if (route.legs != null) {
            for (var leg : route.legs) {
              if (leg.distance != null) totalMeters += leg.distance.value;
            }
          }
        }
        return totalMeters / 1000.0;
      }
    } catch (Exception e) {
      // ignore and fallback
    }
    // fallback: try parse lat,lng and haversine
    try {
      double[] a = parseLatLng(origin);
      double[] b = parseLatLng(destination);
      return haversine(a[0], a[1], b[0], b[1]);
    } catch (Exception ex) {
      return 0.0;
    }
  }

  private double[] parseLatLng(String s){
    String[] p = s.split(",");
    return new double[]{Double.parseDouble(p[0].trim()), Double.parseDouble(p[1].trim())};
  }

  private double haversine(double lat1, double lon1, double lat2, double lon2){
    final int R = 6371;
    double dLat = Math.toRadians(lat2-lat1);
    double dLon = Math.toRadians(lon2-lon1);
    double a = Math.sin(dLat/2)*Math.sin(dLat/2) + Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.sin(dLon/2)*Math.sin(dLon/2);
    double c = 2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R*c;
  }
}
