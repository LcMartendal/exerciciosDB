package com.example.motofrete.dto.motoboy;

import com.example.motofrete.entity.usuario.Usuario;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosMotoboyDTO(

        @NotNull
        Usuario usuario,

        Double latitude,

        Double longitude,

        @NotBlank
        String modelo_veiculo,

        @NotBlank
        String placa_veiculo,

        @NotNull
        int ano_veiculo

) {
}
