package com.example.motofrete.dto;

public record CriarUsuarioDTO(

    String username,

    String password,

    String nome,

    String role

){}
