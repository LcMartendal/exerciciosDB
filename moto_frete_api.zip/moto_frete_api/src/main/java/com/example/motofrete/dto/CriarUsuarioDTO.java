package com.example.motofrete.dto;
import jakarta.validation.constraints.*;

public class CriarUsuarioDTO {
  @NotBlank public String username;
  @NotBlank public String password;
  public String nome;
  @NotBlank public String role;
}
