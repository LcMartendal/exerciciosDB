package com.example.motofrete.dto;
import jakarta.validation.constraints.*;

public record AuthRequestDTO(

    @NotBlank
    String username,

    @NotBlank
    String password

){

}
