package com.example.motofrete.dto;
import jakarta.validation.constraints.*;

public class AuthRequestDTO {
  @NotBlank public String username;
  @NotBlank public String password;
}
