package com.example.motofrete.domain.entity.frete;

public enum StatusFrete {

    PENDENTE,
    ACEITO,
    CONCLUIDO
//
//        COLETADO,        // Motoboy chegou na origem
//        EM_ANDAMENTO,    // Indo para o destino
//        CANCELADO        // Cancelado por alguém



    }
