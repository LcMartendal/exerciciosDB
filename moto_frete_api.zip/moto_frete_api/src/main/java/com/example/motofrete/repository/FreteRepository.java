package com.example.motofrete.repository;
import com.example.motofrete.entity.Frete;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface FreteRepository extends JpaRepository<Frete, Long> {
  List<Frete> findByStatus(String status);

  @Query(value =
    "SELECT f.* FROM frete f WHERE f.status = :status AND f.origem_lat IS NOT NULL AND f.origem_lng IS NOT NULL " +
    "ORDER BY (6371 * acos(cos(radians(:lat)) * cos(radians(f.origem_lat)) * cos(radians(f.origem_lng) - radians(:lng)) + sin(radians(:lat)) * sin(radians(f.origem_lat)))) ASC",
    nativeQuery = true)
  List<Frete> findByStatusOrderByDistance(@Param("status") String status, @Param("lat") double lat, @Param("lng") double lng);
}
