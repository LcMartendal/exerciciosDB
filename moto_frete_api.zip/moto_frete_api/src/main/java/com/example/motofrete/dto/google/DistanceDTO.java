package com.example.motofrete.dto.google;
public class DistanceDTO { public String text; public int value; }
