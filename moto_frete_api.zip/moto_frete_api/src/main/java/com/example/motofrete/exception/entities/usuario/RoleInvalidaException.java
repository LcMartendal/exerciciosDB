package com.example.motofrete.exception.entities.usuario;

public class RoleInvalidaException extends RuntimeException{

    public RoleInvalidaException() {
    }

    public RoleInvalidaException(String message) {
        super(message);
    }
}
