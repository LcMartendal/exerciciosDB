package com.example.motofrete.dto.rota;

public record PontoRota(

        Long freteId,
        TipoPonto tipo,
        double latitude,
        double longitude

) {}
