package com.example.motofrete.domain.rotas.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ORSGeocodingService {

    @Value("${ors.api.key}")
    private String apiKey;

    private final RestTemplate restTemplate = new RestTemplate();

    public String obterEndereco(double lat, double lng) {

        String url = String.format(
                "https://api.openrouteservice.org/geocode/reverse" +
                        "?api_key=%s&point.lon=%f&point.lat=%f",
                apiKey, lng, lat
        );

        OrsReverseResponse response =
                restTemplate.getForObject(url, OrsReverseResponse.class);

        if (response == null ||
                response.getFeatures().isEmpty()) {
            return "Endereço não encontrado";
        }

        return response
                .getFeatures()
                .get(0)
                .getProperties()
                .getLabel();
    }
}
}
