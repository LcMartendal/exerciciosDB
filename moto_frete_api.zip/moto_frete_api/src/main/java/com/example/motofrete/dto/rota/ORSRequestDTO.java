package com.example.motofrete.dto.rota;

import java.util.List;

public record ORSRequestDTO(

        List<double[]> coordenadas,
        String language

){

    public ORSRequestDTO(List<double[]> coordinates) {
        this(coordinates, "pt-BR");
    }

}

