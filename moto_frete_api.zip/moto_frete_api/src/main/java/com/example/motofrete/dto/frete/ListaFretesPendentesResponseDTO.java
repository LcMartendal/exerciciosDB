package com.example.motofrete.dto.frete;

import com.example.motofrete.dto.motoboy.DadosResponseMotoboyDTO;
import org.springframework.data.domain.Page;

public record ListaFretesPendentesResponseDTO(

        String message,
        Page<DadosResponseFreteDTO> fretes

) {}
