package com.example.motofrete.repository;
import com.example.motofrete.entity.Motoboy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface MotoboyRepository extends JpaRepository<Motoboy, Long> {
  @Query(value =
    "SELECT m.* FROM motoboy m WHERE m.latitude IS NOT NULL AND m.longitude IS NOT NULL", nativeQuery = true)
  List<Motoboy> findAllWithCoords();

  @Query(value =
    "SELECT m.*, (6371 * acos(cos(radians(:lat)) * cos(radians(m.latitude)) * cos(radians(m.longitude) - radians(:lng)) + sin(radians(:lat)) * sin(radians(m.latitude)))) as distancia " +
    "FROM motoboy m " +
    "WHERE m.latitude IS NOT NULL AND m.longitude IS NOT NULL " +
    "ORDER BY distancia", nativeQuery = true)
  List<Motoboy> findNearby(@Param("lat") double lat, @Param("lng") double lng);
}
