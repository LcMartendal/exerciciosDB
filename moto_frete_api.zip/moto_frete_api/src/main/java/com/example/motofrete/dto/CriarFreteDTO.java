package com.example.motofrete.dto;
import jakarta.validation.constraints.*;

public record CriarFreteDTO(

    @NotBlank
    String origem,

    @NotBlank
    String destino

){}
