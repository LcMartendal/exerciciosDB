package com.example.motofrete.dto;
import jakarta.validation.constraints.*;

public class CriarFreteDTO {
  @NotBlank public String origem;
  @NotBlank public String destino;
}
