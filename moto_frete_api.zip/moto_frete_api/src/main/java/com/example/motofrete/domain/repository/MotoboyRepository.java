package com.example.motofrete.domain.repository;

import com.example.motofrete.domain.entity.Motoboy;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MotoboyRepository extends JpaRepository<Motoboy, Long> {
}
