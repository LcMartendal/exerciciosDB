package com.example.motofrete.dto.rota.notused;

import java.util.List;

public record NOTUSEDRotaResponseDTO(

        double distance,
        double duration,
        List<double[]> coordinates

) {}
