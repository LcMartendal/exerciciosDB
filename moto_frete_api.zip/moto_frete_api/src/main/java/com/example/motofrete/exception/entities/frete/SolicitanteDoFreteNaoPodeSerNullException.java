package com.example.motofrete.exception.entities.frete;

public class SolicitanteDoFreteNaoPodeSerNullException extends RuntimeException{

    public SolicitanteDoFreteNaoPodeSerNullException() {
    }

    public SolicitanteDoFreteNaoPodeSerNullException(String message) {
        super(message);
    }
}
