package com.example.motofrete.domain.dto.motoboy;

import com.example.motofrete.domain.entity.usuario.Usuario;

public record DadosResponseMotoboyDTO(

        Usuario usuario,

        Double latitude,

        Double longitude,

        String modelo_moto,

        String placa,

        int ano

) {
}
