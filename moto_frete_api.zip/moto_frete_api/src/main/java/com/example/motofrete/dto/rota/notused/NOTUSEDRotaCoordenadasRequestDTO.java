package com.example.motofrete.dto.rota.notused;

import java.util.List;

public record NOTUSEDRotaCoordenadasRequestDTO(

        double[] origem,
        List<double[]> paradas,
        double[] destino

) {}
