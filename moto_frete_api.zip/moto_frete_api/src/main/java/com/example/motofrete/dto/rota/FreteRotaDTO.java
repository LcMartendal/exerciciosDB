package com.example.motofrete.dto.rota;

public record FreteRotaDTO(

        Long freteId,
        PontoRota origem,
        PontoRota destino

){}
