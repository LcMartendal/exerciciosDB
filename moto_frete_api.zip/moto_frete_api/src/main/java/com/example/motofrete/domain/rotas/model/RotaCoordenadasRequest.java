package com.example.motofrete.domain.rotas.model;

import java.util.List;

public class RotaCoordenadasRequest {
    public double[] origem;       // [lat, lng]
    public List<double[]> paradas; // [[lat, lng], ...]
    public double[] destino;      // [lat, lng]
}
