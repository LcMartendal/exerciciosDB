package com.example.motofrete.controller;

import com.example.motofrete.domain.dto.usuario.DadosAtualizarUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosLoginUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosUsuarioDTO;
import com.example.motofrete.domain.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @PostMapping("/registrar")
    public ResponseEntity registrar(@Valid @RequestBody DadosUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Usuario registrado com sucesso!", service.registro(dados)));
    }

    @PostMapping("/login")
    public ResponseEntity login(@Valid @RequestBody DadosLoginUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Login bem sucessedido!", service.login(dados)));
    }

    @PutMapping("/atualizar")
    public ResponseEntity atualizar(Long id, DadosAtualizarUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Usuario atualizado com sucesso!", service.atualizar(id, dados)));
    }

    @GetMapping
    public ResponseEntity listarTodos() {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Usuarios", service.listarTodos()));
    }

    @DeleteMapping
    public ResponseEntity deletar(Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Usuario deletado com sucesso!", service.deletar(id)));
    }

}
