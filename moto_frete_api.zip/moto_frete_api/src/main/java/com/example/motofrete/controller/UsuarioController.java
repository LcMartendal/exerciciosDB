package com.example.motofrete.controller;

import com.example.motofrete.dto.usuario.*;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @PostMapping("/auth/registrar")
    public ResponseEntity registrar(@Valid @RequestBody DadosRegistarUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("Usuario registrado com sucesso!", service.registro(dados)));
    }

    @PostMapping("/auth/login")
    public ResponseEntity login(@Valid @RequestBody DadosLoginUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Login bem sucessedido!","token", service.login(dados)));
    }

    @PutMapping("/{id}")
    public ResponseEntity atualizar(@PathVariable Long id, @Valid @RequestBody DadosAtualizarUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Usuario atualizado com sucesso!", "usuário", service.atualizar(id, dados)));
    }

    @GetMapping
    public ResponseEntity listarUsuarios(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {

        Pageable pageable = PageRequest.of(page, size);
        Page<DadosResponseUsuarioDTO> usuarios = service.listarUsuarios(pageable);
        ListaUsuariosResponseDTO response = new ListaUsuariosResponseDTO("Usuarios listados com sucesso!", usuarios);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deletar(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Usuário deletado com sucesso!", "usuário", service.deletar(id)));
    }

}
