package com.example.motofrete.controller;

import com.example.motofrete.domain.dto.usuario.DadosAtualizarUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosLoginUsuarioDTO;
import com.example.motofrete.domain.dto.usuario.DadosRegistarUsuarioDTO;
import com.example.motofrete.domain.service.UsuarioService;
import feign.Param;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @PostMapping("/auth/registrar")
    public ResponseEntity registrar(@Valid @RequestBody DadosRegistarUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Usuario registrado com sucesso!", service.registro(dados)));
    }

    @PostMapping("/auth/login")
    public ResponseEntity login(@Valid @RequestBody DadosLoginUsuarioDTO dados) {

//        return ResponseEntity.ok("teste");
        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Login bem sucessedido!, token", service.login(dados)));
    }

    @PutMapping("/atualizar/{id}")
    public ResponseEntity atualizar(@PathVariable Long id, @Valid @RequestBody DadosAtualizarUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Usuario atualizado com sucesso!", service.atualizar(id, dados)));
    }

    @GetMapping
    public ResponseEntity listarTodos() {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Usuarios", service.listarTodos()));
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity deletar(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Usuário deletado com sucesso!", "user", service.deletar(id)));
    }

}
