package com.example.motofrete.service.rotas;

import com.example.motofrete.dto.rota.ORSRequestDTO;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
public class ORSService {

    private static final String ORS_URL =
            "https://api.openrouteservice.org/v2/directions/driving-car";

    private static final String API_KEY =
            "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjY5OTdjYmUwZTM4NjQ3N2NhN2ExYTQwNmZjMjRiYmM0IiwiaCI6Im11cm11cjY0In0=";

    private final RestTemplate restTemplate = new RestTemplate();

    public Map<String, Object> calcularRota(List<double[]> coordinates) {

        if (coordinates == null || coordinates.size() < 2) {
            throw new IllegalArgumentException("Informe ao menos origem e destino");
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(API_KEY);
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> body = Map.of(
                "coordinates", coordinates,
                "language", "pt",
                "instructions", true
        );

        HttpEntity<Map<String, Object>> entity =
                new HttpEntity<>(body, headers);

        try {
            return restTemplate.exchange(
                    ORS_URL,
                    HttpMethod.POST,
                    entity,
                    new ParameterizedTypeReference<Map<String, Object>>() {}
            ).getBody();
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            System.out.println("Erro ORS:");
            System.out.println(e.getResponseBodyAsString());
            throw e;
        }
    }
}
