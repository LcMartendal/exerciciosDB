package com.example.motofrete.service.rotas;

import com.example.motofrete.dto.rota.ORSRequestDTO;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class ORSService {

    private static final String ORS_URL =
            "https://api.openrouteservice.org/v2/directions/driving-motorcycle/geojson";

    private static final String API_KEY =
            "eyJvcmciOiI1YjNjZTM1OTc4NTExMTAwMDFjZjYyNDgiLCJpZCI6IjY5OTdjYmUwZTM4NjQ3N2NhN2ExYTQwNmZjMjRiYmM0IiwiaCI6Im11cm11cjY0In0=";

    private final RestTemplate restTemplate = new RestTemplate();

    public String calcularRota(List<double[]> coordinates) {

        if (coordinates == null || coordinates.size() < 2) {
            throw new IllegalArgumentException("Informe ao menos origem e destino");
        }

        ORSRequestDTO body = new ORSRequestDTO(coordinates);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Authorization", API_KEY);

        HttpEntity<ORSRequestDTO> request =
                new HttpEntity<>(body, headers);

        ResponseEntity<String> response = restTemplate.exchange(
                ORS_URL,
                HttpMethod.POST,
                request,
                String.class
        );

        return response.getBody();
    }
}
