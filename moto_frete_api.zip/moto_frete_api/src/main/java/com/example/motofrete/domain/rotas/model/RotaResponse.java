package com.example.motofrete.domain.rotas.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class RotaResponse {
    private double distance;        // metros
    private double duration;        // segundos
    private List<double[]> coordinates;
}
