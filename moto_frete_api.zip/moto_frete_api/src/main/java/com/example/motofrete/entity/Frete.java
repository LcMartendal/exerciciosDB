package com.example.motofrete.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Entity
@Data
public class Frete {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;

  @ManyToOne private User criador;
  @ManyToOne private Motoboy motoboy;

  private String origemEndereco;
  private Double origemLat;
  private Double origemLng;

  private String destinoEndereco;
  private Double destinoLat;
  private Double destinoLng;

  private Double distanciaKm;
  private Double valor;
  private String status;
  private LocalDateTime createdAt = LocalDateTime.now();

}
