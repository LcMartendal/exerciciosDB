package com.example.motofrete.dto.google;
public class DurationDTO { public String text; public int value; }
