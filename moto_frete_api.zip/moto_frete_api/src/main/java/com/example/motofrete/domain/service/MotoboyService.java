package com.example.motofrete.domain.service;

import com.example.motofrete.domain.entity.Motoboy;
import com.example.motofrete.domain.dto.motoboy.DadosAtualizarMotoboyDTO;
import com.example.motofrete.domain.dto.motoboy.DadosMotoboyDTO;
import com.example.motofrete.domain.dto.motoboy.DadosResponseMotoboyDTO;
import com.example.motofrete.exception.motoboy.DadosDoVeiculoNulosOuInvalidos;
import com.example.motofrete.exception.motoboy.MotoboyNaoExisteException;
import com.example.motofrete.exception.usuario.UsuarioNaoExisteException;
import com.example.motofrete.domain.repository.MotoboyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MotoboyService {

    @Autowired
    private MotoboyRepository repository;

    public DadosResponseMotoboyDTO inserir(DadosMotoboyDTO dados) {

        if(dados.usuario() == null) {
            throw new UsuarioNaoExisteException();
        }

        Motoboy motoboy = new Motoboy(dados);

        repository.save(motoboy);

        return new DadosResponseMotoboyDTO(dados.usuario(), dados.latitude(),
                dados.longitude(), dados.modelo_moto(),
                dados.placa(), dados.ano());
    }

    public List<Motoboy> listarTodos() { return repository.findAll(); }

    public DadosResponseMotoboyDTO atualizar(Long id, DadosAtualizarMotoboyDTO dados) {

        Motoboy motoboy = repository.findById(id)
                            .orElseThrow(MotoboyNaoExisteException::new);

        if(dados.modelo_moto().isBlank()){
            throw new DadosDoVeiculoNulosOuInvalidos("Modelo de moto inválido");
        }

        if(dados.placa().isBlank()){
            throw new DadosDoVeiculoNulosOuInvalidos("Placa inválida");
        }

        if(dados.ano() < 1980 ){
            throw new DadosDoVeiculoNulosOuInvalidos("Ano inválido");
        }

        motoboy.setModelo_moto(dados.modelo_moto());
        motoboy.setPlaca(dados.placa());
        motoboy.setAno(dados.ano());


        repository.save(motoboy);

        return new DadosResponseMotoboyDTO(motoboy.getUsuario(), motoboy.getLatitude(),
                motoboy.getLongitude(), dados.modelo_moto(),
                dados.placa(), dados.ano());

    }

    public void deletar(Long motoboy_id) {

        Motoboy motoboy = repository.findById(motoboy_id)
                .orElseThrow(MotoboyNaoExisteException::new);

        repository.delete(motoboy);
    }

}
