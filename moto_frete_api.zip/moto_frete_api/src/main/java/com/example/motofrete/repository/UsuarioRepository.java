package com.example.motofrete.repository;

import com.example.motofrete.entity.usuario.Usuario;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Repository;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    boolean existsByLogin(String login);

    UserDetails findByLogin(String login);

    Page<Usuario> findAll(Pageable pageable);

    boolean existsByCpfOuCnpj(String cpfOuCnpj);

}
