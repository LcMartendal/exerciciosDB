package com.example.motofrete.dto.motoboy;

import com.example.motofrete.dto.usuario.DadosResponseUsuarioDTO;
import org.springframework.data.domain.Page;

public record ListaMotoboysResponseDTO(

        String message,
        Page<DadosResponseMotoboyDTO> motoboys

) {}
