package com.example.motofrete.service;

import com.example.motofrete.dto.motoboy.*;
import com.example.motofrete.dto.usuario.DadosResponseUsuarioDTO;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.repository.UsuarioRepository;
import com.example.motofrete.exception.entities.NaoEncontradoException;
import com.example.motofrete.exception.entities.motoboy.DadosDoVeiculoNulosOuInvalidos;
import com.example.motofrete.exception.entities.usuario.DadosNaoPodemSerNullException;
import com.example.motofrete.repository.MotoboyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@EnableSpringDataWebSupport(pageSerializationMode = EnableSpringDataWebSupport.PageSerializationMode.VIA_DTO)
public class MotoboyService {

    @Autowired
    private MotoboyRepository repository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public DadosResponseMotoboyDTO inserir(DadosCadastroMotoboyDTO dados) {

        if(dados.usuario_id() == null) {
            throw new DadosNaoPodemSerNullException();
        }

        Usuario usuario = usuarioRepository.findById(dados.usuario_id())
                .orElseThrow(() -> new NaoEncontradoException("Usuário não encontrado com id " + dados.usuario_id()));

        Motoboy motoboy = new Motoboy(dados, usuario);

        repository.save(motoboy);

        return new DadosResponseMotoboyDTO(
                motoboy.getUsuario().getUsername(),
                motoboy.getUsuario().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                0.0,
                0.0,
                dados.modelo_veiculo(),
                dados.placa_veiculo(),
                dados.ano_veiculo());
    }

    public Page<DadosResponseMotoboyDTO> listarMotoboys(Pageable pageable) {

        return repository.findAll(pageable)
                .map(m -> new DadosResponseMotoboyDTO(
                        m.getUsuario().getUsername(),
                        m.getUsuario().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                        m.getLatitude(),
                        m.getLongitude(),
                        m.getModelo_veiculo(),
                        m.getPlaca_veiculo(),
                        m.getAno_veiculo())
                );
    }

    public DadosResponseMotoboyDTO atualizar(Long id, DadosAtualizarMotoboyDTO dados) {

        Motoboy motoboy = repository.findById(id)
                            .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + id));

        if(!dados.modelo_moto().isBlank()){
            motoboy.setModelo_veiculo(dados.modelo_moto());
        }

        if(!dados.placa().isBlank()){
            motoboy.setPlaca_veiculo(dados.placa());
        }

        if(dados.ano() < 1980 ){
            throw new DadosDoVeiculoNulosOuInvalidos("Ano da moto inválido: " + dados.ano());
        }

        motoboy.setAno_veiculo(dados.ano());

        repository.save(motoboy);

        Usuario usuario = motoboy.getUsuario();

        DadosResponseUsuarioDTO responseUsuario = new DadosResponseUsuarioDTO(
                usuario.getId(), usuario.getLogin(), usuario.getNome(), usuario.getRole()
        );

        return new DadosResponseMotoboyDTO(
                motoboy.getUsuario().getUsername(),
                motoboy.getUsuario().getAuthorities().stream().map(GrantedAuthority::getAuthority).toList(),
                motoboy.getLatitude(),
                motoboy.getLongitude(),
                dados.modelo_moto(),
                dados.placa(),
                dados.ano());
    }

    public DadosResponseLocalizacaoMotoboyDTO atualizarLocalizacao(Long id, DadosAtualizarLocalizacaoMotoboyDTO dados) {

        Motoboy motoboy = repository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + id));

        motoboy.setLatitude(dados.latitude());
        motoboy.setLongitude(dados.longitude());

        repository.save(motoboy);

        return new DadosResponseLocalizacaoMotoboyDTO(motoboy.getId(), motoboy.getUsuario().getNome(), motoboy.getLatitude(),
                motoboy.getLongitude());

    }

    public void deletar(Long motoboy_id) {

        Motoboy motoboy = repository.findById(motoboy_id)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboy_id));

        repository.delete(motoboy);
    }

}
