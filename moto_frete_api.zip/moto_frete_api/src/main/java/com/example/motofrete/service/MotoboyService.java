package com.example.motofrete.service;
import com.example.motofrete.dto.AtualizarMotoboyDTO;
import com.example.motofrete.dto.CriarMotoboyDTO;
import com.example.motofrete.dto.AtualizarLocalizacaoDTO;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.entity.User;
import com.example.motofrete.repository.MotoboyRepository;
import com.example.motofrete.repository.UserRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MotoboyService {
  private final MotoboyRepository repo;
  private final UserRepository userRepo;
  public MotoboyService(MotoboyRepository repo, UserRepository userRepo){ this.repo=repo; this.userRepo=userRepo; }

  public Motoboy create(CriarMotoboyDTO dto){
    Motoboy m = new Motoboy();

    User u = userRepo.findById(dto.userId()).orElseThrow(IllegalArgumentException::new);

    m.setUser(u);
    m.setPlaca(dto.placa());
    m.setModelo(dto.modelo());
    m.setAno(dto.ano());
    m.setStatus("OFFLINE");

    return repo.save(m);
  }

  public List<Motoboy> list(){
      return repo.findAll();
  }

  public Motoboy get(Long id){
      return repo.findById(id).orElseThrow(IllegalArgumentException::new);
  }

  public Motoboy update(Long id, AtualizarMotoboyDTO dto){
      Motoboy m = get(id);

      m.setPlaca(dto.placa());
      m.setModelo(dto.modelo());
      m.setAno(dto.ano());

      return repo.save(m);
  }

  public Motoboy updateLocation(Long id, AtualizarLocalizacaoDTO dto){
      Motoboy m = get(id); m.setLatitude(dto.latitude());

      m.setLongitude(dto.longitude());
      m.setStatus("ONLINE");

      return repo.save(m);
  }

  public void delete(Long id){
      repo.deleteById(id);
  }

}
