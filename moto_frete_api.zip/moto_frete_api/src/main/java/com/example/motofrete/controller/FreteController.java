package com.example.motofrete.controller;

import com.example.motofrete.domain.dto.frete.DadosFreteDTO;
import com.example.motofrete.domain.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.example.motofrete.domain.service.FreteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/frete")
public class FreteController {

    @Autowired
    private FreteService service;

    @PostMapping("/inserir")
    public ResponseEntity inserir(@Valid @RequestBody DadosFreteDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Frete inserido com sucesso!", service.inserir(dados)));
    }

    @GetMapping("/pendentes")
    public ResponseEntity listarPendentes() {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Fretes pendentes", service.listarPendentes()));
    }

    @GetMapping("/proximos")
    public ResponseEntity listarProximos(@Valid @RequestBody DadosAtualizarLocalizacaoMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Fretes proximos", service.listarProximos(dados)));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity excluir(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Frete deletado com sucesso!", service.excluir(id)));
    }

    @PutMapping("/{frete_id}/aceitar/{motoboy_id}")
    public ResponseEntity aceitar(@PathVariable Long frete_id, @PathVariable Long motoboy_id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Frete aceito", service.aceitar(frete_id, motoboy_id)));
    }

    @PutMapping("/{id}")
    public ResponseEntity concluir(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Frete concluido", service.concluir(id)));
    }

    @GetMapping("/rota/{motoboy_id}")
    public ResponseEntity mostrarRota(@PathVariable Long motoboy_id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("rota", service.mostrarRota(motoboy_id)));
    }

}
