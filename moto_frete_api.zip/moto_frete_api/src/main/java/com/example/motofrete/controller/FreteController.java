package com.example.motofrete.controller;
import com.example.motofrete.dto.CriarFreteDTO;
import com.example.motofrete.entity.Frete;
import com.example.motofrete.entity.User;
import com.example.motofrete.repository.UserRepository;
import com.example.motofrete.service.FreteService;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/fretes")
public class FreteController {
  private final FreteService freteService;
  private final UserRepository userRepo;
  public FreteController(FreteService freteService, UserRepository userRepo){ this.freteService = freteService; this.userRepo = userRepo; }

  @PostMapping public Frete create(@Valid @RequestBody CriarFreteDTO dto, @AuthenticationPrincipal org.springframework.security.core.userdetails.User principal) {
    User u = userRepo.findByUsername(principal.getUsername()).orElseThrow(IllegalArgumentException::new);
    return freteService.create(dto, u);
  }
  @GetMapping public List<Frete> list(){ return freteService.list(); }
  @GetMapping("/pendentes") public List<Frete> pendentes(){ return freteService.list(); }
  @GetMapping("/nearby") public List<Frete> nearby(@RequestParam double lat, @RequestParam double lng){ return freteService.listPendentesNearby(lat,lng); }
  @PutMapping("/{id}/aceitar/{motoboyId}") public Frete aceitar(@PathVariable Long id, @PathVariable Long motoboyId){ return freteService.aceitar(id,motoboyId); }
  @PutMapping("/{id}/concluir") public Frete concluir(@PathVariable Long id){ return freteService.concluir(id); }
}
