package com.example.motofrete.controller;

import com.example.motofrete.dto.frete.DadosFreteDTO;
import com.example.motofrete.dto.frete.DadosResponseFreteDTO;
import com.example.motofrete.dto.frete.ListaFretesPendentesResponseDTO;
import com.example.motofrete.dto.frete.ListaFretesProximosResponseDTO;
import com.example.motofrete.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.example.motofrete.service.FreteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/frete")
public class FreteController {

    @Autowired
    private FreteService service;

    @PostMapping("/inserir")
    public ResponseEntity inserir(@Valid @RequestBody DadosFreteDTO dados) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("message", "Frete inserido com sucesso!", "frete", service.inserir(dados)));
    }

    @GetMapping("/pendentes")
    public ResponseEntity listarPendentes(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {

        Pageable pageable = PageRequest.of(page, size);
        Page<DadosResponseFreteDTO> fretes = service.listarPendentes(pageable);

        ListaFretesPendentesResponseDTO response =
                new ListaFretesPendentesResponseDTO("Listagem de fretes pendentes bem sucessedida", fretes);

        return ResponseEntity.ok(response);
    }

    @GetMapping("/proximos")
    public ResponseEntity listarProximos(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @Valid @RequestBody DadosAtualizarLocalizacaoMotoboyDTO dados
    ) {

        Pageable pageable = PageRequest.of(page, size);
        Page<DadosResponseFreteDTO> fretes = service.listarProximos(pageable, dados);

        ListaFretesProximosResponseDTO response =
                new ListaFretesProximosResponseDTO("Listagem de fretes proximos bem sucessedida", fretes);

        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity excluir(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Frete deletado com sucesso!", "",  service.excluir(id)));
    }

    @PutMapping("/{frete_id}/aceitar/{motoboy_id}")
    public ResponseEntity aceitar(@PathVariable Long frete_id, @PathVariable Long motoboy_id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Frete aceito com sucesso", "frete", service.aceitar(frete_id, motoboy_id)));
    }

    @PutMapping("/{id}")
    public ResponseEntity concluir(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Frete concluido com sucesso", "frete",  service.concluir(id)));
    }

    @GetMapping("/rota/{motoboy_id}")
    public ResponseEntity mostrarRota(@PathVariable Long motoboy_id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("rota", service.mostrarRota(motoboy_id)));
    }

}
