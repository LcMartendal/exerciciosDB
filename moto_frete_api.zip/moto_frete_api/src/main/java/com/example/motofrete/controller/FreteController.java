package com.example.motofrete.controller;

import com.example.motofrete.domain.dto.frete.DadosFreteDTO;
import com.example.motofrete.domain.dto.motoboy.DadosLocalizacaoMotoboyDTO;
import com.example.motofrete.domain.service.FreteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/frete")
public class FreteController {

    @Autowired
    private FreteService service;

    @PostMapping("/inserir")
    public ResponseEntity inserir(@Valid @RequestBody DadosFreteDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Frete inserido com sucesso!", service.inserir(dados)));
    }

    @GetMapping("/pendentes")
    public ResponseEntity listarPendentes() {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Fretes pendentes", service.listarPendentes()));
    }

    @GetMapping("/proximos")
    public ResponseEntity listarProximos(@Valid @RequestBody DadosLocalizacaoMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Fretes proximos", service.listarProximos(dados)));
    }

    @DeleteMapping
    public ResponseEntity excluir(Long frete_id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("Frete deletado com sucesso!", service.excluir(frete_id)));
    }

}
