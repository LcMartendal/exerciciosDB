package com.example.motofrete.service;

import com.example.motofrete.entity.usuario.RoleUsuario;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.dto.usuario.DadosAtualizarUsuarioDTO;
import com.example.motofrete.dto.usuario.DadosLoginUsuarioDTO;
import com.example.motofrete.dto.usuario.DadosResponseUsuarioDTO;
import com.example.motofrete.dto.usuario.DadosRegistarUsuarioDTO;
import com.example.motofrete.exception.entities.NaoEncontradoException;
import com.example.motofrete.exception.entities.usuario.*;
import com.example.motofrete.infra.security.TokenService;
import com.example.motofrete.repository.FreteRepository;
import com.example.motofrete.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class UsuarioService {

    private final UsuarioRepository repository;
    private final FreteRepository freteRepository;
    private final AuthenticationManager authenticationManager;
    private final TokenService tokenService;

    public DadosResponseUsuarioDTO registro(DadosRegistarUsuarioDTO dados) {

        if (repository.existsByLogin(dados.login())){
            throw new LoginJaExisteException();
        }

        if (repository.existsByCpfOuCnpj(dados.cpf_ou_cnpj())){
            throw new CpfOuCnpjJaCadastradoException("Cpf ou cnpj já cadastrado");
        }

        if (dados.dt_nascimento().getYear() < 1925) {
            throw new DataDeNascimentoInvalidaException("Data de nascimento não pode ser antes de 1925");
        }

        if (dados.dt_nascimento().getYear() > (LocalDate.now().getYear() - 18)) {
            throw new DataDeNascimentoInvalidaException("Idade mínima permitida é de 18 anos");
        }

        String role = dados.role().toUpperCase();

        if(!role.equals(RoleUsuario.ADMIN.toString())
                && !role.equals(RoleUsuario.MOTOBOY.toString())
                && !role.equals(RoleUsuario.SOLICITANTE_FRETE.toString())){
            throw new RoleInvalidaException("Role inválida, roles disponiveis (ADMIN, MOTOBOY, SOLICITANTE_FRETE)");
        }

        Usuario usuario = new Usuario(dados, new BCryptPasswordEncoder().encode(dados.senha_hash()));

        repository.save(usuario);

        return new DadosResponseUsuarioDTO(usuario.getId(),usuario.getLogin(), usuario.getNome(), usuario.getRole());
    }


    public String login(DadosLoginUsuarioDTO dados) {
        if(!repository.existsByLogin(dados.login())){
            throw new NaoEncontradoException("Usuário " + dados.login() + " não existe.");
        }

        var tokenAutenticacao = new UsernamePasswordAuthenticationToken(dados.login(), dados.senha_hash());
        var autenticado = authenticationManager.authenticate(tokenAutenticacao);

        return tokenService.gerarToken((Usuario) autenticado.getPrincipal());
    }

    public DadosResponseUsuarioDTO atualizar(Long id, DadosAtualizarUsuarioDTO dados) {

        Usuario usuario = repository.findById(id)
                        .orElseThrow(() -> new NaoEncontradoException("Usuário não encontrado com id " + id));

        if (dados.login() != null && !dados.login().isBlank() &&
                !dados.login().equals(usuario.getLogin()) && repository.existsByLogin(dados.login())) {

            throw new LoginJaExisteException();
        }

        if (dados.login() != null && !dados.login().isBlank()) {
            usuario.setLogin(dados.login());
        }

        if (dados.senha_hash() != null && !dados.senha_hash().isBlank()) {
            usuario.setSenha_hash(new BCryptPasswordEncoder().encode(dados.senha_hash()));
        }

        if (dados.nome() != null && !dados.nome().isBlank()) {
            usuario.setNome(dados.nome());
        }

        if (dados.role() != null) {
            usuario.setRole(dados.role());
        }

        repository.save(usuario);

        return new DadosResponseUsuarioDTO(usuario.getId(), usuario.getLogin(),
                usuario.getNome(), usuario.getRole());
    }

    public Page<DadosResponseUsuarioDTO> listarUsuarios(Pageable pageable) {
        return repository.findAll(pageable)
                .map(u -> new DadosResponseUsuarioDTO(u.getId(), u.getNome(), u.getLogin(), u.getRole()));
    }

    public DadosResponseUsuarioDTO deletar(Long id) {

        Usuario usuario = repository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("Usuário não encontrado com id " + id));

        if (freteRepository.existsByCriadorId(id)) {
            throw new FreteExistenteParaCriadorException("Há frete associado a esse usuário");
        }

        repository.delete(usuario);

        return new DadosResponseUsuarioDTO(usuario.getId(), usuario.getLogin(),
                usuario.getNome(), usuario.getRole());
    }

}
