package com.example.motofrete.dto;
import java.util.List;
import jakarta.validation.constraints.*;

public class RotaRequestDTO {
  @NotBlank public String origem;
  @NotBlank public String destino;
  public List<String> paradas;
}
