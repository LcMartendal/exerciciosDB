package com.example.motofrete.dto;
import java.util.List;
import jakarta.validation.constraints.*;

public record RotaRequestDTO(

    @NotBlank
    String origem,

    @NotBlank
    String destino,

    List<String> paradas

) {}
