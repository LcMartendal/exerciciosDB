package com.example.motofrete.domain.dto.frete;

import com.example.motofrete.domain.entity.frete.StatusFrete;
import com.example.motofrete.domain.entity.usuario.Usuario;

public record DadosResponseFreteDTO(

        Long id,

        Usuario criador,

        String origem,

        String destino,

        Double distanciaKm,

        Double valor,

        StatusFrete status

) {
}
