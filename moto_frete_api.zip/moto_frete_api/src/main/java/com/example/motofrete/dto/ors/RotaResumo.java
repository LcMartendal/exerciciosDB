package com.example.motofrete.dto.ors;

import jdk.jfr.Name;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RotaResumo {
    public double distanciaKm;
    public double tempoMin;
}
