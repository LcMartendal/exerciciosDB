package com.example.motofrete.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "motoboy")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Motoboy {

  @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @OneToOne @JoinColumn(name="user_id", nullable=false)
  private User user;

  private Double latitude;

  private Double longitude;

  private String status;

  private String placa;

  private String modelo;

  private Integer ano;

}
