package com.example.motofrete.entity;

import jakarta.persistence.*;

@Entity
public class Motoboy {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @OneToOne @JoinColumn(name="user_id", nullable=false) private User user;
  private Double latitude;
  private Double longitude;
  private String status;
  private String placa;
  private String modelo;
  private Integer ano;

  public Long getId(){return id;}
  public void setId(Long id){this.id=id;}
  public User getUser(){return user;}
  public void setUser(User user){this.user=user;}
  public Double getLatitude(){return latitude;}
  public void setLatitude(Double latitude){this.latitude=latitude;}
  public Double getLongitude(){return longitude;}
  public void setLongitude(Double longitude){this.longitude=longitude;}
  public String getStatus(){return status;}
  public void setStatus(String status){this.status=status;}
  public String getPlaca(){return placa;}
  public void setPlaca(String placa){this.placa=placa;}
  public String getModelo(){return modelo;}
  public void setModelo(String modelo){this.modelo=modelo;}
  public Integer getAno(){return ano;}
  public void setAno(Integer ano){this.ano=ano;}
}
