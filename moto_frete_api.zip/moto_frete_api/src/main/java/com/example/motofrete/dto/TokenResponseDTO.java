package com.example.motofrete.dto;

public record TokenResponseDTO(

    String token,

    String role

) {}
