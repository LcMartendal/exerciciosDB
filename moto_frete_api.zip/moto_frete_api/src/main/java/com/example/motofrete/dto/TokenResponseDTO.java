package com.example.motofrete.dto;

public class TokenResponseDTO {
  public String token;
  public String role;
  public TokenResponseDTO(String token, String role){this.token=token;this.role=role;}
}
