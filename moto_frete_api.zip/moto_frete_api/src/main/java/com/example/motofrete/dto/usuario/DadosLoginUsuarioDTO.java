package com.example.motofrete.dto.usuario;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

public record DadosLoginUsuarioDTO(

        @Email
        @NotBlank
        String login,

        @NotBlank
        String senha_hash

) {
}
