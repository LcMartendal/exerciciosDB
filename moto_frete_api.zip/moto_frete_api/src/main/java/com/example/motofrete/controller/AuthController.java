package com.example.motofrete.controller;
import com.example.motofrete.config.TokenService;
import com.example.motofrete.dto.*;
import com.example.motofrete.entity.User;
import com.example.motofrete.repository.UserRepository;
import org.springframework.security.authentication.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth")
public class AuthController {
  private final AuthenticationManager authManager;
  private final TokenService tokenService;
  private final UserRepository userRepo;
  private final PasswordEncoder encoder;
  public AuthController(AuthenticationManager authManager, TokenService tokenService, UserRepository userRepo, PasswordEncoder encoder){
    this.authManager = authManager; this.tokenService = tokenService; this.userRepo = userRepo; this.encoder = encoder;
  }

  @PostMapping("/login")
  public TokenResponseDTO login(@Valid @RequestBody AuthRequestDTO req){
    authManager.authenticate(new UsernamePasswordAuthenticationToken(req.username(), req.password()));
    User u = userRepo.findByUsername(req.username()).orElseThrow(IllegalArgumentException::new);
    String token = tokenService.generateToken(u.getUsername(), u.getRole());
    return new TokenResponseDTO(token, u.getRole());
  }

  @PostMapping("/register")
  public TokenResponseDTO register(@Valid @RequestBody CriarUsuarioDTO dto){
    User u = new User();
    u.setUsername(dto.username());
    u.setPassword(encoder.encode(dto.password()));
    u.setNome(dto.nome());
    u.setRole(dto.role());
    userRepo.save(u);
    String token = tokenService.generateToken(u.getUsername(), u.getRole());
    return new TokenResponseDTO(token, u.getRole());
  }
}
