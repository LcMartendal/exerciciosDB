package com.example.motofrete.dto.motoboy;

import java.util.List;

public record DadosResponseMotoboyDTO(

        String username,
        List<String> authorities,
        Double latitude,
        Double longitude,
        String modeloMoto,
        String placa,
        Integer ano

) {}
