package com.example.motofrete.dto.motoboy;

import java.util.List;

public record DadosResponseMotoboyDTO(

        String username,
        List<String> authorities,
        Double latitude,
        Double longitude,
        String modelo_veiculo,
        String placa_veiculo,
        Integer ano_veiculo

) {}
