package com.example.motofrete.dto.motoboy;

import com.example.motofrete.entity.usuario.Usuario;

public record DadosResponseLocalizacaoMotoboyDTO(

        Long id,

        String nome,

        Double latitude,

        Double longitude

) {
}
