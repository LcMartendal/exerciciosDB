package com.example.motofrete.dto;
import jakarta.validation.constraints.*;

public record CriarMotoboyDTO(

    @NotNull
    Long userId,

    @NotBlank
    String placa,

    @NotBlank
    String modelo,

    @NotNull
    Integer ano

) {}
