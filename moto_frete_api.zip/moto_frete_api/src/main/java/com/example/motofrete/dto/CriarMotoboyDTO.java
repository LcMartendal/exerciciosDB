package com.example.motofrete.dto;
import jakarta.validation.constraints.*;

public class CriarMotoboyDTO {
  @NotNull public Long userId;
  public String placa;
  public String modelo;
  public Integer ano;
}
