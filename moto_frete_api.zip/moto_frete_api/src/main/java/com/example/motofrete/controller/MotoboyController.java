package com.example.motofrete.controller;

import com.example.motofrete.domain.dto.motoboy.DadosAtualizarMotoboyDTO;
import com.example.motofrete.domain.dto.motoboy.DadosMotoboyDTO;
import com.example.motofrete.domain.service.MotoboyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/motoboy")
public class MotoboyController {

    @Autowired
    private MotoboyService service;

    @PostMapping("/cadastro")
    public ResponseEntity cadastrar(@Valid @RequestBody DadosMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Cadastrado com sucesso!", service.inserir(dados)));
    }

    @PutMapping("/atualizar_dados/{id}")
    public ResponseEntity atualizarDados(@RequestParam Long id, @Valid @RequestBody DadosAtualizarMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Atualizado com sucesso!", service.atualizar(id, dados)));
    }

    @GetMapping
    public ResponseEntity listarMotoboys() {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Lista de motoboys", service.listarTodos()));
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity deletarMotoboy(@RequestParam Long id) {

        service.deletar(id);

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("deletado com sucesso!", ""));
    }
}
