package com.example.motofrete.controller;

import com.example.motofrete.domain.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.example.motofrete.domain.dto.motoboy.DadosAtualizarMotoboyDTO;
import com.example.motofrete.domain.dto.motoboy.DadosCadastroMotoboyDTO;
import com.example.motofrete.domain.dto.motoboy.DadosMotoboyDTO;
import com.example.motofrete.domain.service.MotoboyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/motoboy")
public class MotoboyController {

    @Autowired
    private MotoboyService service;

    @PostMapping("/cadastro")
    public ResponseEntity cadastrar(@Valid @RequestBody DadosCadastroMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Cadastrado com sucesso!", service.inserir(dados)));
    }

    @PutMapping("/atualizar/{id}")
    public ResponseEntity atualizarDados(@PathVariable Long id, @Valid @RequestBody DadosAtualizarMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Atualizado com sucesso!", service.atualizar(id, dados)));
    }

    @GetMapping
    public ResponseEntity listarMotoboys() {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Lista de motoboys", service.listarTodos()));
    }

    @PutMapping("/localizacao/{id}")
    public ResponseEntity atualizarLocalizacao(@PathVariable Long id, @Valid @RequestBody DadosAtualizarLocalizacaoMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("Atualizado com sucesso!", service.atualizarLocalizacao(id, dados)));
    }

    @DeleteMapping("/deletar/{id}")
    public ResponseEntity deletarMotoboy(@PathVariable Long id) {

        service.deletar(id);

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("deletado com sucesso!", ""));
    }

}
