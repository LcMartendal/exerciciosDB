package com.example.motofrete.controller;
import com.example.motofrete.dto.*;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.service.MotoboyService;
import com.example.motofrete.service.FreteService;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/motoboys")
public class MotoboyController {
  private final MotoboyService motoboyService;

  public MotoboyController(MotoboyService motoboyService){
      this.motoboyService = motoboyService;
  }

  @PostMapping
  public Motoboy create(@Valid @RequestBody CriarMotoboyDTO dto){
      return motoboyService.create(dto);
  }

  @GetMapping
  public List<Motoboy> list(){
      return motoboyService.list();
  }

  @GetMapping("/{id}")
  public Motoboy get(@PathVariable Long id){
      return motoboyService.get(id);
  }

  @PutMapping("/{id}")
  public Motoboy update(@PathVariable Long id, @Valid @RequestBody AtualizarMotoboyDTO dto){
      return motoboyService.update(id,dto);
  }

  @PutMapping("/{id}/localizacao")
  public Motoboy updateLocation(@PathVariable Long id, @Valid @RequestBody AtualizarLocalizacaoDTO dto){
      return motoboyService.updateLocation(id,dto);
  }

  @DeleteMapping("/{id}")
  public void delete(@PathVariable Long id){
      motoboyService.delete(id);
  }

//  @GetMapping("/nearby")
//  public List<Motoboy> nearby(@RequestParam double lat, @RequestParam double lng) {
//      return motoboyService.list();
//  }

}
