package com.example.motofrete.dto.motoboy;

import jakarta.validation.constraints.NotNull;

public record DadosAtualizarLocalizacaoMotoboyDTO(

        @NotNull
        Double latitude,

        @NotNull
        Double longitude

) {
}
