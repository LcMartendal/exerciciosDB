package com.martendal.moto_frete_api.service;

import com.martendal.moto_frete_api.dto.frete.DadosFreteDTO;
import com.martendal.moto_frete_api.dto.frete.DadosResponseFreteDTO;
import com.martendal.moto_frete_api.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.martendal.moto_frete_api.dto.motoboy.DadosMotoboyDTO;
import com.martendal.moto_frete_api.dto.rota.RotaResumoDTO;
import com.martendal.moto_frete_api.entity.Motoboy;
import com.martendal.moto_frete_api.entity.frete.Frete;
import com.martendal.moto_frete_api.entity.frete.StatusFrete;
import com.martendal.moto_frete_api.entity.usuario.RoleUsuario;
import com.martendal.moto_frete_api.entity.usuario.Usuario;
import com.martendal.moto_frete_api.exception.entities.NaoEncontradoException;
import com.martendal.moto_frete_api.exception.entities.frete.*;
import com.martendal.moto_frete_api.repository.FreteRepository;
import com.martendal.moto_frete_api.repository.MotoboyRepository;
import com.martendal.moto_frete_api.repository.UsuarioRepository;
import com.martendal.moto_frete_api.service.entities.FreteService;
import com.martendal.moto_frete_api.service.rotas.RotaOrdenacaoService;
import com.martendal.moto_frete_api.service.rotas.RotaService;
import org.assertj.core.api.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FreteServiceTest {

    @InjectMocks
    private FreteService freteService;

    @Mock
    private FreteRepository freteRepository;

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private MotoboyRepository motoboyRepository;

    @Mock
    private RotaService rotaService;

    @Mock
    private RotaOrdenacaoService rotaOrdenacaoService;

    private Usuario usuario;
    private Motoboy motoboy;
    private Frete frete;

    @BeforeEach
    void setup() {
        usuario = new Usuario();
        usuario.setNome("usuario");
        usuario.setRole(RoleUsuario.MOTOBOY);

        motoboy = new Motoboy();
        motoboy.setLongitude(0.0);
        motoboy.setLatitude(0.0);
        frete = new Frete();
        frete.setId(1L);
        frete.setCriador(usuario);
        frete.setStatus(StatusFrete.PENDENTE);
        frete.setOrigemEndereco("Origem");
        frete.setDestinoEndereco("Destino");
        frete.setDistanciaKm(10.0);
        frete.setValor(25.0);

        // Simula @Value
        ReflectionTestUtils.setField(freteService, "tarifaKm", 2.5);
    }

    @Test
    void deveInserirFreteComSucesso() {
        DadosFreteDTO dto = new DadosFreteDTO(
                1L,
                "Rua A",
                "Rua B"
        );

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        when(rotaService.gerarCoordenadas("Rua A")).thenReturn(new double[]{-26.9155211, -49.0580115});
        when(rotaService.gerarCoordenadas("Rua B")).thenReturn(new double[]{-26.9129614, -49.053546});
        when(freteRepository.existsByCriadorAndRota(
                eq(1L),
                eq(-49.0580115), eq(-26.9155211),
                eq(-49.053546), eq(-26.9129614)
        )).thenReturn(false);
        when(rotaService.gerarRota(anyList())).thenReturn(null);
        when(rotaService.extrairResumoRota(any())).thenReturn(new RotaResumoDTO(10, 20, null));

        DadosResponseFreteDTO response = freteService.inserir(dto);

        assertNotNull(response);
        assertEquals(StatusFrete.PENDENTE, response.status());
        verify(freteRepository).save(any(Frete.class));
    }

    @Test
    void deveLancarExcecaoQuandoInserirMaisDeCincoFretes() {
        DadosFreteDTO dto = new DadosFreteDTO(
                1L,
                "Rua A",
                "Rua B"
        );

        when(freteRepository.hasFiveOrMoreFretesCriador(1L)).thenReturn(true);

        LimiteDeFretesException exception = assertThrows(
                LimiteDeFretesException.class,
                () -> freteService.inserir(dto)
        );

        assertEquals(
                "Limite de fretes, delete ou espere algum frete ser concluido para inserir mais",
                exception.getMessage()
        );
    }

    @Test
    void deveLancarExcecaoQuandoAceitarMaisDeCincoFretes() {
        DadosFreteDTO dto = new DadosFreteDTO(
                1L,
                "Rua A",
                "Rua B"
        );

        when(freteRepository.hasFiveOrMoreFretesMotoboy(1L)).thenReturn(true);

        assertThrows(LimiteDeFretesException.class,
                () -> freteService.aceitar(1L, 1L));
    }

    @Test
    void deveLancarExcecaoQuandoFreteJaExisteParaEssasLocalidades() {
        DadosFreteDTO dto = new DadosFreteDTO(
                1L,
                "Rua A",
                "Rua B"
        );

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        when(rotaService.gerarCoordenadas("Rua A")).thenReturn(new double[]{-26.9155211, -49.0580115});
        when(rotaService.gerarCoordenadas("Rua B")).thenReturn(new double[]{-26.9129614, -49.053546});
        when(freteRepository.existsByCriadorAndRota(
                eq(1L),
                eq(-49.0580115), eq(-26.9155211),
                eq(-49.053546), eq(-26.9129614)
        )).thenReturn(true);

        assertThrows(FreteJaSolicitadoParaEssasLocalidadesException.class,
                () -> freteService.inserir(dto));
    }


        @Test
    void deveLancarExcecaoQuandoUsuarioNaoExiste() {
        DadosFreteDTO dto = new DadosFreteDTO(99L, "A", "B");

        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(NaoEncontradoException.class,
                () -> freteService.inserir(dto));
    }

    @Test
    void deveLancarExcecaoQuandoOrigemOuDestinoEmBranco() {
        DadosFreteDTO dto = new DadosFreteDTO(1L, "", "");

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));

        assertThrows(DadosOrigemOuDestinoNaoPodeSerNullException.class,
                () -> freteService.inserir(dto));
    }

    @Test
    void deveListarFretesPendentes() {
        Page<Frete> page = new PageImpl<>(List.of(frete));
        when(freteRepository.findByStatus(any(), eq(StatusFrete.PENDENTE)))
                .thenReturn(page);

        Page<DadosResponseFreteDTO> result =
                freteService.listarPendentes(PageRequest.of(0, 10));

        assertEquals(1, result.getTotalElements());
    }

    @Test
    void deveListarFretesProximos() {
        Page<Frete> page = new PageImpl<>(List.of(frete));

        when(freteRepository.listarFretesProximosPorRaio(
                any(), anyDouble(), anyDouble(), anyString(), anyDouble()
        )).thenReturn(page);

        Page<DadosResponseFreteDTO> result =
                freteService.listarProximos(
                        PageRequest.of(0, 10),
                        new DadosAtualizarLocalizacaoMotoboyDTO(-26.9, -49.0)
                );

        assertEquals(1, result.getTotalElements());
    }


    @Test
    void deveExcluirFrete() {
        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));

        freteService.excluir(1L);
        verify(freteRepository).delete(frete);
    }

    @Test
    void deveAceitarFrete() {
        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));
        when(motoboyRepository.findById(1L)).thenReturn(Optional.of(motoboy));

        DadosResponseFreteDTO response =
                freteService.aceitar(1L, 1L);

        assertEquals(StatusFrete.ACEITO, response.status());
    }

    @Test
    void deveFalharAoAceitarFreteNaoPendente() {
        frete.setStatus(StatusFrete.ACEITO);

        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));
        when(motoboyRepository.findById(1L)).thenReturn(Optional.of(motoboy));

        assertThrows(FreteNaoDisponivelException.class,
                () -> freteService.aceitar(1L, 1L));
    }

    @Test
    void deveConcluirFrete() {
        frete.setStatus(StatusFrete.ACEITO);

        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));

        DadosResponseFreteDTO response = freteService.concluir(1L);

        assertEquals(StatusFrete.CONCLUIDO, response.status());
    }

    @Test
    void deveFalharAoConcluirFreteInvalido() {
        frete.setStatus(StatusFrete.PENDENTE);

        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));

        assertThrows(FreteNaoPodeSerConcluidoException.class,
                () -> freteService.concluir(1L));
    }
}