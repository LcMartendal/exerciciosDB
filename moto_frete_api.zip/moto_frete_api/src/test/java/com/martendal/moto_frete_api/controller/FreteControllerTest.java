package com.martendal.moto_frete_api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.martendal.moto_frete_api.config.TestSecurityConfigurations;
import com.martendal.moto_frete_api.dto.frete.DadosFreteDTO;
import com.martendal.moto_frete_api.dto.frete.DadosResponseFreteDTO;
import com.martendal.moto_frete_api.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.martendal.moto_frete_api.infra.security.SecurityFilter;
import com.martendal.moto_frete_api.service.entities.FreteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(
        controllers = FreteController.class,
        excludeFilters = {
                @ComponentScan.Filter(
                        type = FilterType.ASSIGNABLE_TYPE,
                        classes = SecurityFilter.class
                )
        }
)
@Import(TestSecurityConfigurations.class)
@ActiveProfiles("test")
class FreteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private FreteService freteService;

    private DadosFreteDTO dadosFrete;
    private DadosResponseFreteDTO dadosResponse;

    @BeforeEach
    void setup() {
        dadosFrete = new DadosFreteDTO(1L, "Rua A", "Rua B");
        dadosResponse = new DadosResponseFreteDTO(1L, "Usuario", "Rua A", "Rua B", 10.0, 25.0, null);
    }

    @Test
    void deveInserirFreteComSucesso() throws Exception {
        when(freteService.inserir(any(DadosFreteDTO.class))).thenReturn(dadosResponse);

        mockMvc.perform(post("/frete/inserir")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dadosFrete)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.message").value("Frete inserido com sucesso!"))
                .andExpect(jsonPath("$.data.id").value(1L));
    }

    @Test
    void deveListarFretesPendentes() throws Exception {
        Page<DadosResponseFreteDTO> page = new PageImpl<>(List.of(dadosResponse));
        when(freteService.listarPendentes(any(PageRequest.class))).thenReturn(page);

        mockMvc.perform(get("/frete/pendentes")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Listagem de fretes pendentes bem sucessedida"))
                .andExpect(jsonPath("$.data.content[0].id").value(1L));
    }

    @Test
    void deveListarFretesProximos() throws Exception {
        Page<DadosResponseFreteDTO> page = new PageImpl<>(List.of(dadosResponse));
        DadosAtualizarLocalizacaoMotoboyDTO localizacao = new DadosAtualizarLocalizacaoMotoboyDTO(-26.9, -49.0);

        when(freteService.listarProximos(any(PageRequest.class), any(DadosAtualizarLocalizacaoMotoboyDTO.class)))
                .thenReturn(page);

        mockMvc.perform(get("/frete/proximos")
                        .param("page", "0")
                        .param("size", "10")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(localizacao)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Listagem de fretes proximos bem sucessedida"))
                .andExpect(jsonPath("$.data.content[0].id").value(1L));
    }

    @Test
    void deveExcluirFrete() throws Exception {

        mockMvc.perform(delete("/frete/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Frete deletado com sucesso!"))
                .andExpect(jsonPath("$.data").value(""));
    }

    @Test
    void deveAceitarFrete() throws Exception {
        when(freteService.aceitar(1L, 1L)).thenReturn(dadosResponse);

        mockMvc.perform(put("/frete/1/aceitar/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Frete aceito com sucesso"))
                .andExpect(jsonPath("$.data.id").value(1L));
    }

    @Test
    void deveConcluirFrete() throws Exception {
        when(freteService.concluir(1L)).thenReturn(dadosResponse);

        mockMvc.perform(put("/frete/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Frete concluido com sucesso"))
                .andExpect(jsonPath("$.data.id").value(1L));
    }

    @Test
    void deveMostrarRota() throws Exception {
        when(freteService.mostrarRota(1L)).thenReturn(List.of());

        mockMvc.perform(get("/frete/rota/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("rota"))
                .andExpect(jsonPath("$.data").isArray());
    }
}
