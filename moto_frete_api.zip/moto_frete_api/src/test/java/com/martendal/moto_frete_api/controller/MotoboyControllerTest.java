package com.martendal.moto_frete_api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.martendal.moto_frete_api.config.TestSecurityConfigurations;
import com.martendal.moto_frete_api.dto.motoboy.*;
import com.martendal.moto_frete_api.dto.usuario.DadosRegistarUsuarioDTO;
import com.martendal.moto_frete_api.infra.security.SecurityFilter;
import com.martendal.moto_frete_api.service.entities.MotoboyService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(
        controllers = MotoboyController.class,
        excludeFilters = {
               @ComponentScan.Filter(
                       type = FilterType.ASSIGNABLE_TYPE,
                       classes = SecurityFilter.class
               )
        }
)
@Import(TestSecurityConfigurations.class)
@ActiveProfiles("test")
class MotoboyControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private MotoboyService motoboyService;

    private DadosRegistarUsuarioDTO registrarDTO;
    private DadosCadastroMotoboyDTO cadastroDTO;
    private DadosAtualizarMotoboyDTO atualizarDTO;
    private DadosAtualizarLocalizacaoMotoboyDTO localizacaoDTO;
    private DadosResponseMotoboyDTO responseDTO;
    private DadosResponseLocalizacaoMotoboyDTO responseLocalizacaoMotoboyDTO;

    @BeforeEach
    void setup() {
        registrarDTO = new DadosRegistarUsuarioDTO(
                "usuario01@mail.com",
                "senha123",
                "usuario motoboy",
                "50558899",
                LocalDate.of(2004,07,11),
                "ADMIN");

        cadastroDTO = new DadosCadastroMotoboyDTO(1L, "honda", "4g8tc", 2010);
        atualizarDTO = new DadosAtualizarMotoboyDTO("moto atualizada", "", 2010);
        localizacaoDTO = new DadosAtualizarLocalizacaoMotoboyDTO(-26.9, -49.0);
        responseDTO = new DadosResponseMotoboyDTO("usuario motoboy",
                "moto atualizada",
                "4g8tc",
                2010,
                new DadosLocalizacaoMotoboyDTO(-26.9, -49.0));
        responseLocalizacaoMotoboyDTO = new DadosResponseLocalizacaoMotoboyDTO(1L, "usuario motoboy", -26.9, -49.0);
    }

    @Test
    void deveCadastrarMotoboy() throws Exception {
        when(motoboyService.inserir(any(DadosCadastroMotoboyDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/motoboy/cadastro")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(cadastroDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.message").value("Motoboy cadastrado com sucesso!"))
                .andExpect(jsonPath("$.data.nome").value("usuario motoboy"));
    }

    @Test
    void deveAtualizarMotoboy() throws Exception {
        when(motoboyService.atualizar(eq(1L), any(DadosAtualizarMotoboyDTO.class)))
                .thenReturn(responseDTO);

        mockMvc.perform(put("/motoboy/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(atualizarDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Motoboy atualizado com sucesso!"))
                .andExpect(jsonPath("$.data.nome").value("usuario motoboy"));
    }

    @Test
    void deveListarMotoboys() throws Exception {
        Page<DadosResponseMotoboyDTO> page = new PageImpl<>(List.of(responseDTO));
        when(motoboyService.listarMotoboys(any(PageRequest.class))).thenReturn(page);

        mockMvc.perform(get("/motoboy")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Motoboys listados com sucesso!"))
                .andExpect(jsonPath("$.data.content[0].nome").value("usuario motoboy"));
    }

    @Test
    void deveAtualizarLocalizacaoMotoboy() throws Exception {
        when(motoboyService.atualizarLocalizacao(eq(1L), any(DadosAtualizarLocalizacaoMotoboyDTO.class)))
                .thenReturn(responseLocalizacaoMotoboyDTO);

        mockMvc.perform(put("/motoboy/localizacao/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(localizacaoDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Localização do motoboy atualizada com sucesso!"))
                .andExpect(jsonPath("$.data.id").value(1L));
    }

    @Test
    void deveDeletarMotoboy() throws Exception {
        // O serviço não retorna nada
        mockMvc.perform(delete("/motoboy/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Motoboy deletado com sucesso!"));
    }
}
