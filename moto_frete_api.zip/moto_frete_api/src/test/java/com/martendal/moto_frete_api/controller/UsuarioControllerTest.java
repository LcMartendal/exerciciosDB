package com.martendal.moto_frete_api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.martendal.moto_frete_api.config.TestSecurityConfigurations;
import com.martendal.moto_frete_api.dto.usuario.*;
import com.martendal.moto_frete_api.entity.usuario.RoleUsuario;
import com.martendal.moto_frete_api.infra.security.SecurityFilter;
import com.martendal.moto_frete_api.service.entities.UsuarioService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;
import static org.springframework.data.domain.PageRequest.of;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(
        controllers = UsuarioController.class,
        excludeFilters = {
                @ComponentScan.Filter(
                        type = FilterType.ASSIGNABLE_TYPE,
                        classes = SecurityFilter.class
                )
        }
)
@Import(TestSecurityConfigurations.class)
@ActiveProfiles("test")
class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UsuarioService usuarioService;

    private DadosRegistarUsuarioDTO registrarDTO;
    private DadosLoginUsuarioDTO loginDTO;
    private DadosAtualizarUsuarioDTO atualizarDTO;
    private DadosResponseUsuarioDTO responseDTO;

    @BeforeEach
    void setup() {
        registrarDTO = new DadosRegistarUsuarioDTO(
                "usuario01@mail.com",
                "senha123",
                "usuario",
                "11144477735",
                LocalDate.of(2004, 7, 11),
                "ADMIN");

        loginDTO = new DadosLoginUsuarioDTO("usuario1@mail.com", "senha123");
        atualizarDTO = new DadosAtualizarUsuarioDTO("usuarioAtualizado@mail.com", "senha321", "asuario", null);
        responseDTO = new DadosResponseUsuarioDTO(1L, "usuario1@mail.com", "usuario", RoleUsuario.ADMIN);
    }

    @Test
    void deveRegistrarUsuario() throws Exception {
        when(usuarioService.registro(any(DadosRegistarUsuarioDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(post("/usuario/auth/registrar")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(registrarDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.message").value("Usuário registrado com sucesso!"))
                .andExpect(jsonPath("$.data.id").value(1L));
    }

    @Test
    void deveRealizarLogin() throws Exception {
        String token = "token123";
        when(usuarioService.login(any(DadosLoginUsuarioDTO.class))).thenReturn(token);

        mockMvc.perform(post("/usuario/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Login bem sucessedido!"))
                .andExpect(jsonPath("$.data").value(token));
    }

    @Test
    void deveAtualizarUsuario() throws Exception {
        when(usuarioService.atualizar(eq(1L), any(DadosAtualizarUsuarioDTO.class))).thenReturn(responseDTO);

        mockMvc.perform(put("/usuario/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(atualizarDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Usuário atualizado com sucesso!"))
                .andExpect(jsonPath("$.data.id").value(1L));
    }

    @Test
    void deveListarUsuarios() throws Exception {
        Page<DadosResponseUsuarioDTO> page = new PageImpl<>(List.of(responseDTO));
        when(usuarioService.listarUsuarios(of(0, 10))).thenReturn(page);

        mockMvc.perform(get("/usuario")
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Usuários listados com sucesso!"))
                .andExpect(jsonPath("$.data.content[0].id").value(1L));
    }

    @Test
    void deveDeletarUsuario() throws Exception {
//        when(usuarioService.deletar(1L)).thenReturn(responseDTO);

        mockMvc.perform(delete("/usuario/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Usuário deletado com sucesso!"));
    }
}
