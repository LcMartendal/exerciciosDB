package com.example.motofrete.service;

import com.example.motofrete.dto.usuario.DadosAtualizarUsuarioDTO;
import com.example.motofrete.dto.usuario.DadosLoginUsuarioDTO;
import com.example.motofrete.dto.usuario.DadosRegistarUsuarioDTO;
import com.example.motofrete.dto.usuario.DadosResponseUsuarioDTO;
import com.example.motofrete.entity.usuario.RoleUsuario;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.exception.entities.NaoEncontradoException;
import com.example.motofrete.exception.entities.usuario.FreteExistenteParaCriadorException;
import com.example.motofrete.exception.entities.usuario.LoginJaExisteException;
import com.example.motofrete.infra.security.TokenService;
import com.example.motofrete.repository.FreteRepository;
import com.example.motofrete.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UsuarioServiceTest {


    @InjectMocks
    private UsuarioService service;

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private FreteRepository freteRepository;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private TokenService tokenService;

    private Usuario usuario;

    @BeforeEach
    void setup() {
        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setLogin("luiz");
        usuario.setNome("Luiz");
        usuario.setSenha_hash("senhaCriptografada");
        usuario.setRole(RoleUsuario.SOLICITANTE_FRETE);
    }

    // ========================= REGISTRO =========================

    @Test
    void deveRegistrarUsuarioComSucesso() {

        DadosRegistarUsuarioDTO dto =
                new DadosRegistarUsuarioDTO("luiz", "123", "Luiz", RoleUsuario.SOLICITANTE_FRETE);

        when(usuarioRepository.existsByLogin("luiz"))
                .thenReturn(false);

        DadosResponseUsuarioDTO response = service.registro(dto);

        assertNotNull(response);
        assertEquals("luiz", response.login());
        assertEquals("Luiz", response.nome());
        assertEquals(RoleUsuario.SOLICITANTE_FRETE, response.role());

        verify(usuarioRepository).save(any(Usuario.class));
    }

    @Test
    void deveFalharAoRegistrarLoginExistente() {

        DadosRegistarUsuarioDTO dto =
                new DadosRegistarUsuarioDTO("luiz", "123", "Luiz", RoleUsuario.SOLICITANTE_FRETE);

        when(usuarioRepository.existsByLogin("luiz"))
                .thenReturn(true);

        assertThrows(LoginJaExisteException.class,
                () -> service.registro(dto));
    }

    // ========================= LOGIN =========================

    @Test
    void deveRealizarLoginComSucesso() {

        DadosLoginUsuarioDTO dto =
                new DadosLoginUsuarioDTO("luiz", "123");

        Authentication authentication =
                new UsernamePasswordAuthenticationToken(usuario, null);

        when(usuarioRepository.existsByLogin("luiz"))
                .thenReturn(true);

        when(authenticationManager.authenticate(any()))
                .thenReturn(authentication);

        when(tokenService.gerarToken(usuario))
                .thenReturn("TOKEN_JWT");

        String token = service.login(dto);

        assertEquals("TOKEN_JWT", token);
    }

    @Test
    void deveFalharLoginUsuarioInexistente() {

        DadosLoginUsuarioDTO dto =
                new DadosLoginUsuarioDTO("inexistente", "123");

        when(usuarioRepository.existsByLogin("inexistente"))
                .thenReturn(false);

        assertThrows(NaoEncontradoException.class,
                () -> service.login(dto));
    }

    // ========================= ATUALIZAR =========================

    @Test
    void deveAtualizarUsuarioComSucesso() {

        DadosAtualizarUsuarioDTO dto =
                new DadosAtualizarUsuarioDTO("novoLogin", "novaSenha", "Novo Nome", RoleUsuario.ADMIN);

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuario));

        when(usuarioRepository.existsByLogin("novoLogin"))
                .thenReturn(false);

        DadosResponseUsuarioDTO response = service.atualizar(1L, dto);

        assertEquals("novoLogin", response.login());
        assertEquals("Novo Nome", response.nome());
        assertEquals(RoleUsuario.ADMIN, response.role());

        verify(usuarioRepository).save(usuario);
    }

    @Test
    void deveFalharAoAtualizarLoginExistente() {

        DadosAtualizarUsuarioDTO dto =
                new DadosAtualizarUsuarioDTO("admin", null, null, null);

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuario));

        when(usuarioRepository.existsByLogin("admin"))
                .thenReturn(true);

        assertThrows(LoginJaExisteException.class,
                () -> service.atualizar(1L, dto));
    }

    @Test
    void deveFalharAoAtualizarUsuarioInexistente() {

        DadosAtualizarUsuarioDTO dto =
                new DadosAtualizarUsuarioDTO("login", null, null, null);

        when(usuarioRepository.findById(99L))
                .thenReturn(Optional.empty());

        assertThrows(NaoEncontradoException.class,
                () -> service.atualizar(99L, dto));
    }

    // ========================= LISTAR =========================

    @Test
    void deveListarUsuarios() {

        Page<Usuario> page = new PageImpl<>(List.of(usuario));

        when(usuarioRepository.findAll(any(PageRequest.class)))
                .thenReturn(page);

        Page<DadosResponseUsuarioDTO> result =
                service.listarUsuarios(PageRequest.of(0, 10));

        assertEquals(1, result.getTotalElements());
        assertEquals("luiz", result.getContent().get(0).nome());
    }

    // ========================= DELETAR =========================

    @Test
    void deveDeletarUsuarioComSucesso() {

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuario));

        when(freteRepository.existsByCriadorId(1L))
                .thenReturn(false);

        DadosResponseUsuarioDTO response = service.deletar(1L);

        assertEquals("luiz", response.login());

        verify(usuarioRepository).delete(usuario);
    }

    @Test
    void deveFalharAoDeletarUsuarioComFreteAssociado() {

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuario));

        when(freteRepository.existsByCriadorId(1L))
                .thenReturn(true);

        assertThrows(FreteExistenteParaCriadorException.class,
                () -> service.deletar(1L));
    }

    @Test
    void deveFalharAoDeletarUsuarioInexistente() {

        when(usuarioRepository.findById(99L))
                .thenReturn(Optional.empty());

        assertThrows(NaoEncontradoException.class,
                () -> service.deletar(99L));
    }

}