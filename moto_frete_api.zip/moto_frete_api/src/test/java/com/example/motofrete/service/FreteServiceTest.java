package com.example.motofrete.service;

import com.example.motofrete.dto.frete.DadosFreteDTO;
import com.example.motofrete.dto.frete.DadosResponseFreteDTO;
import com.example.motofrete.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.example.motofrete.dto.rota.RotaResumoDTO;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.entity.frete.Frete;
import com.example.motofrete.entity.frete.StatusFrete;
import com.example.motofrete.entity.usuario.RoleUsuario;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.exception.entities.NaoEncontradoException;
import com.example.motofrete.exception.entities.frete.DadosOrigemOuDestinoNaoPodeSerNullException;
import com.example.motofrete.exception.entities.frete.FreteNaoDisponivelException;
import com.example.motofrete.exception.entities.frete.FreteNaoPodeSerConcluidoException;
import com.example.motofrete.repository.FreteRepository;
import com.example.motofrete.repository.MotoboyRepository;
import com.example.motofrete.repository.UsuarioRepository;
import com.example.motofrete.service.rotas.RotaOrdenacaoService;
import com.example.motofrete.service.rotas.RotaService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FreteServiceTest {

    @InjectMocks
    private FreteService freteService;

    @Mock
    private FreteRepository freteRepository;

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private MotoboyRepository motoboyRepository;

    @Mock
    private RotaService rotaService;

    @Mock
    private RotaOrdenacaoService rotaOrdenacaoService;

    private Usuario usuario;
    private Motoboy motoboy;
    private Frete frete;

    @BeforeEach
    void setup() {
        usuario = new Usuario();
        usuario.setNome("usuario");
        usuario.setRole(RoleUsuario.MOTOBOY);

        motoboy = new Motoboy();

        frete = new Frete();
        frete.setId(1L);
        frete.setCriador(usuario);
        frete.setStatus(StatusFrete.PENDENTE);
        frete.setOrigemEndereco("Origem");
        frete.setDestinoEndereco("Destino");
        frete.setDistanciaKm(10.0);
        frete.setValor(25.0);

        // Simula @Value
        ReflectionTestUtils.setField(freteService, "tarifaKm", 2.5);
    }

    // ===================== INSERIR =====================

    @Test
    void deveInserirFreteComSucesso() {

        DadosFreteDTO dto = new DadosFreteDTO(
                1L,
                "Rua A",
                "Rua B"

        );

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        when(rotaService.gerarCoordenadas(anyString())).thenReturn(new double[]{-26.9, -49.0});
        when(rotaService.gerarRota(anyList())).thenReturn(null);
        when(rotaService.extrairResumoRota(any()))
                .thenReturn(new RotaResumoDTO(10, 20, null));

        DadosResponseFreteDTO response = freteService.inserir(dto);

        assertNotNull(response);
        assertEquals(StatusFrete.PENDENTE, response.status());
        verify(freteRepository).save(any(Frete.class));
    }

    @Test
    void deveLancarExcecaoQuandoUsuarioNaoExiste() {
        DadosFreteDTO dto = new DadosFreteDTO(99L, "A", "B");

        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(NaoEncontradoException.class,
                () -> freteService.inserir(dto));
    }

    @Test
    void deveLancarExcecaoQuandoOrigemOuDestinoEmBranco() {
        DadosFreteDTO dto = new DadosFreteDTO(1L, "", "");

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));

        assertThrows(DadosOrigemOuDestinoNaoPodeSerNullException.class,
                () -> freteService.inserir(dto));
    }

    // ===================== LISTAR =====================

    @Test
    void deveListarFretesPendentes() {
        Page<Frete> page = new PageImpl<>(List.of(frete));
        when(freteRepository.findByStatus(any(), eq(StatusFrete.PENDENTE)))
                .thenReturn(page);

        Page<DadosResponseFreteDTO> result =
                freteService.listarPendentes(PageRequest.of(0, 10));

        assertEquals(1, result.getTotalElements());
    }

    @Test
    void deveListarFretesProximos() {
        Page<Frete> page = new PageImpl<>(List.of(frete));

        when(freteRepository.listarFretesProximosPorRaio(
                any(), anyDouble(), anyDouble(), anyString(), anyDouble()
        )).thenReturn(page);

        Page<DadosResponseFreteDTO> result =
                freteService.listarProximos(
                        PageRequest.of(0, 10),
                        new DadosAtualizarLocalizacaoMotoboyDTO(-26.9, -49.0)
                );

        assertEquals(1, result.getTotalElements());
    }

    // ===================== EXCLUIR =====================

    @Test
    void deveExcluirFrete() {
        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));

        DadosResponseFreteDTO response = freteService.excluir(1L);

        verify(freteRepository).delete(frete);
        assertEquals(1L, response.id());
    }

    // ===================== ACEITAR =====================

    @Test
    void deveAceitarFrete() {
        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));
        when(motoboyRepository.findById(1L)).thenReturn(Optional.of(motoboy));

        DadosResponseFreteDTO response =
                freteService.aceitar(1L, 1L);

        assertEquals(StatusFrete.ACEITO, response.status());
    }

    @Test
    void deveFalharAoAceitarFreteNaoPendente() {
        frete.setStatus(StatusFrete.ACEITO);

        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));
        when(motoboyRepository.findById(1L)).thenReturn(Optional.of(motoboy));

        assertThrows(FreteNaoDisponivelException.class,
                () -> freteService.aceitar(1L, 1L));
    }

    // ===================== CONCLUIR =====================

    @Test
    void deveConcluirFrete() {
        frete.setStatus(StatusFrete.ACEITO);

        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));

        DadosResponseFreteDTO response = freteService.concluir(1L);

        assertEquals(StatusFrete.CONCLUIDO, response.status());
    }

    @Test
    void deveFalharAoConcluirFreteInvalido() {
        frete.setStatus(StatusFrete.PENDENTE);

        when(freteRepository.findById(1L)).thenReturn(Optional.of(frete));

        assertThrows(FreteNaoPodeSerConcluidoException.class,
                () -> freteService.concluir(1L));
    }
}