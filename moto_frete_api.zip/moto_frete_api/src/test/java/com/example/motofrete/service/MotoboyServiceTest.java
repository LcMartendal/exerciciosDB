package com.example.motofrete.service;

import com.example.motofrete.dto.motoboy.*;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.entity.usuario.RoleUsuario;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.exception.entities.NaoEncontradoException;
import com.example.motofrete.exception.entities.motoboy.DadosDoVeiculoNulosOuInvalidos;
import com.example.motofrete.exception.entities.usuario.DadosNaoPodemSerNullException;
import com.example.motofrete.repository.MotoboyRepository;
import com.example.motofrete.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MotoboyServiceTest {

    @InjectMocks
    private MotoboyService service;

    @Mock
    private MotoboyRepository motoboyRepository;

    @Mock
    private UsuarioRepository usuarioRepository;

    private Usuario usuario;
    private Motoboy motoboy;

    @BeforeEach
    void setup() {

        usuario = new Usuario();
        usuario.setId(1L);
        usuario.setLogin("motoboy");
        usuario.setNome("Motoboy Teste");
        usuario.setRole(RoleUsuario.MOTOBOY);

        motoboy = new Motoboy();
        motoboy.setId(1L);
        motoboy.setUsuario(usuario);
        motoboy.setModelo_moto("CG 160");
        motoboy.setPlaca("ABC-1234");
        motoboy.setAno(2020);
        motoboy.setLatitude(0.0);
        motoboy.setLongitude(0.0);
    }

    // ========================= INSERIR =========================

    @Test
    void deveInserirMotoboyComSucesso() {

        DadosCadastroMotoboyDTO dto = new DadosCadastroMotoboyDTO(
                1L,
                "CG 160",
                "ABC-1234",
                2020
        );

        when(usuarioRepository.findById(1L))
                .thenReturn(Optional.of(usuario));

        DadosResponseMotoboyDTO response = service.inserir(dto);

        assertNotNull(response);
        assertEquals("motoboy", response.username());
        assertEquals("CG 160", response.modeloMoto());
        assertEquals("ABC-1234", response.placa());
        assertEquals(2020, response.ano());

        verify(motoboyRepository).save(any(Motoboy.class));
    }

    @Test
    void deveFalharAoInserirSemUsuarioId() {

        DadosCadastroMotoboyDTO dto = new DadosCadastroMotoboyDTO(
                null,
                "CG 160",
                "ABC-1234",
                2020
        );

        assertThrows(DadosNaoPodemSerNullException.class,
                () -> service.inserir(dto));
    }

    @Test
    void deveFalharAoInserirUsuarioInexistente() {

        DadosCadastroMotoboyDTO dto = new DadosCadastroMotoboyDTO(
                99L,
                "CG 160",
                "ABC-1234",
                2020
        );

        when(usuarioRepository.findById(99L))
                .thenReturn(Optional.empty());

        assertThrows(NaoEncontradoException.class,
                () -> service.inserir(dto));
    }

    // ========================= LISTAR =========================

    @Test
    void deveListarMotoboys() {

        Page<Motoboy> page = new PageImpl<>(List.of(motoboy));

        when(motoboyRepository.findAll(any(PageRequest.class)))
                .thenReturn(page);

        Page<DadosResponseMotoboyDTO> result =
                service.listarMotoboys(PageRequest.of(0, 10));

        assertEquals(1, result.getTotalElements());
        assertEquals("motoboy", result.getContent().get(0).username());
    }

    // ========================= ATUALIZAR =========================

    @Test
    void deveAtualizarMotoboyComSucesso() {

        DadosAtualizarMotoboyDTO dto = new DadosAtualizarMotoboyDTO(
                "Factor 150",
                "XYZ-9999",
                2022
        );

        when(motoboyRepository.findById(1L))
                .thenReturn(Optional.of(motoboy));

        DadosResponseMotoboyDTO response =
                service.atualizar(1L, dto);

        assertEquals("Factor 150", response.modeloMoto());
        assertEquals("XYZ-9999", response.placa());
        assertEquals(2022, response.ano());

        verify(motoboyRepository).save(motoboy);
    }

    @Test
    void deveFalharAoAtualizarAnoInvalido() {

        DadosAtualizarMotoboyDTO dto = new DadosAtualizarMotoboyDTO(
                "CG 125",
                "AAA-0000",
                1970
        );

        when(motoboyRepository.findById(1L))
                .thenReturn(Optional.of(motoboy));

        assertThrows(DadosDoVeiculoNulosOuInvalidos.class,
                () -> service.atualizar(1L, dto));
    }

    @Test
    void deveFalharAoAtualizarMotoboyInexistente() {

        DadosAtualizarMotoboyDTO dto = new DadosAtualizarMotoboyDTO(
                "CG 125",
                "AAA-0000",
                2020
        );

        when(motoboyRepository.findById(99L))
                .thenReturn(Optional.empty());

        assertThrows(NaoEncontradoException.class,
                () -> service.atualizar(99L, dto));
    }

    // ========================= ATUALIZAR LOCALIZAÇÃO =========================

    @Test
    void deveAtualizarLocalizacaoMotoboy() {

        DadosAtualizarLocalizacaoMotoboyDTO dto =
                new DadosAtualizarLocalizacaoMotoboyDTO(-26.9, -49.0);

        when(motoboyRepository.findById(1L))
                .thenReturn(Optional.of(motoboy));

        DadosResponseLocalizacaoMotoboyDTO response =
                service.atualizarLocalizacao(1L, dto);

        assertEquals(-26.9, response.latitude());
        assertEquals(-49.0, response.longitude());

        verify(motoboyRepository).save(motoboy);
    }

    // ========================= DELETAR =========================

    @Test
    void deveDeletarMotoboy() {

        when(motoboyRepository.findById(1L))
                .thenReturn(Optional.of(motoboy));

        service.deletar(1L);

        verify(motoboyRepository).delete(motoboy);
    }

    @Test
    void deveFalharAoDeletarMotoboyInexistente() {

        when(motoboyRepository.findById(99L))
                .thenReturn(Optional.empty());

        assertThrows(NaoEncontradoException.class,
                () -> service.deletar(99L));
    }

}