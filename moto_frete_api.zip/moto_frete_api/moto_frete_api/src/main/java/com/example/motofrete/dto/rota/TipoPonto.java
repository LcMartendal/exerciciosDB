package com.example.motofrete.dto.rota;

public enum TipoPonto {
    ORIGEM,
    DESTINO
}
