package com.example.motofrete.exception.usuario;

public class LoginJaExisteException extends RuntimeException{

    public LoginJaExisteException() { super("Login já existe"); }

    public LoginJaExisteException(String message) {
        super(message);
    }
}
