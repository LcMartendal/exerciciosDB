package com.example.motofrete.repository;

import com.example.motofrete.entity.Motoboy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MotoboyRepository extends JpaRepository<Motoboy, Long> {

    Page<Motoboy> findAll(Pageable pageable);
}
