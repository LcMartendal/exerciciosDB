package com.example.motofrete.dto.rota;

import java.util.List;

public record RotaResponseDTO(

        double distance,
        double duration,
        List<double[]> coordinates

) {}
