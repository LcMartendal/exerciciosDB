package com.example.motofrete.entity;

import com.example.motofrete.dto.motoboy.DadosCadastroMotoboyDTO;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.dto.motoboy.DadosMotoboyDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "motoboy")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Motoboy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne @JoinColumn(name="usuario_id", nullable=false)
    private Usuario usuario;

    private Double latitude;

    private Double longitude;

//    private String status;

    private String modelo_moto;

    private String placa;

    private int ano;

    public Motoboy(DadosMotoboyDTO dados) {
        this.usuario = dados.usuario();
        this.latitude = dados.latitude();
        this.longitude = dados.longitude();
        this.modelo_moto = dados.modelo_moto();
        this.placa = dados.placa();
        this.ano = dados.ano();
    }

    public Motoboy(DadosCadastroMotoboyDTO dados, Usuario usuario) {
        this.usuario = usuario;
        this.modelo_moto = dados.modelo_moto();
        this.placa = dados.placa();
        this.ano = dados.ano();
    }
}
