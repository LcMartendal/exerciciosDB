package com.example.motofrete.exception.entities.usuario;

public class SenhaIncorretaException extends RuntimeException{

    public SenhaIncorretaException() {
    }

    public SenhaIncorretaException(String message) {
        super(message);
    }
}
