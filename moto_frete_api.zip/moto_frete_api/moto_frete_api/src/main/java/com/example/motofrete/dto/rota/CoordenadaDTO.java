package com.example.motofrete.dto.rota;

public record CoordenadaDTO(

        double lat,
        double lng

) {}
