package com.example.motofrete.exception;

import com.example.motofrete.exception.autenticacao.TokenInvalidoException;
import com.example.motofrete.exception.motoboy.DadosDoVeiculoNulosOuInvalidos;
import com.example.motofrete.exception.usuario.LoginJaExisteException;
import com.example.motofrete.exception.validations.FieldErrorResponse;
import com.example.motofrete.exception.validations.ResponseException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Date;
import java.util.List;

@RestControllerAdvice
public class RestControllerAdviceHandler {

    @ExceptionHandler(NaoEncontradoException.class)
    public ResponseEntity<ResponseException> handlerNotFound(NaoEncontradoException ex) {
        ResponseException response = new ResponseException(
                "Não encontrado",
                HttpStatus.NOT_FOUND.value(),
                new Date().getTime(),
                null
        );


        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(response);
    }

    @ExceptionHandler(DadosDoVeiculoNulosOuInvalidos.class)
    public ResponseEntity<ResponseException> handler(DadosDoVeiculoNulosOuInvalidos ex) {
        ResponseException response = new ResponseException(
                "Dado inválido",
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                null
        );


        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(response);
    }

    @ExceptionHandler(LoginJaExisteException.class)
    public ResponseEntity<ResponseException> handlerConflict(LoginJaExisteException ex) {

        ResponseException response = new ResponseException(
                ex.getMessage(),
                HttpStatus.CONFLICT.value(),
                new Date().getTime(),
                null
        );

        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResponseException> handleValidations(MethodArgumentNotValidException ex) {

        List<FieldErrorResponse> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(error -> new FieldErrorResponse(
                        error.getField(),
                        error.getDefaultMessage()
                ))
                .toList();

        ResponseException response = new ResponseException(

                "Erro de validação",
                HttpStatus.BAD_REQUEST.value(),
                new Date().getTime(),
                errors
        );

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(response);

    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResponseException> handle(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(
                new ResponseException(
                        "Erro interno da aplicação. Tente novamente mais tarde ou entre em contato com o time de suporte.",
                        HttpStatus.INTERNAL_SERVER_ERROR.value(),
                        new Date().getTime()
                )
        );
    }

}
