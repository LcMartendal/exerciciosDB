package com.example.motofrete.service.rotas;

import com.example.motofrete.dto.rota.FreteRotaDTO;
import com.example.motofrete.dto.rota.PontoRota;
import com.example.motofrete.dto.rota.TipoPonto;
import com.example.motofrete.service.rotas.util.CalculadoraDistancia;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RotaOrdenacaoService {

    private PontoRota atual;

    public List<PontoRota> ordenar(List<FreteRotaDTO> fretes) {

        List<PontoRota> pontos = new ArrayList<>();

        for (FreteRotaDTO frete : fretes) {
            pontos.add(frete.origem());
            pontos.add(frete.destino());
        }

        List<List<PontoRota>> rotasValidas = new ArrayList<>();
        permutar(pontos, 0, rotasValidas);

        return rotasValidas.stream()
                .min(Comparator.comparingDouble(CalculadoraDistancia::distanciaTotal))
                .orElse(pontos);
    }

    private void permutar(List<PontoRota> lista, int index, List<List<PontoRota>> resultado) {
        if (index == lista.size()) {
            if (rotaValida(lista)) {
                resultado.add(new ArrayList<>(lista));
            }
            return;
        }

        for (int i = index; i < lista.size(); i++) {
            trocar(lista, index, i);
            permutar(lista, index + 1, resultado);
            trocar(lista, index, i);
        }
    }

    private void trocar(List<PontoRota> lista, int i, int j) {
        PontoRota temp = lista.get(i);
        lista.set(i, lista.get(j));
        lista.set(j, temp);
    }

    private boolean rotaValida(List<PontoRota> rota) {
        for (PontoRota p : rota) {
            if (p.tipo() == TipoPonto.DESTINO) {
                boolean origemAntes = false;
                for (PontoRota anterior : rota) {
                    if (anterior == p) break;
                    if (anterior.freteId().equals(p.freteId())
                            && anterior.tipo() == TipoPonto.ORIGEM) {
                        origemAntes = true;
                    }
                }
                if (!origemAntes) {
                    return false;
                }
            }
        }
        return true;
    }

    //Heurística Greedy
    public List<PontoRota> ordenarGreedy(
            PontoRota inicio,
            List<FreteRotaDTO> fretes
    ) {
        List<PontoRota> rota = new ArrayList<>();
        List<PontoRota> pendentes = new ArrayList<>();
        Set<Long> fretesColetados = new HashSet<>();

        for (FreteRotaDTO f : fretes) {
            pendentes.add(f.origem());
            pendentes.add(f.destino());
        }

        this.atual = inicio;

        while (!pendentes.isEmpty()) {

            PontoRota proximo = pendentes.stream()
                    .filter(p ->
                            p.tipo() == TipoPonto.ORIGEM ||
                                    fretesColetados.contains(p.freteId())
                    )
                    .min(Comparator.comparingDouble(p ->
                            CalculadoraDistancia.distancia(atual, p)
                    ))
                    .orElseThrow();

            rota.add(proximo);
            pendentes.remove(proximo);

            if (proximo.tipo() == TipoPonto.ORIGEM) {
                fretesColetados.add(proximo.freteId());
            }

            atual = proximo;
        }

        return rota;
    }

}
