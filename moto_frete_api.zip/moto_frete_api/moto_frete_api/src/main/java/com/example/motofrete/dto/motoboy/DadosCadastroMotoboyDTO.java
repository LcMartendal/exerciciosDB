package com.example.motofrete.dto.motoboy;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record DadosCadastroMotoboyDTO(

        @NotNull
        Long usuario_id,

        @NotBlank
        String modelo_moto,

        @NotBlank
        String placa,

        @NotNull
        int ano

) {
}
