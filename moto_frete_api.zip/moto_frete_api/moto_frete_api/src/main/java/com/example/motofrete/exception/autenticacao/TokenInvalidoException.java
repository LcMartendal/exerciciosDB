package com.example.motofrete.exception.autenticacao;

public class TokenInvalidoException extends RuntimeException{

    public TokenInvalidoException() {
    }

    public TokenInvalidoException(String message) {
        super(message);
    }
}
