package com.example.motofrete.dto.rota.notused;

public record NOTUSEDCoordenadaDTO(

        double lat,
        double lng

) {}
