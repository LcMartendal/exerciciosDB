package com.example.motofrete.controller;

import com.example.motofrete.dto.motoboy.DadosAtualizarLocalizacaoMotoboyDTO;
import com.example.motofrete.dto.motoboy.DadosAtualizarMotoboyDTO;
import com.example.motofrete.dto.motoboy.DadosCadastroMotoboyDTO;
import com.example.motofrete.service.MotoboyService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/motoboy")
public class MotoboyController {

    @Autowired
    private MotoboyService service;

    @PostMapping("/cadastro")
    public ResponseEntity cadastrar(@Valid @RequestBody DadosCadastroMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("message", "Motoboy cadastrado com sucesso!", "motoboy", service.inserir(dados)));
    }

    @PutMapping("/{id}")
    public ResponseEntity atualizar(@PathVariable Long id, @Valid @RequestBody DadosAtualizarMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Motoboy atualizado com sucesso!", "motoboy", service.atualizar(id, dados)));
    }

    @GetMapping
    public ResponseEntity listar() {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Motoboys listados com sucesso!", "motoboys", service.listarTodos()));
    }

    @PutMapping("/localizacao/{id}")
    public ResponseEntity atualizarLocalizacao(@PathVariable Long id, @Valid @RequestBody DadosAtualizarLocalizacaoMotoboyDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Localização do motoboy atualizada com sucesso!", "motoboy", service.atualizarLocalizacao(id, dados)));
    }

    @DeleteMapping("{id}")
    public ResponseEntity deletar(@PathVariable Long id) {

        service.deletar(id);

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("message", "deletado com sucesso!"));
    }

}
