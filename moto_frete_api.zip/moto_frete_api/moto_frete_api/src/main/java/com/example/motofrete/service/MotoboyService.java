package com.example.motofrete.service;

import com.example.motofrete.dto.motoboy.*;
import com.example.motofrete.entity.Motoboy;
import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.repository.UsuarioRepository;
import com.example.motofrete.exception.NaoEncontradoException;
import com.example.motofrete.exception.motoboy.DadosDoVeiculoNulosOuInvalidos;
import com.example.motofrete.exception.usuario.DadosNaoPodemSerNullException;
import com.example.motofrete.repository.MotoboyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MotoboyService {

    @Autowired
    private MotoboyRepository repository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    public DadosResponseMotoboyDTO inserir(DadosCadastroMotoboyDTO dados) {

        if(dados.usuario_id() == null) {
            throw new DadosNaoPodemSerNullException();
        }

        Usuario usuario = usuarioRepository.findById(dados.usuario_id())
                .orElseThrow(() -> new NaoEncontradoException("Usuário não encontrado com id " + dados.usuario_id()));

        Motoboy motoboy = new Motoboy(dados, usuario);

        repository.save(motoboy);

        return new DadosResponseMotoboyDTO(usuario,0.0, 0.0, dados.modelo_moto(),
                dados.placa(), dados.ano());
    }

    public List<Motoboy> listarTodos() { return repository.findAll(); }

    public DadosResponseMotoboyDTO atualizar(Long id, DadosAtualizarMotoboyDTO dados) {

        Motoboy motoboy = repository.findById(id)
                            .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + id));

        if(!dados.modelo_moto().isBlank()){
            motoboy.setModelo_moto(dados.modelo_moto());
        }

        if(!dados.placa().isBlank()){
            motoboy.setPlaca(dados.placa());
        }

        if(dados.ano() < 1980 ){
            throw new DadosDoVeiculoNulosOuInvalidos("Ano da moto inválido: " + dados.ano());
        }

        motoboy.setAno(dados.ano());

        repository.save(motoboy);

        return new DadosResponseMotoboyDTO(motoboy.getUsuario(), motoboy.getLatitude(),
                motoboy.getLongitude(), dados.modelo_moto(),
                dados.placa(), dados.ano());

    }

    public DadosResponseLocalizacaoMotoboyDTO atualizarLocalizacao(Long id, DadosAtualizarLocalizacaoMotoboyDTO dados) {

        Motoboy motoboy = repository.findById(id)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + id));

        motoboy.setLatitude(dados.latitude());
        motoboy.setLongitude(dados.longitude());

        repository.save(motoboy);

        return new DadosResponseLocalizacaoMotoboyDTO(motoboy.getUsuario(), motoboy.getId(), motoboy.getLatitude(),
                motoboy.getLongitude());

    }

    public void deletar(Long motoboy_id) {

        Motoboy motoboy = repository.findById(motoboy_id)
                .orElseThrow(() -> new NaoEncontradoException("Motoboy não encontrado com id " + motoboy_id));

        repository.delete(motoboy);
    }

}
