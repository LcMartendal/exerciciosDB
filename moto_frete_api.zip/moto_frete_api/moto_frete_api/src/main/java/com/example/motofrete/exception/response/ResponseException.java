package com.example.motofrete.exception.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class ResponseException {
    private String message;
    private Integer statusCode;
    private Long timestamp;
    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private List<FieldErrorResponse> invalidFields;

    public ResponseException(String message, Integer statusCode, Long timestamp) {
        this.message = message;
        this.statusCode = statusCode;
        this.timestamp = timestamp;
    }
}
