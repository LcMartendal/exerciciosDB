package com.example.motofrete.exception.usuario;

public class DadosNaoPodemSerNullException extends RuntimeException{

    public DadosNaoPodemSerNullException() {
    }

    public DadosNaoPodemSerNullException(String message) {
        super(message);
    }
}
