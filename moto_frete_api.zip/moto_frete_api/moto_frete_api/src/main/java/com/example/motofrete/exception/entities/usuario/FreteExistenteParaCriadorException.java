package com.example.motofrete.exception.entities.usuario;

public class FreteExistenteParaCriadorException extends RuntimeException{

    public FreteExistenteParaCriadorException() {
    }

    public FreteExistenteParaCriadorException(String message) {
        super(message);
    }
}
