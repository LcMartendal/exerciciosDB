package com.example.motofrete.dto.motoboy;

import com.example.motofrete.entity.usuario.Usuario;

public record DadosResponseMotoboyDTO(

        Usuario usuario,

        Double latitude,

        Double longitude,

        String modelo_moto,

        String placa,

        int ano

) {
}
