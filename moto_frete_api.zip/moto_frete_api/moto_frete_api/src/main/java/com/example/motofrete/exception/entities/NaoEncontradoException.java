package com.example.motofrete.exception.entities;

public class NaoEncontradoException extends RuntimeException{

    public NaoEncontradoException() {
    }

    public NaoEncontradoException(String message) {
        super(message);
    }
}
