package com.example.motofrete.controller;

import com.example.motofrete.dto.usuario.DadosAtualizarUsuarioDTO;
import com.example.motofrete.dto.usuario.DadosLoginUsuarioDTO;
import com.example.motofrete.dto.usuario.DadosRegistarUsuarioDTO;
import com.example.motofrete.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("usuario")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @PostMapping("/auth/registrar")
    public ResponseEntity registrar(@Valid @RequestBody DadosRegistarUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(Map.of("Usuario registrado com sucesso!", service.registro(dados)));
    }

    @PostMapping("/auth/login")
    public ResponseEntity login(@Valid @RequestBody DadosLoginUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Login bem sucessedido!","token", service.login(dados)));
    }

    @PutMapping("/{id}")
    public ResponseEntity atualizar(@PathVariable Long id, @Valid @RequestBody DadosAtualizarUsuarioDTO dados) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Usuario atualizado com sucesso!", "usuário", service.atualizar(id, dados)));
    }

    @GetMapping
    public ResponseEntity listarTodos() {

        return ResponseEntity.status(HttpStatus.OK).body(Map.of("message", "Usuários listados com sucesso!", "lista de usuários", service.listarTodos()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity deletar(@PathVariable Long id) {

        return ResponseEntity.status(HttpStatus.OK)
                .body(Map.of("message", "Usuário deletado com sucesso!", "usuário", service.deletar(id)));
    }

}
