package com.example.motofrete.dto.rota;

public record RotaRequestMotoboyDTO(

        Double origem,
        Double[] paradas,
        Double destino

){}

