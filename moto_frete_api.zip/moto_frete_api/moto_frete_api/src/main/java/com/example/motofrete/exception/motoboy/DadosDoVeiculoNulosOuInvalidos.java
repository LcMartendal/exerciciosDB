package com.example.motofrete.exception.motoboy;

public class DadosDoVeiculoNulosOuInvalidos extends RuntimeException{

    public DadosDoVeiculoNulosOuInvalidos() {
    }

    public DadosDoVeiculoNulosOuInvalidos(String message) {
        super(message);
    }
}
