package com.example.motofrete.dto.motoboy;

import com.example.motofrete.entity.usuario.Usuario;

public record DadosResponseLocalizacaoMotoboyDTO(

        Usuario usuario,

        Long id,

        Double latitude,

        Double longitude

) {
}
