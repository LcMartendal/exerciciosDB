package com.example.motofrete.service.rotas.util;

import com.example.motofrete.dto.rota.PontoRota;
import java.util.List;

public class CalculadoraDistancia {

    public static double distancia(PontoRota a, PontoRota b) {
        double dx = a.latitude() - b.latitude();
        double dy = a.longitude() - b.longitude();
        return Math.sqrt(dx * dx + dy * dy);
    }

    public static double distanciaTotal(List<PontoRota> rota) {
        double total = 0.0;
        for (int i = 0; i < rota.size() - 1; i++) {
            total += distancia(rota.get(i), rota.get(i + 1));
        }
        return total;
    }

}
