package com.example.motofrete.service;

import com.example.motofrete.entity.usuario.Usuario;
import com.example.motofrete.repository.UsuarioRepository;
import com.example.motofrete.exception.NaoEncontradoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

@Service
public class AutenticacaoService implements UserDetailsService {

    @Autowired
    private UsuarioRepository repository;

    @Override
    public UserDetails loadUserByUsername(String login) {

        Usuario usuario = (Usuario) repository.findByLogin(login);
        if(usuario.equals(null) || usuario.equals("")){
            throw new NaoEncontradoException("Usuário não encontrado com login: " + login);
        }

        return repository.findByLogin(login);
    }

}
