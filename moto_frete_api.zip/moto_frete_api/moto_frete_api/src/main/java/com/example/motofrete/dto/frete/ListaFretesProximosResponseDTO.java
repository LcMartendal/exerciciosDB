package com.example.motofrete.dto.frete;

import org.springframework.data.domain.Page;

public record ListaFretesProximosResponseDTO(

        String message,
        Page<DadosResponseFreteDTO> fretes

) {}
