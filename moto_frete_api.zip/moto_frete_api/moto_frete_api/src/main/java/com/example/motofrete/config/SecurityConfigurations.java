package com.example.motofrete.config;

import com.example.motofrete.exception.response.ResponseException;
import com.example.motofrete.infra.security.SecurityFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import java.io.IOException;
import java.util.Date;

@Configuration
@EnableWebSecurity
public class SecurityConfigurations {
    
    @Autowired
    private SecurityFilter securityFilter;

    private static final ObjectMapper mapper = new ObjectMapper();

    @Bean
    SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
        return httpSecurity
                .csrf(AbstractHttpConfigurer::disable)

                .sessionManagement(session ->
                        session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

                // Handlers de autenticação e autorização
                .exceptionHandling(ex -> ex
                        .authenticationEntryPoint(this::handleAuthException)
                        .accessDeniedHandler(this::handleAccessDenied)
                )

                .authorizeHttpRequests(auth ->
                        auth.requestMatchers(HttpMethod.POST, "/usuario/auth/registrar", "/usuario/auth/login").permitAll()
                        .requestMatchers(HttpMethod.GET, "/usuario").permitAll()
                    .anyRequest().permitAll())

                .addFilterBefore(securityFilter, UsernamePasswordAuthenticationFilter.class)
                .build();
    }

    @Bean
    public AuthenticationManager authorizationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    private void handleAuthException(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException {
        ResponseException body;
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        if (authException instanceof org.springframework.security.authentication.BadCredentialsException) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            body = new ResponseException(
                    "Usuário ou senha inválidos",
                    HttpServletResponse.SC_UNAUTHORIZED,
                    new Date().getTime(),
                    null
            );
        } else {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            body = new ResponseException(
                    authException.getMessage(),
                    HttpServletResponse.SC_UNAUTHORIZED,
                    new Date().getTime(),
                    null
            );
        }

        response.getWriter().write(mapper.writeValueAsString(body));
    }

    private void handleAccessDenied(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException {
        ResponseException body = new ResponseException(
                "Acesso negado",
                HttpServletResponse.SC_FORBIDDEN,
                new Date().getTime(),
                null
        );

        response.setStatus(HttpServletResponse.SC_FORBIDDEN);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        response.getWriter().write(mapper.writeValueAsString(body));
    }

    
}
