package com.example.motofrete.dto.rota;

import java.util.List;

public record RotaCoordenadasRequestDTO(

        double[] origem,
        List<double[]> paradas,
        double[] destino

) {}
