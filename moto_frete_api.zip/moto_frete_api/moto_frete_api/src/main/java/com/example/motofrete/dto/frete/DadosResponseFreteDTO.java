package com.example.motofrete.dto.frete;

import com.example.motofrete.dto.usuario.DadosResponseUsuarioDTO;
import com.example.motofrete.entity.frete.StatusFrete;
import com.example.motofrete.entity.usuario.Usuario;

import java.util.List;

public record DadosResponseFreteDTO(

        Long id,
        String username,
        List<String> authorities,
        String origem,
        String destino,
        Double distanciaKm,
        Double valor,
        StatusFrete status

) {
}
