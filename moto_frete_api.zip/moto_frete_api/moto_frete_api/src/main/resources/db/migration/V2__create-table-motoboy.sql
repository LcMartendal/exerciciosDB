CREATE TABLE IF NOT EXISTS motoboy (

    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL REFERENCES usuario(id) ON DELETE CASCADE,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    modelo_moto VARCHAR(100),
    placa VARCHAR(30),
    ano INTEGER

);